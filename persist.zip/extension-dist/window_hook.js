; (function () {
  const origin = window.open.bind(window)
  const hook = () => {
    Object.assign(window, {
      open: (url, _target, features) => {
        origin(url, '_self', features)
      },
    })
    // 解决 IDE PWA 场景开启的 iframe 优化导致页面机构异构的问题
    if (window.location.hostname === 'ide.byted.org' || window.location.hostname === 'ide-boe.byted.org') {
      window.matchMedia = function () {
        return {
          matches: false,
          addListener: () => {
            //
          },
          removeListener: () => {
            //
          },
        }
      }
    }
    const Garfish = window?.Garfish
    if (Garfish?.activeApps?.length) {
      Garfish?.activeApps.forEach((app) => {
        if (app?.global) {
          Object.assign(app?.global, {
            open: (url, _target, features) => {
              origin(url, '_self', features)
            },
          })
        }
      })
    }
  }
  const only = new MutationObserver(() => {
    hook()
  })
  only.observe(document.body, {
    childList: true,
    subtree: true,
  })
})()
