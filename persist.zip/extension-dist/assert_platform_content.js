(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["mnt-swan"] = factory();
	else
		root["mnt-swan"] = factory();
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 3540:
/***/ (function() {

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let init = false;
const RunAssertPlatform = () => {
    if (!init) {
        /**
         * 监听来自页面的 postMessage 转发给 background 进行后续处理
         */
        window.addEventListener('message', (e) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            /**
             * 只处理来自 mnt 的消息
             */
            if (typeof e.data === 'object' && ((_a = e.data) === null || _a === void 0 ? void 0 : _a.origin) === 'mnt') {
                const { payload } = e.data;
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'start_record') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'record-processing') {
                    // 录制进行中，需要添加蒙层，不让用户继续操作
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'restart_record') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'end-record') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'end-execution') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'init-execution') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'open-task-detail') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'check-open') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'set-cookies') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'reset-cookies') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'set-del-cookies') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'check-running-task') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'set-extra-headers') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'set-window-size') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'query-work-area-size') {
                    yield chrome.runtime.sendMessage(payload);
                }
                // if (payload?.name === 'heartbeat') {
                //   await chrome.runtime.sendMessage(payload)
                // }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'set-record-env') {
                    yield chrome.runtime.sendMessage(payload);
                }
                if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'get-version') {
                    window.postMessage({
                        type: 'version-result',
                        payload: '1.3.3',
                    });
                }
            }
        }));
        init = true;
    }
};
RunAssertPlatform();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__[3540]();
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});