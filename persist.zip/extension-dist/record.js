(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["mnt-swan"] = factory();
	else
		root["mnt-swan"] = factory();
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 1080:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.generateElementFindRules = exports.findNodeByXpath = void 0;
const default_primaryKeys = [
    'data-e2e-id',
    'data-nclc-runtime-form-item-id',
    'type',
    'name',
    'data-automation-e2e',
    'data-testid',
    // 'data-automation-activity-node-id',
    'data-automation-activity-node-type',
    'data-form-item',
    'data-row-btn',
    'data-autotest-e2e',
    'data-autotest-e2e-type',
];
const ud_uniqu_cls = ['ud__layout', 'ud__table', 'ud__tabs', 'ud__pagination', 'ud__layout__content'];
const primaryKeys = ['data-origin-path', ...default_primaryKeys];
const secondaryKeys = ['data-automation-e2e'];
const primaryClsKeys = ['data-autotest-e2e'];
// const hasOnlyOne = (elementList) => elementList?.length === 1
// const hasOnlyOneWithSelector = (sel) => hasOnlyOne(document.querySelectorAll(sel || '*'))
const findNodeByXpath = (xpath) => {
    const result = document.evaluate(xpath, document, null, XPathResult.ANY_TYPE, null);
    const eles = [];
    let _result = result.iterateNext();
    while (_result) {
        if (_result) {
            eles.push(_result);
        }
        _result = result.iterateNext();
    }
    return eles;
};
exports.findNodeByXpath = findNodeByXpath;
const hasOnlyOneWithXpath = (xpath, ignore = false) => {
    var _a;
    if (ignore) {
        return false;
    }
    return ((_a = (0, exports.findNodeByXpath)(xpath)) === null || _a === void 0 ? void 0 : _a.length) === 1;
};
const getTextContent = (element) => {
    var _a, _b;
    let text = '';
    if ((element === null || element === void 0 ? void 0 : element.children.length) > 0) {
        let textNodeCount = 0;
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let i = 0; i < element.children.length; i++) {
            const child = element.children[i];
            if (child && child.nodeType === Node.TEXT_NODE) {
                textNodeCount += 1;
            }
        }
        // 当前节点内包含文字
        if (textNodeCount > 0 && element.tagName.toLowerCase() !== 'body' && element.tagName.toLowerCase() !== 'html') {
            text = (_a = element.textContent) !== null && _a !== void 0 ? _a : '';
        }
    }
    else {
        text = (_b = element.textContent) !== null && _b !== void 0 ? _b : '';
    }
    return text;
};
const calculate = (element, path = [], pk = [], states = {
    last: 0,
    current: 0,
    finish: false,
}, ignoreText = false) => {
    var _a, _b;
    if (states.finish) {
        return path;
    }
    const tagName = element.tagName.toLowerCase();
    if (element instanceof SVGAElement || ['svg', 'path', 'g', 'text'].includes(tagName)) {
        return;
    }
    states.current += 1;
    if (tagName === 'body') {
        if (path.length) {
            path.unshift(states.current - 1 === states.last ? '/' : '//');
        }
        path.unshift('//body');
        states.finish = true;
        return path;
    }
    let _xpath = tagName;
    // 通过 attribute 寻找唯一性的特征
    const relativePath = element.getAttribute('data-e2e-relative-path');
    if (relativePath) {
        if (path.length) {
            path.unshift(states.current - 1 === states.last ? '/' : '//');
        }
        path.unshift(relativePath);
        states.finish = true;
        return path;
    }
    // 通过元素class属性及索引确定目标元素的唯一性
    for (const c of primaryClsKeys) {
        if ((_a = element.className) === null || _a === void 0 ? void 0 : _a.includes(`${c}`)) {
            const classList = Array.from(element.classList);
            const className = classList === null || classList === void 0 ? void 0 : classList.find((cls) => cls.includes(c));
            const classPath = `[contains(@class,"${className}")]`;
            const nodeCol = (0, exports.findNodeByXpath)(`//${_xpath}${classPath}`);
            if (nodeCol.length) {
                const index = nodeCol.findIndex((ele) => ele === element);
                if (index === -1) {
                    continue;
                }
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`(//${_xpath}${classPath})[${index + 1}]`);
                states.finish = true;
                return path;
            }
        }
    }
    for (const c of ud_uniqu_cls) {
        if ((_b = element.classList) === null || _b === void 0 ? void 0 : _b.contains(`${c}`)) {
            const classPath = `[contains(@class,"${c} ")]`;
            const isOnly = hasOnlyOneWithXpath(`//${_xpath}${classPath}`);
            if (isOnly) {
                _xpath += classPath;
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    for (const key of pk) {
        const attrVal = element.getAttribute(key);
        if (attrVal) {
            const attributePath = `[@${key}="${attrVal}"]`;
            // 找到具有唯一性的特征
            const isOnly = hasOnlyOneWithXpath(`//${_xpath}${attributePath}`);
            // 如果包含 hover 需要过滤一下
            // if (key === 'class' && attrVal.includes('hover')) {
            //   continue
            // }
            if (isOnly) {
                _xpath += attributePath;
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    // 通过元素属性及索引确定目标元素的唯一性
    for (const secondaryKey of secondaryKeys) {
        const attrVal = element.getAttribute(secondaryKey);
        if (attrVal) {
            const attributePath = `[@${secondaryKey}="${attrVal}"]`;
            const nodeCol = (0, exports.findNodeByXpath)(`//${_xpath}${attributePath}`);
            if (nodeCol.length) {
                const index = nodeCol.findIndex((ele) => ele === element);
                if (index === -1) {
                    continue;
                }
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`(//${_xpath}${attributePath})[${index + 1}]`);
                states.finish = true;
                return path;
            }
        }
    }
    // 通过元素的文本信息查看是否具有唯一性
    if (!ignoreText) {
        const text = getTextContent(element);
        if (text.length) {
            const textPath = `[text()='${text}']`;
            const textPathWithTrim = `[text()='${text.trim()}']`;
            const textPathWithTrimStart = `[text()='${text.trimStart()}']`;
            const textPathWithTrimEnd = `[text()='${text.trimEnd()}']`;
            const textList = Array.from(new Set([textPath, textPathWithTrim, textPathWithTrimStart, textPathWithTrimEnd]));
            let isOnly = false;
            textList.forEach((t) => {
                if (hasOnlyOneWithXpath(`//${_xpath}${t}`)) {
                    isOnly = true;
                    _xpath += t;
                    return;
                }
            });
            // 找到具有唯一性的特征
            if (isOnly) {
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    else {
        // 检查 className 的唯一性
        const classNames = element.classList;
        if ((classNames === null || classNames === void 0 ? void 0 : classNames.length) > 0) {
            const _cls = [];
            let _c = '';
            classNames.forEach((cls, i) => {
                if (i + 1 === classNames.length) {
                    _c += `${cls}`;
                }
                else {
                    _c += `${cls} `;
                }
                _cls.push(_c);
            });
            for (const c of _cls) {
                const classPath = `[contains(@class,"${c}")]`;
                const isOnly = hasOnlyOneWithXpath(`//${_xpath}${classPath}`);
                if (isOnly) {
                    _xpath += classPath;
                    if (path.length) {
                        path.unshift(states.current - 1 === states.last ? '/' : '//');
                    }
                    path.unshift(`//${_xpath}`);
                    states.finish = true;
                    return path;
                }
            }
        }
    }
    if (_xpath === tagName) {
        let previousSibling = element;
        let nextSibling = element;
        let nth = 1;
        let nextSiblingCount = 0;
        // eslint-disable-next-line no-cond-assign
        while ((previousSibling = previousSibling.previousElementSibling)) {
            if (previousSibling.nodeName.toLowerCase() === element.nodeName.toLowerCase()) {
                nth++;
            }
        }
        while ((nextSibling = nextSibling.nextElementSibling)) {
            if (nextSibling.nodeName.toLowerCase() === element.nodeName.toLowerCase()) {
                nextSiblingCount++;
            }
        }
        if (nth > 1 || nextSiblingCount > 0) {
            if (nextSiblingCount === 0 && element.nodeName.toLowerCase() === 'td') {
                _xpath += '[last()]';
            }
            else {
                _xpath += `[${nth}]`;
            }
        }
    }
    if (path.length) {
        path.unshift(states.current - 1 === states.last ? '/' : '//');
    }
    path.unshift(_xpath);
    states.last = states.current;
    // if (!isStrictMode && path.length && hasOnlyOneWithXpath(`//${path.join('')}`, isFullPathMode)) {
    //   path.unshift('//')
    //   // console.log('xpath ele', element)
    //   states.finish = true
    //   return path
    // }
};
const generateElementFindRules = (element, pk = primaryKeys) => {
    const result = [];
    const level_1_path = [];
    const level_1_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_2_path = [];
    const level_2_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_3_path = [];
    const level_3_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_4_path = [];
    const level_4_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_5_path = [];
    const level_5_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    // const results: string[][] = [level_1_path, level_2_path, level_3_path, level_4_path, level_5_path]
    // 对 dom 做一次深度遍历。
    // TO DO: 需要在此基础上减少 evaluate 的检查次数，优化在大节点场景中时间复杂度仍旧过高的问题
    while (element.nodeType === Node.ELEMENT_NODE) {
        // console.log('generateElementFindRules', level_1_path, level_1_states, level_2_path, level_2_states)
        if (!level_1_states.finish) {
            calculate(element, level_1_path, default_primaryKeys, level_1_states, true);
        }
        if (!level_2_states.finish) {
            calculate(element, level_2_path, primaryKeys, level_2_states);
        }
        if (!level_3_states.finish) {
            calculate(element, level_3_path, default_primaryKeys, level_3_states);
        }
        // if (!level_4_states.finish) {
        //   calculate(element, level_4_path, primaryKeys, level_4_states)
        // }
        // if (!level_5_states.finish) {
        //   calculate(element, level_5_path, primaryKeys, level_5_states, true, true, true)
        // }
        if (level_1_states.finish &&
            // level_2_states.finish &&
            level_3_states.finish &&
            // level_4_states.finish &&
            // level_5_states.finish
            level_2_states.finish) {
            break;
        }
        element = element.parentNode;
        if (element === null) {
            console.log('ERROR: Cannot determine CSS selector. Please report the error by providing the URL and the element at https://github.com/mszeles/selenideium-element-inspector/issues');
            break;
        }
    }
    if (level_1_states.finish && level_1_path.length) {
        result.push({
            type: 'xpath',
            value: level_1_path.join(''),
        });
    }
    if (level_2_states.finish && level_2_path.length) {
        result.push({
            type: 'xpath',
            value: level_2_path.join(''),
        });
    }
    if (level_3_states.finish && level_3_path.length) {
        result.push({
            type: 'xpath',
            value: level_3_path.join(''),
        });
    }
    if (level_4_states.finish && level_4_path.length) {
        result.push({
            type: 'xpath',
            value: level_4_path.join(''),
        });
    }
    if (level_5_states.finish && level_5_path.length) {
        result.push({
            type: 'xpath',
            value: level_5_path.join(''),
        });
    }
    return result;
};
exports.generateElementFindRules = generateElementFindRules;


/***/ }),

/***/ 1615:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MouseModifiers = exports.FailType = exports.KeyEventCode = exports.MouseInteractionsEventTypes = void 0;
const tuple = (...args) => args;
exports.MouseInteractionsEventTypes = tuple('MouseUp', 'MouseMove', 'MouseDown', 'Click', 'ContextMenu', 'DblClick', 'Focus', 'Blur');
var KeyEventCode;
(function (KeyEventCode) {
    KeyEventCode["Enter"] = "Enter";
    KeyEventCode["Escape"] = "Escape";
    KeyEventCode["Tab"] = "Tab";
    KeyEventCode["ArrowLeft"] = "ArrowLeft";
    KeyEventCode["ArrowRight"] = "ArrowRight";
    KeyEventCode["ArrowUp"] = "ArrowUp";
    KeyEventCode["ArrowDown"] = "ArrowDown";
})(KeyEventCode = exports.KeyEventCode || (exports.KeyEventCode = {}));
var FailType;
(function (FailType) {
    FailType[FailType["NONODE"] = 0] = "NONODE";
    FailType[FailType["JSERROR"] = 1] = "JSERROR";
    FailType[FailType["NORULES"] = 2] = "NORULES";
    FailType[FailType["EDITORKIT"] = 3] = "EDITORKIT";
})(FailType = exports.FailType || (exports.FailType = {}));
var ResponseErrorReason;
(function (ResponseErrorReason) {
    ResponseErrorReason["Failed"] = "Failed";
    ResponseErrorReason["Aborted"] = "Aborted";
    ResponseErrorReason["TimedOut"] = "TimedOut";
    ResponseErrorReason["AccessDenied"] = "AccessDenied";
    ResponseErrorReason["ConnectionClosed"] = "ConnectionClosed";
    ResponseErrorReason["ConnectionReset"] = "ConnectionReset";
    ResponseErrorReason["ConnectionRefused"] = "ConnectionRefused";
    ResponseErrorReason["ConnectionAborted"] = "ConnectionAborted";
    ResponseErrorReason["ConnectionFailed"] = "ConnectionFailed";
    ResponseErrorReason["NameNotResolved"] = "NameNotResolved";
    ResponseErrorReason["InternetDisconnected"] = "InternetDisconnected";
    ResponseErrorReason["AddressUnreachable"] = "AddressUnreachable";
})(ResponseErrorReason || (ResponseErrorReason = {}));
var MouseModifiers;
(function (MouseModifiers) {
    MouseModifiers[MouseModifiers["Default"] = 0] = "Default";
    MouseModifiers[MouseModifiers["Alt"] = 1] = "Alt";
    MouseModifiers[MouseModifiers["Ctrl"] = 2] = "Ctrl";
    MouseModifiers[MouseModifiers["Meta"] = 4] = "Meta";
    MouseModifiers[MouseModifiers["Command"] = 4] = "Command";
    MouseModifiers[MouseModifiers["Shift"] = 8] = "Shift";
})(MouseModifiers = exports.MouseModifiers || (exports.MouseModifiers = {}));


/***/ }),

/***/ 9571:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitDragInteractions = void 0;
const utils_1 = __webpack_require__(7741);
const InitDragInteractions = ({ bindingTarget, eventCb }) => {
    const result = {
        start: { x: 0, y: 0 },
        end: { x: 0, y: 0 },
        move: [],
    };
    let dragging = false;
    const handleDragStart = (e) => {
        const { clientX, clientY } = e;
        dragging = true;
        result.start.x = clientX;
        result.start.y = clientY;
        result.move.push({ x: clientX, y: clientY });
        window.__mnt_dragging_end = undefined;
    };
    const handleMouseUp = (e) => {
        if (dragging) {
            dragging = false;
            const { clientX, clientY } = e;
            result.end.x = clientX;
            result.end.y = clientY;
            eventCb(result);
            window.__mnt_dragging_end = new Date();
        }
    };
    const handleMouseMove = (e) => {
        if (dragging) {
            const { clientX: x, clientY: y } = e;
            result.move.push({ x, y });
        }
    };
    const disposeDrag = (0, utils_1.addEventListener)('dragstart', handleDragStart, bindingTarget);
    const disposeMouseUp = (0, utils_1.addEventListener)('mouseup', handleMouseUp, bindingTarget);
    const disposeMouseMove = (0, utils_1.addEventListener)('mousemove', handleMouseMove, bindingTarget);
    return () => {
        disposeDrag();
        disposeMouseUp();
        disposeMouseMove();
    };
};
exports.InitDragInteractions = InitDragInteractions;


/***/ }),

/***/ 1631:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitFileUploadInteractions = void 0;
const utils_1 = __webpack_require__(7741);
const uuid_1 = __webpack_require__(5546);
const InitFileUploadInteractions = ({ bindingTarget, eventCb }) => {
    const handleInputChange = (e) => __awaiter(void 0, void 0, void 0, function* () {
        const { target } = e;
        if (target instanceof HTMLInputElement && target.type === 'file') {
            const { files } = target;
            if (files === null || files === void 0 ? void 0 : files.length) {
                const file = files[0];
                const reader = new FileReader();
                reader.onload = function () {
                    const source = reader.result;
                    // 读取文件后切片发送至 background
                    if (reader.readyState === FileReader.DONE && source instanceof ArrayBuffer && source.byteLength) {
                        const bufferSize = source.byteLength;
                        const chunkSize = 1024 * 1024 * 3; // 每个块的大小，
                        const numChunks = Math.ceil(file.size / chunkSize); // 总块数
                        const uuid = (0, uuid_1.v4)();
                        chrome.runtime.sendMessage({
                            name: 'transfer-file-buffer',
                            payload: {
                                mode: 'start',
                                id: uuid,
                                name: file.name,
                                type: file.type,
                                chunkSize,
                                bufferSize,
                                numChunks
                            }
                        });
                        for (let i = 0; i < numChunks; i++) {
                            const start = i * chunkSize;
                            const end = Math.min(bufferSize, start + chunkSize);
                            const chunk = source.slice(start, end);
                            chrome.runtime.sendMessage({
                                name: 'transfer-file-buffer',
                                payload: {
                                    id: uuid,
                                    mode: 'sending',
                                    start,
                                    end,
                                    chunk: new Uint8Array(chunk)
                                }
                            });
                        }
                        chrome.runtime.sendMessage({
                            name: 'transfer-file-buffer',
                            payload: {
                                id: uuid,
                                mode: 'end',
                            }
                        });
                    }
                };
                reader.readAsArrayBuffer(file);
            }
        }
    });
    const dispose = (0, utils_1.addEventListener)('change', handleInputChange, bindingTarget);
    return () => {
        dispose();
    };
};
exports.InitFileUploadInteractions = InitFileUploadInteractions;


/***/ }),

/***/ 365:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitInputInteractions = void 0;
const utils_1 = __webpack_require__(7741);
const isInputOrTextArea = (e) => e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement;
const isVsCodeIDETerminal = (e) => e instanceof HTMLTextAreaElement && e.classList.contains('xterm-helper-textarea');
const isVsCodeIDEInput = (e) => { var _a; return (_a = e === null || e === void 0 ? void 0 : e.classList) === null || _a === void 0 ? void 0 : _a.contains('monaco-mouse-cursor-text'); };
const InitInputInteractions = ({ bindingTarget, eventCb, }) => {
    let currentInputElement;
    let currentKeyboardInput = [];
    let terminalInput = [];
    let terminalInputState = 'default';
    const ignoreKey = [
        'Meta',
        'Shift',
        'Control',
        'Alt',
        'Escape',
        'CapsLock',
        'ArrowLeft',
        'ArrowRight',
        'ArrowUp',
        'ArrowDown',
    ];
    const ignoreKey_ide = [
        'Meta',
        'Shift',
        'Control',
        'Alt',
        'Escape',
        'CapsLock',
        'ArrowLeft',
        'ArrowRight',
        'ArrowUp',
        'ArrowDown',
    ];
    const handleKeyDownEvent = (e) => {
        const element = e.target;
        // 在 Cloud IDE 的输入场景下
        if (isVsCodeIDEInput(element)) {
            return;
        }
        else if (isVsCodeIDETerminal(element)) {
            // 暂时忽略一些功能键
            if (ignoreKey.includes(e.key) || e.ctrlKey || e.metaKey || e.altKey) {
                return;
            }
            else if (e.key === 'Backspace' && terminalInput.length) {
                // 删除输入内容
                terminalInput.pop();
            }
            else if (e.key === 'Enter' && terminalInput.length) {
                // 结束录制
                eventCb({
                    target: element ? element : undefined,
                    timestamp: new Date().getTime(),
                    type: 'finish',
                    value: terminalInput.join(''),
                });
                terminalInput = [];
                terminalInputState = 'finish';
            }
            else {
                if (terminalInputState === 'default' || terminalInputState === 'finish') {
                    terminalInputState = 'start';
                    eventCb({
                        target: element ? element : undefined,
                        timestamp: new Date().getTime(),
                        type: 'start',
                    });
                }
                terminalInput.push(e.key);
            }
            return;
        }
        else if ((element instanceof HTMLElement && element.isContentEditable) || isInputOrTextArea(element)) {
            if (!currentInputElement) {
                currentKeyboardInput = [];
                eventCb({
                    target: element ? element : undefined,
                    timestamp: new Date().getTime(),
                    type: 'start',
                });
            }
            currentInputElement = e.target;
            const isComposing = e.isComposing || e.keyCode === 229;
            const isCapsLock = e.getModifierState('CapsLock');
            const isShift = e.shiftKey || e.getModifierState('Shift');
            currentKeyboardInput.push({
                type: 'down',
                isShift,
                isCapsLock,
                isComposing,
                keyCode: e.keyCode,
                key: e.key,
                time: new Date().getTime(),
            });
        }
        console.log('handleKeyDownEvent !!!', e, currentInputElement);
    };
    const handleKeyUpEvent = (e) => {
        console.log('handleKeyUpEvent !!!', e, currentInputElement);
        const element = e.target;
        if (isVsCodeIDETerminal(element) || isVsCodeIDEInput(element)) {
            return;
        }
        if (element && ((element instanceof HTMLElement && element.isContentEditable) || isInputOrTextArea(element))) {
            const isComposing = e.isComposing || e.keyCode === 229;
            const isCapsLock = e.getModifierState('CapsLock');
            const isShift = e.shiftKey || e.getModifierState('Shift');
            const isContentEditable = element instanceof HTMLElement && element.isContentEditable;
            currentKeyboardInput.push({
                type: 'up',
                isShift,
                isCapsLock,
                isComposing,
                keyCode: e.keyCode,
                key: e.key,
                time: new Date().getTime(),
                value: isContentEditable ? element.textContent : element.value,
            });
        }
    };
    const handleBlurEvent = (e) => {
        if (isVsCodeIDETerminal(e.target) || isVsCodeIDEInput(e.target)) {
            return;
        }
        console.log('handleBlurEvent !!!', e, currentInputElement);
        if (currentInputElement && e.target === currentInputElement) {
            eventCb({
                target: currentInputElement,
                timestamp: new Date().getTime(),
                type: 'finish',
                value: isInputOrTextArea(currentInputElement) ? currentInputElement.value : currentInputElement.textContent,
                log: currentKeyboardInput,
            });
            currentInputElement = undefined;
            currentKeyboardInput = [];
        }
    };
    const handleClick = (e) => {
        if (isVsCodeIDETerminal(e.target) || isVsCodeIDEInput(e.target)) {
            return;
        }
        console.log('handleClick !!!', e, currentInputElement);
        if (currentInputElement && currentInputElement !== e.target) {
            eventCb({
                target: currentInputElement,
                timestamp: new Date().getTime(),
                type: 'finish',
                value: isInputOrTextArea(currentInputElement) ? currentInputElement.value : currentInputElement.textContent,
                log: currentKeyboardInput,
            });
            currentInputElement = undefined;
            currentKeyboardInput = [];
        }
    };
    const handleScroll = (e) => {
        if (isVsCodeIDETerminal(e.target) || isVsCodeIDEInput(e.target)) {
            return;
        }
        console.log('handleScroll !!!', e, currentInputElement);
        if (currentInputElement && currentInputElement !== e.target) {
            eventCb({
                target: currentInputElement,
                timestamp: new Date().getTime(),
                type: 'finish',
                value: isInputOrTextArea(currentInputElement) ? currentInputElement.value : currentInputElement.textContent,
                log: currentKeyboardInput,
            });
            currentInputElement = undefined;
            currentKeyboardInput = [];
        }
    };
    let currentIDEInputElement = null;
    let IDE_Input_Val = '';
    let IS_IDE_Inputing = false;
    let IS_Composition = false;
    let IS_Select_All = false;
    let Find_In_CompositionEnd = false;
    const finishIDERecord = () => {
        if (currentIDEInputElement) {
            eventCb({
                target: currentIDEInputElement,
                timestamp: new Date().getTime(),
                type: 'finish',
                value: IDE_Input_Val,
            });
            currentIDEInputElement = null;
            IDE_Input_Val = '';
            IS_IDE_Inputing = false;
            IS_Composition = false;
            IS_Select_All = false;
            Find_In_CompositionEnd = false;
        }
    };
    const handleCompositionStart = (e) => {
        if (IS_IDE_Inputing) {
            IS_Composition = true;
        }
    };
    const handleCompositionEnd = (e) => {
        IS_Composition = false;
        // 记录中文输入
        if (e.data) {
            IDE_Input_Val += e.data;
        }
        if (Find_In_CompositionEnd) {
            finishIDERecord();
        }
    };
    const handleClickWithIDE = (e) => {
        finishIDERecord();
    };
    // 输入提示点击后，输入行为终止
    const handleMousedownWithIDE = (e) => {
        const suggestContainer = document.querySelector('.editor-instance .editor-widget.suggest-widget');
        const isSuggestClick = suggestContainer === null || suggestContainer === void 0 ? void 0 : suggestContainer.contains(e.target);
        if (isSuggestClick) {
            finishIDERecord();
        }
    };
    // 只处理 IDE 场景下的逻辑
    const handleIDEKeyDown = (e) => {
        const element = e.target;
        // 在 Cloud IDE 的输入场景下
        if (isVsCodeIDEInput(element)) {
            if (IS_Composition || e.keyCode === 229) {
                // 一上来就是中文输入
                if (!currentIDEInputElement) {
                    currentIDEInputElement = e.target;
                    IS_IDE_Inputing = true;
                    // 开启录制
                    eventCb({
                        target: element ? element : undefined,
                        timestamp: new Date().getTime(),
                        type: 'start',
                    });
                }
            }
            else if (e.code === 'Enter' && IS_Composition) {
                // 在中文输入中直接通过回车发送数据
                Find_In_CompositionEnd = true;
            }
            else if ((e.code === 'ArrowLeft' || e.code === 'ArrowRight' || e.code === 'ArrowUp' || e.code === 'ArrowDown') &&
                !IS_Composition) {
                // 非中文输入情况下使用小键盘切换方向需要中断输入
                finishIDERecord();
            }
            else if (e.code === 'Tab' && !IS_Composition) {
                finishIDERecord();
            }
            else if (e.code === 'Enter' && !IS_Composition) {
                // 英文输入结尾的情况下，通过 回车可以直接结束
                finishIDERecord();
            }
            else if (e.metaKey && e.code === 'KeyA') {
                // 用户通过快捷键全选了
                IS_Select_All = true;
            }
            else if (e.code === 'Backspace') {
                if (IS_Select_All) {
                    // 全选情况下的清空
                    IDE_Input_Val = '';
                    IS_Select_All = false;
                }
                else {
                    // 只删除一位
                    IDE_Input_Val = IDE_Input_Val.slice(0, -1);
                }
                // todo 用户通过点击选择如何处理？
            }
            else {
                // 忽略一些系统级的快捷键
                if (ignoreKey_ide.includes(e.key) || e.ctrlKey || e.metaKey || e.altKey) {
                    return;
                }
                if (!currentIDEInputElement) {
                    currentIDEInputElement = e.target;
                    IS_IDE_Inputing = true;
                    // 开启录制
                    eventCb({
                        target: element ? element : undefined,
                        timestamp: new Date().getTime(),
                        type: 'start',
                    });
                }
                IDE_Input_Val += e.key;
            }
        }
    };
    const disposeKeyDown = (0, utils_1.addEventListener)('keydown', handleKeyDownEvent, bindingTarget);
    const disposeKeyUp = (0, utils_1.addEventListener)('keyup', handleKeyUpEvent, bindingTarget);
    const disposeBlur = (0, utils_1.addEventListener)('blur', handleBlurEvent, bindingTarget);
    const disposeClick = (0, utils_1.addEventListener)('click', handleClick, bindingTarget);
    const disposeScroll = (0, utils_1.addEventListener)('scroll', handleScroll, bindingTarget);
    const disposeCompositionStart = (0, utils_1.addEventListener)('compositionstart', handleCompositionStart, bindingTarget);
    const disposeCompositionEnd = (0, utils_1.addEventListener)('compositionend', handleCompositionEnd, bindingTarget);
    const disposeIDEKeyDown = (0, utils_1.addEventListener)('keydown', handleIDEKeyDown, bindingTarget);
    const disposeClickWithIDE = (0, utils_1.addEventListener)('click', handleClickWithIDE, bindingTarget);
    const disposeMousedownWithIDE = (0, utils_1.addEventListener)('mousedown', handleMousedownWithIDE, bindingTarget);
    return () => {
        disposeKeyDown();
        disposeKeyUp();
        disposeBlur();
        disposeClick();
        disposeScroll();
        disposeCompositionStart();
        disposeCompositionEnd();
        disposeIDEKeyDown();
        disposeClickWithIDE();
        disposeMousedownWithIDE();
    };
};
exports.InitInputInteractions = InitInputInteractions;


/***/ }),

/***/ 4902:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitKeyUpInteractions = void 0;
const interface_1 = __webpack_require__(1615);
const utils_1 = __webpack_require__(7741);
// const isVsCodeIDEInput = (e) => e instanceof HTMLTextAreaElement && e.classList.contains('monaco-mouse-cursor-text')
// const pending: {
//   timeout?: ReturnType<typeof setTimeout>
//   inputs?: any[]
// } = { inputs: [] }
const InitKeyUpInteractions = ({ bindingTarget, eventCb }) => {
    let IS_Composition = false;
    const handleKeyUpEvent = (e) => {
        const keyBoardEvent = e;
        if (!keyBoardEvent.target) {
            return;
        }
        // // 编辑器场景使用 keydown 事件，用户点击按键不松时会多次触发 keydown，不会触发 keyup，此时会有多次的输入需要记录
        // if (isVsCodeIDEInput(keyBoardEvent.target)) {
        //   return
        // }
        if (keyBoardEvent.code !== interface_1.KeyEventCode.Enter &&
            keyBoardEvent.code !== interface_1.KeyEventCode.Escape &&
            keyBoardEvent.code !== interface_1.KeyEventCode.Tab &&
            keyBoardEvent.code !== interface_1.KeyEventCode.ArrowDown &&
            keyBoardEvent.code !== interface_1.KeyEventCode.ArrowUp &&
            keyBoardEvent.code !== interface_1.KeyEventCode.ArrowLeft &&
            keyBoardEvent.code !== interface_1.KeyEventCode.ArrowRight) {
            return;
        }
        // 中文输入下不生成快捷键操作
        if ((keyBoardEvent.code === interface_1.KeyEventCode.ArrowDown ||
            keyBoardEvent.code === interface_1.KeyEventCode.ArrowUp ||
            keyBoardEvent.code === interface_1.KeyEventCode.ArrowLeft ||
            keyBoardEvent.code === interface_1.KeyEventCode.ArrowRight) &&
            (keyBoardEvent.keyCode === 229 || IS_Composition)) {
            return;
        }
        eventCb({
            target: keyBoardEvent.target,
            keyCode: keyBoardEvent.keyCode,
            code: keyBoardEvent.code,
        });
    };
    const handleCompositionStart = (e) => {
        IS_Composition = true;
    };
    const handleCompositionEnd = (e) => {
        IS_Composition = false;
    };
    // const handleKeyDownEvent = (e: Event) => {
    //   const keyBoardEvent = e as KeyboardEvent
    //   if (!keyBoardEvent.target) {
    //     return
    //   }
    //   const target = keyBoardEvent.target as Element
    //   if (isVsCodeIDEInput(target)) {
    //     const { altKey, ctrlKey, shiftKey, metaKey, code, key, keyCode } = keyBoardEvent
    //     if (ctrlKey || metaKey) {
    //       // 快捷键会在 shortcut-keys 中单独记录
    //       return
    //     }
    //     if (altKey) {
    //       // altKey 既可以是输入，也可以是快捷键
    //     }
    //     if (shiftKey) {
    //       // 如果 shift + f1~f10 就是快捷键
    //     }
    //     if (pending?.timeout) {
    //       clearTimeout(pending.timeout)
    //     }
    //     pending.inputs?.push({
    //       target,
    //       altKey,
    //       ctrlKey,
    //       shiftKey,
    //       metaKey,
    //       code,
    //       key,
    //       keyCode,
    //     })
    //     pending.timeout = setTimeout(() => {
    //       eventCb({
    //         target,
    //         inputs: pending.inputs,
    //       })
    //       pending.inputs = []
    //       clearTimeout(pending.timeout)
    //     }, 1000)
    //   }
    // }
    const disposeKeyUp = (0, utils_1.addEventListener)('keyup', handleKeyUpEvent, bindingTarget);
    const disposeCompositionStart = (0, utils_1.addEventListener)('compositionstart', handleCompositionStart, bindingTarget);
    const disposeCompositionEnd = (0, utils_1.addEventListener)('compositionend', handleCompositionEnd, bindingTarget);
    // const disposeKeyDown = addEventListener('keydown', handleKeyDownEvent, document)
    return () => {
        disposeKeyUp();
        disposeCompositionStart();
        disposeCompositionEnd();
        // disposeKeyDown()
    };
};
exports.InitKeyUpInteractions = InitKeyUpInteractions;


/***/ }),

/***/ 1209:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitMouseInteractionsEvent = void 0;
/* eslint-disable max-lines-per-function */
const interface_1 = __webpack_require__(1615);
const utils_1 = __webpack_require__(7741);
let pendingClick, pendingMouseUp, pendingMockClick, latestMouseDownEvent;
let inVsCodeIDE;
const InitMouseInteractionsEvent = ({ bindingTarget, blockClass, blockSelector, eventCb, }) => {
    const disposeFunctions = [];
    const getHandler = (eventKey) => (event) => {
        var _a;
        const target = (0, utils_1.getEventTarget)(event);
        if (!target) {
            return;
        }
        // 在黑名单里的元素要忽略一下
        if ((0, utils_1.isBlocked)(target, blockClass, blockSelector, true)) {
            return;
        }
        const e = (0, utils_1.isTouchEvent)(event) ? event.changedTouches[0] : event;
        if (!e) {
            return;
        }
        const dragEndTime = (_a = window.__mnt_dragging_end) !== null && _a !== void 0 ? _a : 0;
        if (Date.now() - dragEndTime < 500) {
            return;
        }
        ;
        window.__mnt_dragging_end = undefined;
        const clickAsHover = window.__clickAsHover;
        const { clientX, clientY } = e;
        if (clickAsHover === true && eventKey === 'Click') {
            ;
            e.stopPropagation();
            e.preventDefault();
            window.__clickAsHover = false;
        }
        const clickEventRecord = (_event) => {
            const { altKey, ctrlKey, shiftKey, metaKey, clientX: _clientX, clientY: _clientY, target: _target, } = _event;
            const vscodeContainer = document.querySelector('.editor-instance');
            inVsCodeIDE = inVsCodeIDE !== null && inVsCodeIDE !== void 0 ? inVsCodeIDE : vscodeContainer === null || vscodeContainer === void 0 ? void 0 : vscodeContainer.contains(_target);
            const modifiers = altKey
                ? interface_1.MouseModifiers.Alt
                : ctrlKey
                    ? interface_1.MouseModifiers.Ctrl
                    : metaKey
                        ? interface_1.MouseModifiers.Meta
                        : shiftKey
                            ? interface_1.MouseModifiers.Shift
                            : interface_1.MouseModifiers.Default;
            eventCb({
                type: clickAsHover ? 'Hover' : 'Click',
                target: inVsCodeIDE ? undefined : _target,
                x: _clientX,
                y: _clientY,
                useOriginPoint: inVsCodeIDE,
                modifiers,
                timestamp: new Date().getTime(),
            });
            inVsCodeIDE = undefined;
        };
        switch (event.detail) {
            case 1:
                if (eventKey === 'MouseUp') {
                    eventCb({
                        type: eventKey,
                        target,
                        x: clientX,
                        y: clientY,
                        timestamp: new Date().getTime(),
                    });
                    // const matched = matchMouseUpAndMouseDown(event as MouseEvent, latestMouseDownEvent as MouseEvent)
                    // if (matched) {
                    //   pendingMockClick && clearTimeout(pendingMockClick)
                    //   pendingMockClick = setTimeout(() => {
                    //     clickEventRecord(latestMouseDownEvent)
                    //   }, 500)
                    // }
                }
                else if (eventKey === 'Click') {
                    // pendingMockClick && clearTimeout(pendingMockClick)
                    // pendingClick && clearTimeout(pendingClick)
                    // // 等待确认是否是 dblclick
                    // pendingClick = setTimeout(() => {
                    //   clickEventRecord(event as MouseEvent)
                    // }, 500)
                    clickEventRecord(event);
                }
                else {
                    // mousedown 事件
                    latestMouseDownEvent = event;
                    const vscodeContainer = document.querySelector('.editor-instance');
                    inVsCodeIDE = vscodeContainer === null || vscodeContainer === void 0 ? void 0 : vscodeContainer.contains(target);
                    if (!inVsCodeIDE && vscodeContainer) {
                        const shadowRootHost = vscodeContainer.querySelector('.editor-instance div.shadow-root-host');
                        const shadowRoots = (0, utils_1.findShadowRoots)(shadowRootHost);
                        if (shadowRoots.length) {
                            const shadowRoot = shadowRoots[0];
                            inVsCodeIDE = shadowRoot.contains(target);
                        }
                    }
                    eventCb({
                        type: eventKey,
                        target,
                        x: clientX,
                        y: clientY,
                        timestamp: new Date().getTime(),
                    });
                }
                break;
            case 2:
            // pendingMockClick && clearTimeout(pendingMockClick)
            // pendingClick && clearTimeout(pendingClick)
            // pendingMouseUp && clearTimeout(pendingMouseUp)
            // // 过滤掉第二次的点击事件
            // if (eventKey === 'Click') {
            //   return
            // }
            // eventCb({
            //   type: 'DblClick',
            //   target,
            //   x: clientX,
            //   y: clientY,
            //   timestamp: new Date().getTime(),
            // })
            // break
            default:
                eventCb({
                    type: eventKey,
                    target,
                    x: clientX,
                    y: clientY,
                    timestamp: new Date().getTime(),
                });
                break;
        }
    };
    interface_1.MouseInteractionsEventTypes.forEach((eventKey) => {
        const eventName = eventKey.toLowerCase();
        const handler = getHandler(eventKey);
        disposeFunctions.push((0, utils_1.addEventListener)(eventName, handler, bindingTarget));
    });
    return () => {
        disposeFunctions.forEach((dispose) => dispose());
    };
};
exports.InitMouseInteractionsEvent = InitMouseInteractionsEvent;
// export const initMouseMoveEvent = ({
//   mousemoveCb,
//   sampling,
//   doc,
//   mirror,
// }: any) => {
//   const threshold =
//     typeof sampling.mousemove === 'number' ? sampling.mousemove : 50;
//   const callbackThreshold =
//     typeof sampling.mousemoveCallback === 'number'
//       ? sampling.mousemoveCallback
//       : 500;
//   let positions: mousePosition[] = [];
//   let timeBaseline: number | null;
//   const wrappedCb = throttle(
//     (
//       source:
//         | IncrementalSource.MouseMove
//         | IncrementalSource.TouchMove
//         | IncrementalSource.Drag,
//     ) => {
//       const totalOffset = Date.now() - timeBaseline!;
//       mousemoveCb(
//         positions.map(p => {
//           p.timeOffset -= totalOffset;
//           return p;
//         }),
//         source,
//       );
//       positions = [];
//       timeBaseline = null;
//     },
//     callbackThreshold,
//   );
//   const updatePosition = throttle<MouseEvent>(
//     evt => {
//       const target = getEventTarget(evt);
//       const { clientX, clientY } = isTouchEvent(evt)
//         ? evt.changedTouches[0]
//         : evt;
//       if (!timeBaseline) {
//         timeBaseline = Date.now();
//       }
//       positions.push({
//         x: clientX,
//         y: clientY,
//         target,
//         timeOffset: Date.now() - timeBaseline,
//       });
//       // it is possible DragEvent is undefined even on devices
//       // that support event 'drag'
//       wrappedCb(
//         typeof DragEvent !== 'undefined' && evt instanceof DragEvent
//           ? IncrementalSource.Drag
//           : evt instanceof MouseEvent
//           ? IncrementalSource.MouseMove
//           : IncrementalSource.TouchMove,
//       );
//     },
//     threshold,
//     {
//       trailing: false,
//     },
//   );
//   const handlers = [
//     on('mousemove', updatePosition, doc),
//   ];
//   return () => {
//     handlers.forEach(h => h());
//   };
// };


/***/ }),

/***/ 8840:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitShortcutInteractions = void 0;
const utils_1 = __webpack_require__(7741);
const InitShortcutInteractions = ({ bindingTarget, eventCb }) => {
    let metaEnable, ctrlEnable, shiftEnable;
    let keys = [];
    const handleKeyDownEvent = (e) => {
        if (e.metaKey) {
            metaEnable = true;
        }
        else if (e.ctrlKey) {
            ctrlEnable = true;
        }
        else if (e.shiftKey) {
            shiftEnable = true;
        }
        if (metaEnable || ctrlEnable) {
            keys.push({ key: e.key, keyCode: e.keyCode });
        }
    };
    const handleKeyUpEvent = (e) => {
        if (e.key === 'Meta') {
            metaEnable = false;
            console.log('shortcut - metaKey', keys);
        }
        else if (e.key === 'Control') {
            ctrlEnable = false;
            console.log('shortcut - ctrlKey', keys);
        }
        else if (e.key === 'Shift') {
            shiftEnable = false;
        }
        if (!(metaEnable | ctrlEnable)) {
            // 只有 meta/control 键时不录制为快捷键
            if (keys.length > 1) {
                // 结束采集上报
                eventCb({
                    keyPaths: keys,
                });
            }
            keys = [];
        }
    };
    const disposeKeyUp = (0, utils_1.addEventListener)('keyup', handleKeyUpEvent, bindingTarget);
    const disposeKeyDown = (0, utils_1.addEventListener)('keydown', handleKeyDownEvent, bindingTarget);
    return () => {
        disposeKeyUp();
        disposeKeyDown();
    };
};
exports.InitShortcutInteractions = InitShortcutInteractions;


/***/ }),

/***/ 3461:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InitWheelEvent = void 0;
const utils_1 = __webpack_require__(7741);
const InitWheelEvent = ({ bindingTarget, eventCb }) => {
    const handleWheel = (event) => {
        eventCb({
            value: {
                deltaX: event.deltaX,
                deltaY: event.deltaY,
            },
            mousePoint: {
                x: event.x,
                y: event.y,
            },
            timestamp: new Date().getTime(),
        });
    };
    const dispose = (0, utils_1.addEventListener)('wheel', handleWheel, bindingTarget);
    return () => dispose();
};
exports.InitWheelEvent = InitWheelEvent;


/***/ }),

/***/ 982:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.initEventHooks = void 0;
const mouse_1 = __webpack_require__(1209);
// import { InitInputInteractions } from './hooks/input'
// import { InitEditorKitInteractions } from './hooks/editor-kit'
const keyup_1 = __webpack_require__(4902);
// import { InitTooltipInteractions } from './hooks/tooltip'
const input_v2_1 = __webpack_require__(365);
const drag_1 = __webpack_require__(9571);
const file_1 = __webpack_require__(1631);
const wheel_1 = __webpack_require__(3461);
const shortcut_key_1 = __webpack_require__(8840);
const initEventHooks = ({ bindingTarget, blockClass, blockSelector, mouseEventCb, scrollEventCb, 
// inputEventCb,
inputEventCbV2, 
// editorKitEventCb,
keyupEventCb, tooltipEventCb, dragEventCb, fileUploadEventCb, wheelEventCb, shortcutKeyEventCb, }) => {
    const disposeFunctions = [
        (0, mouse_1.InitMouseInteractionsEvent)({
            bindingTarget,
            blockClass,
            blockSelector,
            eventCb: mouseEventCb,
        }),
        /* InitScrollEvent({
          blockClass,
          blockSelector,
          eventCb: scrollEventCb,
        }), */
        // InitInputInteractions({
        //   blockClass,
        //   blockSelector,
        //   eventCb: inputEventCb,
        // }),
        // InitEditorKitInteractions({ eventCb: editorKitEventCb }),
        (0, keyup_1.InitKeyUpInteractions)({
            bindingTarget,
            eventCb: keyupEventCb,
        }),
        // InitTooltipInteractions({
        //   eventCb: tooltipEventCb,
        // }),
        (0, input_v2_1.InitInputInteractions)({ bindingTarget, eventCb: inputEventCbV2 }),
        (0, drag_1.InitDragInteractions)({ bindingTarget, eventCb: dragEventCb }),
        (0, file_1.InitFileUploadInteractions)({ bindingTarget, eventCb: fileUploadEventCb }),
        (0, wheel_1.InitWheelEvent)({ bindingTarget, eventCb: wheelEventCb }),
        (0, shortcut_key_1.InitShortcutInteractions)({ bindingTarget, eventCb: shortcutKeyEventCb }),
    ];
    return () => {
        disposeFunctions.forEach((dispose) => dispose());
    };
};
exports.initEventHooks = initEventHooks;


/***/ }),

/***/ 2136:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.initShadowEvent = exports.initEvent = void 0;
const utils_1 = __webpack_require__(7741);
const event_hooks_1 = __webpack_require__(982);
// import { initAjaxHook } from './xhr-hook'
const mutation_1 = __webpack_require__(447);
function getFrameUrl() {
    var _a, _b;
    console.log('getFrameUrl');
    if (window.self !== window.top) {
        return ((_b = (_a = window === null || window === void 0 ? void 0 : window.__mnt) === null || _a === void 0 ? void 0 : _a.uri) !== null && _b !== void 0 ? _b : `${window.location.protocol}//${window.location.hostname}${window.location.pathname}`);
    }
    else {
        return undefined;
    }
}
function getFrameID() {
    var _a, _b;
    return (_b = (_a = window === null || window === void 0 ? void 0 : window.__mnt) === null || _a === void 0 ? void 0 : _a.fid) !== null && _b !== void 0 ? _b : 0;
}
const disposeFunctions = [];
const initEvent = (bindingTarget, blockClass = 'rr-class-xx', blockSelector = 'rr-class-xx', mouseEventCb, scrollEventCb, inputEventCb) => {
    disposeFunctions.push((0, event_hooks_1.initEventHooks)({
        bindingTarget,
        blockClass,
        blockSelector,
        mouseEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            var _a, _b;
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target) && payload.type !== 'Hover') {
                return;
            }
            let find;
            if (target) {
                // 如果是 shadowRoot 并且是 clickAsHover 就不计算控件树了
                if (utils_1.shadowRootHosts.has(target) && payload.type === 'Hover') {
                    find = undefined;
                }
                else {
                    (0, utils_1.setOnlyE2EID)();
                    find = (0, utils_1.getFindRules)(target);
                }
            }
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: payload.type,
                        source: {
                            xpath: ((_a = find === null || find === void 0 ? void 0 : find.ruls) === null || _a === void 0 ? void 0 : _a.length) ? find === null || find === void 0 ? void 0 : find.ruls[0].value : '暂无',
                            x: payload.x,
                            y: payload.y,
                            timestamp: payload.timestamp,
                            findRules: find === null || find === void 0 ? void 0 : find.ruls,
                            modifiers: payload === null || payload === void 0 ? void 0 : payload.modifiers,
                            useOriginPoint: ((_b = find === null || find === void 0 ? void 0 : find.ruls) === null || _b === void 0 ? void 0 : _b.length) ? payload === null || payload === void 0 ? void 0 : payload.useOriginPoint : true,
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
            if (mouseEventCb) {
                mouseEventCb(payload);
            }
        }),
        inputEventCbV2: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            var _c;
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target)) {
                return;
            }
            (0, utils_1.setOnlyE2EID)();
            const find = (0, utils_1.getFindRules)(target);
            (0, utils_1.postTwoMessage)(`input(输入值：${payload.value})`, find.ruls);
            console.log('inputEventCbV2', payload);
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'input',
                        source: {
                            xpath: ((_c = find === null || find === void 0 ? void 0 : find.ruls) === null || _c === void 0 ? void 0 : _c.length) ? find === null || find === void 0 ? void 0 : find.ruls[0].value : '暂无',
                            findRules: find === null || find === void 0 ? void 0 : find.ruls,
                            timestamp: payload.timestamp,
                            type: payload.type,
                            value: payload.value,
                            log: payload.log,
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
            if (inputEventCb) {
                inputEventCb(payload);
            }
        }),
        scrollEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            var _d;
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target)) {
                return;
            }
            (0, utils_1.setOnlyE2EID)();
            const find = (0, utils_1.getFindRules)(target);
            (0, utils_1.postTwoMessage)(`收到事件scroll的上报,rules:`, find.ruls);
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'scroll',
                        source: {
                            value: payload.value,
                            xpath: ((_d = find === null || find === void 0 ? void 0 : find.ruls) === null || _d === void 0 ? void 0 : _d.length) ? find === null || find === void 0 ? void 0 : find.ruls[0].value : '暂无',
                            timestamp: payload.timestamp,
                            findRules: find === null || find === void 0 ? void 0 : find.ruls,
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
            if (scrollEventCb) {
                scrollEventCb(payload);
            }
        }),
        keyupEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target)) {
                return;
            }
            const find = (0, utils_1.getFindRules)(target);
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'keyup',
                        source: {
                            findRules: find.ruls,
                            value: {
                                inputs: payload.inputs,
                                code: payload.code,
                                keyCode: payload.keyCode,
                            },
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
        }),
        tooltipEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target)) {
                return;
            }
            const find = (0, utils_1.getFindRules)(target);
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'popup',
                        source: {
                            findRules: find.ruls,
                        },
                    },
                },
            });
        }),
        dragEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'drag',
                        source: Object.assign(Object.assign({}, payload), { frame: {
                                url: getFrameUrl(),
                            } }),
                    },
                },
            });
        }),
        fileUploadEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            var _e;
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            const target = payload.target;
            if (utils_1.shadowRootHosts.has(target)) {
                return;
            }
            const find = (0, utils_1.getFindRules)(target);
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'file-upload',
                        source: {
                            xpath: ((_e = find === null || find === void 0 ? void 0 : find.ruls) === null || _e === void 0 ? void 0 : _e.length) ? find === null || find === void 0 ? void 0 : find.ruls[0].value : '暂无',
                            findRules: find === null || find === void 0 ? void 0 : find.ruls,
                            timestamp: payload.timestamp,
                            type: payload.type,
                            value: payload.value,
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
        }),
        wheelEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            yield chrome.runtime.sendMessage({
                type: 'mnt-rr-event-capture',
                frameID: getFrameID(),
                data: {
                    type: 'rr_event_capture',
                    payload: {
                        type: 'wheel',
                        source: {
                            timestamp: payload.timestamp,
                            value: payload.value,
                            mousePoint: payload.mousePoint,
                            frame: {
                                url: getFrameUrl(),
                            },
                        },
                    },
                },
            });
        }),
        shortcutKeyEventCb: (payload) => __awaiter(void 0, void 0, void 0, function* () {
            const pauseRecording = window.__pauseRecording;
            if (pauseRecording) {
                return;
            }
            if (payload.keyPaths.length) {
                yield chrome.runtime.sendMessage({
                    type: 'mnt-rr-event-capture',
                    frameID: getFrameID(),
                    data: {
                        type: 'rr_event_capture',
                        payload: {
                            type: 'shortcut-key',
                            source: {
                                keyPaths: payload.keyPaths || [],
                                frame: {
                                    url: getFrameUrl(),
                                },
                            },
                        },
                    },
                });
            }
        }),
    }));
};
exports.initEvent = initEvent;
const initShadowEvent = (element = document.documentElement) => {
    const shadowRoots = (0, utils_1.findShadowRoots)(element);
    shadowRoots.forEach((shadowRoot) => {
        if (!shadowRoot.__bound_event) {
            shadowRoot.__bound_event = true;
            (0, exports.initEvent)(shadowRoot);
        }
    });
};
exports.initShadowEvent = initShadowEvent;
const init = (blockClass, blockSelector, mouseEventCb, scrollEventCb, inputEventCb) => {
    (0, exports.initEvent)(document, blockClass, blockSelector, mouseEventCb, scrollEventCb, inputEventCb);
    disposeFunctions.push((0, mutation_1.initMutation)());
    (0, exports.initShadowEvent)();
};
const record = ({ blockClass = 'rr-class-xx', blockSelector = 'rr-class-xx', mouseEventCb, scrollEventCb, inputEventCb, }) => {
    if (window.__rr_record_init) {
        console.log('record is injected', window);
        return;
    }
    console.log('record init', window);
    window.__rr_record_init = true;
    if (window.__rr_record_init_count !== undefined) {
        ;
        window.__rr_record_init_count += 1;
    }
    else {
        ;
        window.__rr_record_init_count = 1;
    }
    try {
        if (document.readyState === 'complete') {
            init(blockClass, blockSelector, mouseEventCb, scrollEventCb, inputEventCb);
        }
        else {
            disposeFunctions.push((0, utils_1.addEventListener)('load', () => {
                init(blockClass, blockSelector, mouseEventCb, scrollEventCb, inputEventCb);
            }, window));
        }
    }
    catch (error) {
        (0, utils_1.postLogMessage)('Erorr', `${error}`);
    }
    return () => {
        disposeFunctions.forEach((dispose) => dispose());
    };
};
// const createStatusIcon = () => {
//   const statusBar = document.createElement('div')
//   statusBar.setAttribute(
//     'style',
//     `position: fixed;right: 50px;bottom: 100px;background: red;width: 50px;height: 50px;border-radius: 50px;line-height: 50px;color: #fff;cursor: pointer;`,
//   )
//   statusBar.innerHTML = '<span>结束录制</span>'
//   document.body.appendChild(statusBar)
//   statusBar.addEventListener('click', async (e: MessageEvent) => {
//     await chrome.runtime.sendMessage({
//       type: 'stop-record',
//     })
//   })
// }
const addRecordingMask = () => {
    const mask = document.createElement('div');
    mask.setAttribute('style', 'position: fixed; top: 0; width: 100vw; height: 100vh; z-index: 999999; background: rgba(0, 0, 0, 0); text-align: center; line-height: 100vh; color: #333');
    mask.setAttribute('id', 'rr-recording-mask');
    document.body.appendChild(mask);
};
const removeRecordingMask = () => {
    const mask = document.getElementById('rr-recording-mask');
    if (!mask) {
        return;
    }
    document.body.removeChild(mask);
};
chrome.runtime.onMessage.addListener(function (request, sender, sendMessage) {
    console.log('setProcessing', request);
    if (request.type === 'record-processing') {
        if (request.data) {
            addRecordingMask();
        }
        else {
            removeRecordingMask();
        }
    }
    if (request.type === 'mtn-rr-do-snapshot-with-record' && window.self === window.top) {
        (0, utils_1.postLogMessage)('Info', '开始生成控件树....');
        const domSnapshot = [];
        const frames = [];
        console.log('deepTravalSal');
        (0, utils_1.setOnlyE2EID)();
        try {
            (0, utils_1.deepTravalSal)(window.document.body, domSnapshot, frames);
            console.log('deepTravalSal.ends', domSnapshot, frames);
            sendMessage(domSnapshot);
        }
        catch (error) {
            console.log('deepTravalSal.error', error);
        }
    }
    else if ((request === null || request === void 0 ? void 0 : request.action) === 'do-snapshot-in-frame-with-record') {
        console.log('handleSnapshot - do-snapshot-in-frame-handle - start');
        try {
            const domSnapshot = [];
            (0, utils_1.deepTravalSal)(window.document.body, domSnapshot);
            sendMessage(domSnapshot);
            console.log('handleSnapshot - do-snapshot-in-frame-handle - end');
        }
        catch (e) {
            console.log('handleSnapshot - do-snapshot-in-frame-handle - fail', e.message);
            sendMessage(undefined);
        }
    }
});
chrome.runtime.onMessage.addListener(function (request, sender, sendMessage) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function* () {
        console.log('clickAsHover', request);
        if (request.type === 'clickAsHover') {
            ;
            window.__clickAsHover = (_a = (yield chrome.storage.session.get(['clickAsHover']))) === null || _a === void 0 ? void 0 : _a.clickAsHover;
        }
        if (request.type === 'pauseRecording') {
            ;
            window.__pauseRecording = (_b = (yield chrome.storage.session.get(['pauseRecording']))) === null || _b === void 0 ? void 0 : _b.pauseRecording;
        }
    });
});
record({});


/***/ }),

/***/ 447:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.initMutation = void 0;
/* eslint-disable no-console */
const utils_1 = __webpack_require__(7741);
const index_1 = __webpack_require__(2136);
const options = {
    childList: true,
    subtree: true,
    attributes: true,
    attributeOldValue: true,
    attributeFilter: [],
    characterData: true,
    characterDataOldValue: true, // 在characterData属性已经设为true的前提下,将发生变化characterData节点之前的文本内容记录下来(记录到下面MutationRecord对象的oldValue属性中)
};
// eslint-disable-next-line max-lines-per-function
const initMutation = () => {
    if (window.MutationObserver) {
        let _last;
        let clickCount = 0;
        const callback = (_mutations, _observer) => {
            var _a, _b, _c, _d;
            try {
                for (const mutation of _mutations) {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class' && mutation.oldValue) {
                        // eslint-disable-next-line max-depth
                        if ((_a = mutation.target) === null || _a === void 0 ? void 0 : _a.setAttribute) {
                            ;
                            (_b = mutation.target) === null || _b === void 0 ? void 0 : _b.setAttribute('data-before-cls', mutation.oldValue);
                        }
                    }
                    if (mutation.type === 'childList' &&
                        mutation.addedNodes.length &&
                        ((_d = (_c = mutation.target) === null || _c === void 0 ? void 0 : _c.tagName) === null || _d === void 0 ? void 0 : _d.toLowerCase()) === 'body' &&
                        _last) {
                        ;
                        mutation.addedNodes[0].setAttribute('data-origin-path', _last);
                        _last = undefined;
                    }
                }
                // console.log('mutations:', mutations)
                // console.log(observer)
                const testPanel = document.querySelector('.kunlun-builder-user-test-container');
                if (testPanel) {
                    ;
                    testPanel.style.display = 'none';
                }
                const cloud_ide_svg = document.querySelectorAll('svg.force-icon.force-icon-more');
                if (cloud_ide_svg === null || cloud_ide_svg === void 0 ? void 0 : cloud_ide_svg.length) {
                    cloud_ide_svg.forEach(function (svgElement) {
                        const { parentElement } = svgElement;
                        const isOnlyChild = (parentElement === null || parentElement === void 0 ? void 0 : parentElement.children.length) === 1 && parentElement.children[0] === svgElement;
                        // 3. 如果不是唯一子元素就为 svg 添加一个父级使用 div
                        if (!isOnlyChild && parentElement) {
                            const wrapperElement = document.createElement('div');
                            wrapperElement.style.display = 'contents';
                            parentElement.replaceChild(wrapperElement, svgElement);
                            wrapperElement.appendChild(svgElement);
                        }
                    });
                }
                // setSvgWrap()
            }
            catch (e) {
                console.error('mutation error', JSON.stringify(e));
            }
        };
        const observer = new MutationObserver(callback);
        observer.observe(document.body, options);
        const counter = (e) => {
            clickCount += 1;
            _last = clickCount;
            if (e.target && e.target instanceof HTMLAnchorElement) {
                const el = e.target;
                if (el.target === '_blank') {
                    e.preventDefault();
                    window.open(el.href, '_self');
                }
            }
        };
        const destroy = (0, utils_1.addEventListener)('click', counter, document);
        const only = new MutationObserver((mutations) => __awaiter(void 0, void 0, void 0, function* () {
            let ignore = false;
            mutations.forEach((m) => {
                var _a, _b, _c, _d;
                const t = (_b = (_a = m.target) === null || _a === void 0 ? void 0 : _a.getAttribute('aria-label')) !== null && _b !== void 0 ? _b : '';
                const id = (_d = (_c = m.target) === null || _c === void 0 ? void 0 : _c.id) !== null && _d !== void 0 ? _d : '';
                if (t.includes('latency-green-icon') ||
                    t.includes('memory-icon') ||
                    t.includes('cpu-icon') ||
                    id === 'byted-ide.cloud-workspace.cpuItem' ||
                    id === 'byted-ide.cloud-workspace.memItem' ||
                    id === 'byted-ide.cloud-workspace.diskItem') {
                    ignore = true;
                }
            });
            if (!ignore) {
                yield (0, utils_1.postDomMutation)();
            }
        }));
        only.observe(document.body, {
            childList: true,
            subtree: true, // 观察目标节点的所有后代节点
        });
        // 暂时下线
        // 给新增的 shadow root 绑定事件
        const shadowObserver = new MutationObserver((mutations) => mutations.forEach((mutation) => {
            if (mutation.type !== 'childList') {
                return;
            }
            const addedElements = Array.from(mutation.addedNodes).filter((node) => node.nodeType === Node.ELEMENT_NODE);
            if (addedElements.length) {
                addedElements.forEach((addedElement) => {
                    (0, index_1.initShadowEvent)(addedElement);
                });
            }
        }));
        shadowObserver.observe(document.body, {
            childList: true,
            subtree: true,
        });
        chrome.runtime.onMessage.addListener((msg) => __awaiter(void 0, void 0, void 0, function* () {
            console.log('msg', msg);
            if ((msg === null || msg === void 0 ? void 0 : msg.type) === 'calculate-frame-rect') {
                const { frameId, url } = msg.payload;
                let _frame;
                document.querySelectorAll('iframe').forEach((frame) => {
                    if (frame.src === url) {
                        _frame = frame;
                    }
                });
                if (_frame) {
                    const rect = _frame.getBoundingClientRect();
                    yield chrome.storage.session.set({ [frameId]: { x: rect.x, y: rect.y } });
                }
            }
        }));
        return () => {
            observer.disconnect();
            only.disconnect();
            // shadowObserver.disconnect()
            destroy();
        };
    }
    else {
        return () => {
            //
        };
    }
};
exports.initMutation = initMutation;


/***/ }),

/***/ 7741:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.matchMouseUpAndMouseDown = exports.getFindRules = exports.findShadowRoots = exports.shadowRootHosts = exports.isInShadow = exports.HookWindowOpen = exports.GenerateTargetDescription = exports.deepTravalSal = exports.updateRect = exports.findFrame = exports.setOnlyE2EID = exports.setSvgWrap = exports.getTagName = exports.isVisible = exports.isValidClassValue = exports.errorListen = exports.postDomMutation = exports.postJsErrorMessage = exports.postTwoMessage = exports.postLogRulesMessage = exports.postLogMessage = exports.processElementId = exports.processElementRuntimeId = exports.detectIsReact = exports.isTouchEvent = exports.getEventTarget = exports.isBlocked = exports.classMatchesRegex = exports.addEventListener = void 0;
/* eslint-disable max-depth */
const uuid_1 = __webpack_require__(5546);
const xpath_1 = __webpack_require__(203);
const addEventListener = (type, fn, target) => {
    const options = { capture: true, passive: type !== 'click' };
    target.addEventListener(type, fn, options);
    return () => target.removeEventListener(type, fn, options);
};
exports.addEventListener = addEventListener;
function classMatchesRegex(node, regex, checkAncestors) {
    var _a;
    if (!node) {
        return false;
    }
    if (node.nodeType !== node.ELEMENT_NODE) {
        if (!checkAncestors) {
            return false;
        }
        return classMatchesRegex(node.parentNode, regex, checkAncestors);
    }
    for (let eIndex = (_a = node.classList) === null || _a === void 0 ? void 0 : _a.length; eIndex--;) {
        const className = node.classList[eIndex];
        if (regex.test(className)) {
            return true;
        }
    }
    if (!checkAncestors) {
        return false;
    }
    return classMatchesRegex(node.parentNode, regex, checkAncestors);
}
exports.classMatchesRegex = classMatchesRegex;
function isBlocked(node, blockClass, blockSelector, checkAncestors) {
    var _a;
    if (!node) {
        return false;
    }
    const el = node.nodeType === node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) {
        return false;
    }
    if (typeof blockClass === 'string') {
        if ((_a = el.classList) === null || _a === void 0 ? void 0 : _a.contains(blockClass)) {
            return true;
        }
        if (checkAncestors && el.closest(`.${blockClass}`) !== null) {
            return true;
        }
    }
    else if (classMatchesRegex(el, blockClass, checkAncestors)) {
        return true;
    }
    if (blockSelector) {
        if (node.matches(blockSelector)) {
            return true;
        }
        if (checkAncestors && el.closest(blockSelector) !== null) {
            return true;
        }
    }
    return false;
}
exports.isBlocked = isBlocked;
function getEventTarget(event) {
    try {
        if ('composedPath' in event) {
            const path = event.composedPath();
            if (path.length) {
                return path[0];
            }
        }
        else if ('path' in event && event.path.length) {
            return event.path[0];
        }
        return event.target;
    }
    catch (_a) {
        return event.target;
    }
}
exports.getEventTarget = getEventTarget;
function isTouchEvent(event) {
    return Boolean(event.changedTouches);
}
exports.isTouchEvent = isTouchEvent;
// export function throttle<T>(
//   func: (arg: T) => void,
//   wait: number,
//   options: ThrottleOptions = {},
// ) {
//   let timeout: ReturnType<typeof setTimeout> | null = null;
//   let previous = 0;
//   return function (...args: T[]) {
//     const now = Date.now();
//     if (!previous && options.leading === false) {
//       previous = now;
//     }
//     const remaining = wait - (now - previous);
//     // eslint-disable-next-line consistent-this, @babel/no-invalid-this, @typescript-eslint/no-this-alias
//     const context = this;
//     if (remaining <= 0 || remaining > wait) {
//       if (timeout) {
//         clearTimeout(timeout);
//         timeout = null;
//       }
//       previous = now;
//       func.apply(context, args);
//     } else if (!timeout && options.trailing !== false) {
//       timeout = setTimeout(() => {
//         previous = options.leading === false ? 0 : Date.now();
//         timeout = null;
//         func.apply(context, args);
//       }, remaining);
//     }
//   };
// }
const detectIsReact = () => Array.from(document.querySelectorAll('[id]')).some((e) => e._reactRootContainer !== undefined);
exports.detectIsReact = detectIsReact;
const processElementRuntimeId = () => {
    const els = document.querySelectorAll('[nclc-runtime-id]');
    const map = {};
    els.forEach((el) => {
        const id = el.getAttribute('nclc-runtime-id');
        if (id) {
            if (map[id]) {
                map[id] = [...map[id], el];
            }
            else {
                map[id] = [el];
            }
        }
    });
    Object.keys(map).forEach((key) => {
        const eles = map[key];
        if (eles.length) {
            eles.forEach((el, i) => {
                el.setAttribute('nclc-runtime-mnt-id', `${key}-${i + 1}`);
            });
        }
    });
};
exports.processElementRuntimeId = processElementRuntimeId;
const processElementId = () => {
    const els = document.querySelectorAll('[id]');
    const map = {};
    els.forEach((el) => {
        const id = el.getAttribute('id');
        if (id) {
            if (map[id]) {
                map[id] = [...map[id], el];
            }
            else {
                map[id] = [el];
            }
        }
    });
    Object.keys(map).forEach((key) => {
        const eles = map[key];
        if (eles.length) {
            eles.forEach((el, i) => {
                el.setAttribute('mnt-id', `${key}-${i + 1}`);
            });
        }
    });
};
exports.processElementId = processElementId;
const postLogMessage = (type, content, noTime = false) => {
    console.log('postLogMessage', type, content, noTime);
    // chrome.runtime.sendMessage(
    //   {
    //     type: 'mnt-rr-log',
    //     data: {
    //       type: 'mnt-rr-log',
    //       payload: {
    //         type,
    //         content,
    //         timestamp: noTime ? null : Date.now(),
    //       },
    //     },
    //   },
    //   function (sendResponse) {
    //     sendResponse()
    //   },
    // )
};
exports.postLogMessage = postLogMessage;
const postLogRulesMessage = (rules) => {
    rules.forEach((rule, index) => {
        (0, exports.postLogMessage)('Info', `${index + 1}. 类型：${rule.type},值：${rule.value}`, true);
    });
};
exports.postLogRulesMessage = postLogRulesMessage;
const postTwoMessage = (typ, rules) => {
    (0, exports.postLogMessage)('Info', `事件：${typ}, 对应的rules: `);
    (0, exports.postLogRulesMessage)(rules);
};
exports.postTwoMessage = postTwoMessage;
const postJsErrorMessage = (content) => {
    window.postMessage({
        type: 'mnt-rr-error',
        data: {
            type: 'javascript',
            content,
        },
    });
};
exports.postJsErrorMessage = postJsErrorMessage;
const postDomMutation = () => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.runtime.sendMessage({
        type: 'mnt-rr-dom-mutation',
        data: {
            type: 'mnt-rr-dom-mutation',
        },
    });
});
exports.postDomMutation = postDomMutation;
// const originAddEventListener = EventTarget.prototype.addEventListener;
// EventTarget.prototype.addEventListener = function (type, listener, options) {
//   const wrappedListener = function (...args: any[]) {
//     try {
//       return listener.apply(this, args);
//     } catch (err) {
//       throw err;
//     }
//   };
//   return originAddEventListener.call(this, type, wrappedListener, options);
// };
// todo 是不是要写在kakashi里
const errorListen = () => {
    window.onerror = (message, source) => {
        (0, exports.postJsErrorMessage)(JSON.stringify({ message, source }));
    };
    // 捕获资源加载的错误
    window.addEventListener('unhandledrejection', (e) => {
        e.preventDefault();
        (0, exports.postJsErrorMessage)(`unhandledrejection: ${e.reason}`);
        return true;
    });
};
exports.errorListen = errorListen;
const isValidClassValue = (classValue) => {
    if (!classValue || classValue === '') {
        return false;
    }
    if (!classValue.trim()) {
        return false;
    }
    if (classValue.includes('{') || classValue.includes('}')) {
        return false;
    }
    return true;
};
exports.isValidClassValue = isValidClassValue;
function isVisible(elem) {
    var _a;
    const style = window.getComputedStyle(elem);
    if (style.display === 'none') {
        return false;
    }
    if (style.visibility !== 'visible') {
        return false;
    }
    if (elem.tagName.toLowerCase().startsWith('svg')) {
        let svgParentElement = elem.parentElement;
        while (svgParentElement === null || svgParentElement === void 0 ? void 0 : svgParentElement.tagName.toLowerCase().startsWith('svg')) {
            svgParentElement = svgParentElement.parentElement;
        }
        if (!svgParentElement) {
            return false;
        }
        return isVisible(svgParentElement);
    }
    if (elem.offsetWidth + elem.offsetHeight + elem.getBoundingClientRect().height + elem.getBoundingClientRect().width ===
        0) {
        return false;
    }
    const elemCenter = {
        x: elem.getBoundingClientRect().left + elem.offsetWidth / 2,
        y: elem.getBoundingClientRect().top + elem.offsetHeight / 2,
    };
    if (elemCenter.x < 0) {
        return false;
    }
    const clientWidth = document.documentElement.clientWidth || window.innerWidth;
    const clientHeight = document.documentElement.clientHeight || window.innerHeight;
    const boundingWidth = elem.getBoundingClientRect().width;
    if (boundingWidth > clientWidth) {
        return true;
    }
    if (boundingWidth < clientWidth && elemCenter.x > clientWidth) {
        return false;
    }
    if (elemCenter.y < 0) {
        return false;
    }
    if (elem.offsetHeight > clientHeight) {
        return true;
    }
    if (elemCenter.y > clientHeight) {
        return false;
    }
    try {
        let pointContainer = document.elementFromPoint(elemCenter.x, elemCenter.y);
        do {
            if (pointContainer === elem) {
                return true;
            }
        } while ((pointContainer = (_a = pointContainer === null || pointContainer === void 0 ? void 0 : pointContainer.parentElement) !== null && _a !== void 0 ? _a : null));
    }
    catch (e) {
        console.error(e);
        return false;
    }
    return false;
}
exports.isVisible = isVisible;
const getTagName = (element) => { var _a; return ((_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) || ''; };
exports.getTagName = getTagName;
const setSvgWrap = () => {
    // 1. 查找所有的 svg 元素
    const svgElements = document.querySelectorAll('svg');
    // 2. 判断 svg 是否是父级的唯一子元素
    svgElements.forEach(function (svgElement) {
        const { parentElement } = svgElement;
        const isOnlyChild = (parentElement === null || parentElement === void 0 ? void 0 : parentElement.children.length) === 1 && parentElement.children[0] === svgElement;
        // 3. 如果不是唯一子元素就为 svg 添加一个父级使用 div
        if (!isOnlyChild && parentElement) {
            const wrapperElement = document.createElement('div');
            wrapperElement.style.display = 'contents';
            parentElement.replaceChild(wrapperElement, svgElement);
            wrapperElement.appendChild(svgElement);
        }
    });
};
exports.setSvgWrap = setSvgWrap;
const setOnlyE2EID = () => {
    const e2e_els = document.querySelectorAll('[data-e2e-id]');
    const ids = [];
    e2e_els.forEach((el) => {
        const e2e_id = el.getAttribute('data-e2e-id');
        if (e2e_id) {
            ids.push(e2e_id);
        }
    });
    Array.from(new Set(ids)).forEach((id) => {
        const els = document.querySelectorAll(`[data-e2e-id="${id}"]`);
        if (els.length === 1) {
            els[0].setAttribute('data-e2e-id-mnt', id);
            if (id.toLowerCase().includes('table')) {
                const table = els[0].querySelectorAll('table');
                if (table.length === 1) {
                    const trs_head = table[0].querySelectorAll('thead tr');
                    trs_head.forEach((tr, trIndex) => {
                        const ths = tr.querySelectorAll('th');
                        ths.forEach((th, thIndex) => {
                            const _index = thIndex + 1 === ths.length ? 'last()' : thIndex + 1;
                            th.setAttribute('data-e2e-relative-path', `//${(0, exports.getTagName)(els[0])}[@data-e2e-id="${id}"]//table/thead/tr[${trIndex + 1}]//th[${_index}]`);
                        });
                    });
                    const trs_body = table[0].querySelectorAll('tbody tr');
                    trs_body.forEach((tr, trIndex) => {
                        const tds = tr.querySelectorAll('td');
                        tds.forEach((td, tdIndex) => {
                            const _index = tdIndex + 1 === tds.length ? 'last()' : tdIndex + 1;
                            td.setAttribute('data-e2e-relative-path', `//${(0, exports.getTagName)(els[0])}[@data-e2e-id="${id}"]//table/tbody/tr[${trIndex + 1}]//td[${_index}]`);
                        });
                    });
                }
            }
            console.log('Only Element', els[0]);
        }
    });
    if (!e2e_els.length) {
        const ud_table_body = document.querySelectorAll('.ud__table-body');
        if (ud_table_body.length === 1) {
            const trs_body = ud_table_body[0].querySelectorAll('tbody tr');
            trs_body.forEach((tr, trIndex) => {
                const tds = tr.querySelectorAll('td');
                tds.forEach((td, tdIndex) => {
                    const _index = tdIndex + 1 === tds.length ? 'last()' : tdIndex + 1;
                    td.setAttribute('data-e2e-relative-path', `//*[@class='ud__table-body']//tbody/tr[${trIndex + 1}]//td[${_index}]`);
                });
            });
        }
        const ud_table_head = document.querySelectorAll('.ud__table-thead');
        if (ud_table_head.length === 1) {
            const trs_head = ud_table_head[0].querySelectorAll('thead tr');
            trs_head.forEach((tr, trIndex) => {
                const ths = tr.querySelectorAll('th');
                ths.forEach((th, thIndex) => {
                    const _index = thIndex + 1 === ths.length ? 'last()' : thIndex + 1;
                    th.setAttribute('data-e2e-relative-path', `//*[@class='ud__table-thead']//thead/tr[${trIndex + 1}]//th[${_index}]`);
                });
            });
        }
    }
};
exports.setOnlyE2EID = setOnlyE2EID;
function findFrame(node, frames) {
    if (node.Type.toLocaleLowerCase() === 'iframe' && node.Visible) {
        frames.push(node);
    }
    if (node.Children.length) {
        node.Children.forEach((n) => {
            findFrame(n, frames);
        });
    }
}
exports.findFrame = findFrame;
function updateRect(node, rect) {
    if (node.Visible && node.Rect) {
        node.Rect.Top += rect.Top;
        node.Rect.Left += rect.Left;
    }
    if (node.Children.length) {
        node.Children.forEach((n) => {
            updateRect(n, rect);
        });
    }
}
exports.updateRect = updateRect;
/**
 * 深度遍历 dom 对象生成 控件树 Json
 * @param node element节点
 * @param nodes 控件树集合
 * @returns 控件树集合
 */
function deepTravalSal(node, nodes, iframes) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    const stack = [];
    if (node) {
        stack.push(node);
        while (stack.length) {
            const item = stack.shift();
            if (item) {
                // 暂时不记录 style 标签和 script 标签
                if (item.tagName.toLowerCase() === 'style' || item.tagName.toLowerCase() === 'script') {
                    continue;
                }
                const len = item.children.length || 0;
                const rect = item.getBoundingClientRect();
                const attr = {};
                if (item.hasAttributes()) {
                    const attrs = item.attributes;
                    for (let i = attrs.length - 1; i >= 0; i--) {
                        if (attrs[i].name === 'src' && attrs[i].value.includes('./')) {
                            attr.src = `${location.protocol}//${location.host}${location.pathname.replace(/\/[^\/]+$/, '') + attrs[i].value.replace('./', '/')}`;
                        }
                        else {
                            attr[`${attrs[i].name}`] = attrs[i].value;
                        }
                    }
                    try {
                        if (node.tagName.toLowerCase() === 'iframe' &&
                            ((_b = (_a = node.contentWindow) === null || _a === void 0 ? void 0 : _a.document) === null || _b === void 0 ? void 0 : _b.location.href)) {
                            attr.document_src = (_f = (_e = (_d = (_c = node.contentWindow) === null || _c === void 0 ? void 0 : _c.document) === null || _d === void 0 ? void 0 : _d.location) === null || _e === void 0 ? void 0 : _e.href) !== null && _f !== void 0 ? _f : undefined;
                        }
                    }
                    catch (e) {
                        console.error('get iframe document url fail', e);
                    }
                }
                // const fullPath = makeQueryForElement(item, true);
                let ruls = [];
                let elementXpath = '';
                if (isVisible(item)) {
                    const { ruls: _ruls } = (0, xpath_1.processElementXpath)(item);
                    // 不再提供独立的 elementXpath
                    elementXpath = _ruls.length ? _ruls[0].value : '';
                    ruls = _ruls.length ? _ruls : [];
                }
                const fontSize = window.getComputedStyle(item, null).getPropertyValue('font-size').replace('px', '') || undefined;
                let inputValue = '';
                if (item.tagName.toLowerCase() === 'input') {
                    inputValue = (_g = item.value) !== null && _g !== void 0 ? _g : '';
                }
                if (item.contentEditable === 'true') {
                    inputValue = (_h = item.textContent) !== null && _h !== void 0 ? _h : '';
                }
                let text = '';
                if (item.childNodes.length > 0) {
                    let textNodeCount = 0;
                    item.childNodes.forEach((c) => {
                        if (c.nodeType === Node.TEXT_NODE) {
                            textNodeCount += 1;
                        }
                    });
                    // 当前节点内包含文字
                    if (textNodeCount > 0 && item.tagName.toLowerCase() !== 'body') {
                        text = (_j = item.textContent) !== null && _j !== void 0 ? _j : '';
                    }
                }
                else {
                    text = (_k = item.textContent) !== null && _k !== void 0 ? _k : '';
                }
                const current = {
                    _type: 'web',
                    Type: item.tagName,
                    Text: text,
                    Value: inputValue,
                    Visible: isVisible(item),
                    Attributes: attr,
                    Font: fontSize,
                    Rect: {
                        Left: rect.left,
                        Top: rect.top,
                        Width: rect.width,
                        Height: rect.height,
                    },
                    AccurateRect: {
                        Left: rect.left * window.devicePixelRatio,
                        Top: rect.top * window.devicePixelRatio,
                        Width: rect.width * window.devicePixelRatio,
                        Height: rect.height * window.devicePixelRatio,
                    },
                    elementXpath,
                    Children: [],
                    hash: (0, uuid_1.v4)(),
                    findRules: ruls,
                    devicePixelRatio: window.devicePixelRatio,
                };
                if (item.tagName === 'BODY') {
                    current.manifest = {
                        version: chrome.runtime.getManifest().version,
                    };
                }
                nodes.push(current);
                if (current.Type.toLowerCase() === 'iframe' && current.Visible && iframes !== undefined) {
                    iframes.push(current);
                }
                for (let i = 0; i <= len - 1; i++) {
                    if (current.Type.toLowerCase() !== 'svg') {
                        deepTravalSal(item.children[i], current.Children, iframes);
                    }
                }
            }
        }
    }
    return nodes;
}
exports.deepTravalSal = deepTravalSal;
const GenerateTargetDescription = (ele, type) => {
    var _a;
    const nodeName = ele.nodeName.toLowerCase();
    const text = ele.textContent;
    const cls = ((_a = ele.classList) === null || _a === void 0 ? void 0 : _a.toString()) || '';
    if (nodeName === 'button' || cls.includes('btn') || cls.includes('button')) {
        return `点击 按钮 ${text}`;
    }
    else {
        return `点击 ${nodeName} ${text}`;
    }
};
exports.GenerateTargetDescription = GenerateTargetDescription;
const HookWindowOpen = () => {
    const origin = window.open.bind(window);
    Object.assign(window, {
        open: (url, target, features) => {
            origin(url, '_self', features);
        },
    });
};
exports.HookWindowOpen = HookWindowOpen;
function isInShadow(node) {
    return node.getRootNode() instanceof ShadowRoot;
}
exports.isInShadow = isInShadow;
exports.shadowRootHosts = new WeakSet();
function findShadowRoots(element) {
    if (!element) {
        return [];
    }
    // @ts-ignore
    const shadowRoots = [element, ...element.querySelectorAll('*')]
        .filter((elem) => Boolean(elem.shadowRoot))
        .flatMap((elem) => [elem.shadowRoot, ...findShadowRoots(elem.shadowRoot)]);
    shadowRoots.forEach((shadowRoot) => {
        const { host } = shadowRoot.getRootNode();
        exports.shadowRootHosts.add(host);
    });
    return shadowRoots;
}
exports.findShadowRoots = findShadowRoots;
function getFindRules(target) {
    const find = (0, xpath_1.processElementXpath)(target);
    if (isInShadow(target)) {
        const shadowRoot = target.getRootNode();
        const { host } = shadowRoot;
        const hostFind = (0, xpath_1.processElementXpath)(host);
        find === null || find === void 0 ? void 0 : find.ruls.forEach((rule) => {
            rule.hostRules = hostFind.ruls;
        });
    }
    return find;
}
exports.getFindRules = getFindRules;
function matchMouseUpAndMouseDown(mouseUpEvent, mouseDownEvent) {
    if (mouseUpEvent && mouseDownEvent) {
        return (Math.abs(mouseDownEvent.clientX - mouseUpEvent.clientX) < 10 &&
            Math.abs(mouseDownEvent.clientY - mouseUpEvent.clientY) < 10 &&
            (mouseDownEvent.button === 0 || mouseUpEvent.button === 0)); // 0 => left button
        // && mouseDownEvent.target === mouseUpEvent.target // 提示词场景下的 mouseup 时 target 已经是代码窗口而不是提示词选择窗口
    }
    return false;
}
exports.matchMouseUpAndMouseDown = matchMouseUpAndMouseDown;


/***/ }),

/***/ 203:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/* eslint-disable max-lines */
/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/prefer-for-of */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/member-ordering */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.processElementXpath = void 0;
const find_rules_1 = __webpack_require__(1080);
const utils_1 = __webpack_require__(7741);
const PathReg = new RegExp(/^path\[\d+\]$|path/);
function escapeJquery(srcString) {
    // 转义之后的结果
    let escapseResult = srcString;
    // 遇到的特殊字符
    const jsSpecialChars = ['$', '%'];
    for (let i = 0; i < jsSpecialChars.length; i++) {
        escapseResult = escapseResult.replace(new RegExp(`\\${jsSpecialChars[i]}`, 'g'), `\\${jsSpecialChars[i]}`);
    }
    return escapseResult;
}
class SelectorGenerator {
    constructor() {
        this.selectors = [];
    }
    storeSelector(selector, type) {
        if (selector === undefined || selector === 'undefined') {
            console.log('WARNING!: Invalid selector at: ');
            console.trace();
            return;
        }
        this.selectors.push({ value: selector, type });
    }
    generateIdBasedSelector(id) {
        throw new Error('You have to implement the method!');
    }
    generateNameBasedSelector(name) {
        throw new Error('You have to implement the method!');
    }
    generateTagNameBasedSelector(tagName) {
        throw new Error('You have to implement the method!');
    }
    generateLinkTextBasedSelector(linkText) {
        throw new Error('You have to implement the method!');
    }
    generateTextBasedSelector(text) {
        throw new Error('You have to implement the method!');
    }
    generateCssBasedSelector(css) {
        this.storeSelector(css, 'css');
    }
    generateXPathBasedSelector(xPath) {
        throw new Error('You have to implement the method!');
    }
    collectAttributeBasedSelectors(element) {
        var _a, _b;
        const doc = element.getRootNode();
        const { attributes } = element;
        for (let i = 0; i < attributes.length; i++) {
            const nodeName = attributes[i].nodeName.toLowerCase();
            if (nodeName !== 'id' &&
                nodeName !== 'class' &&
                nodeName !== 'name' &&
                nodeName !== 'xmlns:xlink' &&
                !nodeName.includes('&') &&
                attributes[i].nodeValue !== null &&
                attributes[i].nodeValue !== undefined &&
                !((_a = attributes[i].nodeValue) === null || _a === void 0 ? void 0 : _a.includes('}')) &&
                !((_b = attributes[i].nodeValue) === null || _b === void 0 ? void 0 : _b.includes('{'))) {
                const cssSelector = `${element.tagName.toLowerCase()}[${nodeName} = '${escape(attributes[i].nodeValue)}']`;
                const allElements = doc.querySelectorAll(cssSelector);
                if (this.hasOnlyOne(allElements)) {
                    this.generateAttributeBasedSelector(element.tagName.toLowerCase(), nodeName, escape(attributes[i].nodeValue));
                }
            }
        }
    }
    generateAttributeBasedSelector(tagName, attributeName, attributeValue) {
        this.generateCssBasedSelector(`${tagName}[${attributeName} = '${attributeValue}']`);
    }
    collectUniqueClassSelectors(element) {
        const doc = element.getRootNode();
        const cl = element.getAttribute('class');
        if (cl === null || cl === undefined) {
            return;
        }
        const classes = cl.split(' ');
        for (let i = 0; i < classes.length; i++) {
            if ((0, utils_1.isValidClassValue)(classes[i])) {
                const cssSelector = `${element.tagName.toLowerCase()}.${classes[i]}`;
                try {
                    if (this.hasOnlyOne(doc.querySelectorAll(cssSelector))) {
                        this.generateClassBasedSelector(element.tagName.toLowerCase(), classes[i]);
                    }
                }
                catch (e) {
                    console.error('collectUniqueClassSelectors error', e);
                }
            }
        }
    }
    generateClassBasedSelector(tagName, className) {
        this.generateCssBasedSelector(`${tagName}.${className}`);
    }
    hasOnlyOne(elementList) {
        return elementList.length === 1;
    }
    hasOnlyOneWithText(elementList, text) {
        let foundCount = 0;
        for (let i = 0; i < elementList.length; i++) {
            if (elementList[i].text !== undefined && elementList[i].text.localeCompare(text) === 0) {
                foundCount++;
                if (foundCount > 1) {
                    return false;
                }
            }
        }
        return foundCount === 1;
    }
    svgFilter(path) {
        if (path.length > 0 && PathReg.test(path[path.length - 1])) {
            path.pop();
        }
        if (path.length > 0 && path[path.length - 1] === 'svg') {
            path.pop();
        }
    }
    // Source: https://stackoverflow.com/questions/3620116/get-css-path-from-dom-element
    // deprecated
    getCssSelector(element, ignoreID = false) {
        if (!(element instanceof Element)) {
            console.log(`Element is not an Element: ${element}`);
            return;
        }
        const path = [];
        while (element.nodeType === Node.ELEMENT_NODE) {
            let selector = element.nodeName.toLowerCase();
            const UIDL_ID = element.getAttribute('data-e2e-id');
            const FORM_ITEM_ID = element.getAttribute('data-nclc-runtime-form-item-id');
            if (FORM_ITEM_ID) {
                selector += `[data-nclc-runtime-form-item-id="${FORM_ITEM_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (UIDL_ID) {
                selector += `[data-e2e-id="${UIDL_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (element.id && !ignoreID) {
                selector += `#${escapeJquery(element.id)}`;
                path.unshift(selector);
                break;
            }
            else {
                let previousSibling = element;
                let nth = 1;
                // eslint-disable-next-line no-cond-assign
                while ((previousSibling = previousSibling.previousElementSibling)) {
                    if (previousSibling.nodeName.toLowerCase() === selector) {
                        nth++;
                    }
                }
                if (nth !== 1) {
                    selector += `:nth-of-type(${nth})`;
                }
            }
            path.unshift(selector);
            // eslint-disable-next-line no-param-reassign
            element = element.parentNode;
            if (element === null) {
                console.log('ERROR: Cannot determine CSS selector. Please report the error by providing the URL and the element at https://github.com/mszeles/selenideium-element-inspector/issues');
                // eslint-disable-next-line consistent-return
                return null;
            }
        }
        this.svgFilter(path);
        // eslint-disable-next-line consistent-return
        return path.join(' > ');
    }
    // deprecated
    getRelativeXPathSelector(element, ignoreID = false) {
        if (!(element instanceof Element)) {
            console.log(`Element is not an Element: ${element}`);
            return;
        }
        const path = [];
        while (element.nodeType === Node.ELEMENT_NODE) {
            let selector = element.nodeName.toLowerCase();
            const UIDL_ID = element.getAttribute('data-e2e-id');
            const FORM_ITEM_ID = element.getAttribute('data-nclc-runtime-form-item-id');
            if (FORM_ITEM_ID) {
                selector += `[@data-nclc-runtime-form-item-id="${FORM_ITEM_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (UIDL_ID) {
                selector += `[@data-e2e-id="${UIDL_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (element.id && !ignoreID) {
                const mnt_ID = element.getAttribute('mnt-id');
                if (mnt_ID) {
                    selector += `[@mnt-id="${escapeJquery(mnt_ID)}"]`;
                }
                else {
                    selector += `[@id="${escapeJquery(element.id)}"]`;
                }
                path.unshift(selector);
                break;
            }
            else {
                let previousSibling = element;
                let nth = 1;
                // eslint-disable-next-line no-cond-assign
                while ((previousSibling = previousSibling.previousElementSibling)) {
                    if (previousSibling.nodeName.toLowerCase() === selector) {
                        nth++;
                    }
                }
                if (nth !== 0) {
                    selector += `[${nth}]`;
                }
            }
            path.unshift(selector);
            if (element.parentNode === null) {
                console.log('ERROR: Cannot determine XPath selector.');
                // eslint-disable-next-line consistent-return
                return null;
            }
            // eslint-disable-next-line no-param-reassign
            element = element.parentNode;
        }
        this.svgFilter(path);
        // eslint-disable-next-line consistent-return
        return `//${path.join('/')}`;
    }
}
class JavaScriptSelectorGenerator extends SelectorGenerator {
    getName() {
        return 'JavaScript';
    }
    createXPathSelector(selector) {
        return selector;
    }
    generateIdBasedSelector(id) {
        this.storeSelector(`#${id}`, 'css');
    }
    generateNameBasedSelector(name) {
        // this.storeSelector(this.createSelector(`By.name('${name}')`));
    }
    generateTagNameBasedSelector(tagName) {
        // this.storeSelector(this.createSelector(`By.tagName('${tagName}')`));
    }
    generateLinkTextBasedSelector(linkText) {
        // this.storeSelector(this.createSelector(`By.linkText('${linkText}')`));
    }
    generateTextBasedSelector(text) { }
    generateCssBasedSelector(css) {
        this.storeSelector(css, 'css');
    }
    generateXPathBasedSelector(xPath, ignoreID = false) {
        this.storeSelector(xPath, 'xpath');
    }
    generateCssWithIgnoreId(target) {
        const css = this.getCssSelector(target, true);
        if (css) {
            this.storeSelector(css, 'css');
        }
    }
}
const processElementXpath = (target, _log = false) => {
    var _a;
    try {
        // console.log('------------- Element Inspector -------------')
        // console.log(target)
        // 转化一下
        // processElementRuntimeId()
        // processElementId()
        const doc = target.getRootNode();
        const selectorGenerator = new JavaScriptSelectorGenerator();
        if (target.hasAttribute('id')) {
            const id = escapeJquery((_a = target.getAttribute('id')) !== null && _a !== void 0 ? _a : '');
            try {
                if (id && selectorGenerator.hasOnlyOne(doc.querySelectorAll(`*#${id}`))) {
                    selectorGenerator.generateIdBasedSelector(id);
                }
                else {
                    console.log(`Warning: There are multiple elements with id: ${id}`);
                }
            }
            catch (e) {
                console.log('Error is not a valid selector: ', `*#${id}`, 'reason', e);
            }
        }
        // if (target.hasAttribute('name')) {
        //   const name = target.getAttribute('name')
        //   if (name && selectorGenerator.hasOnlyOne(document.getElementsByName(name))) {
        //     selectorGenerator.generateNameBasedSelector(name)
        //   }
        // }
        // if (selectorGenerator.hasOnlyOne(document.getElementsByTagName(target.tagName))) {
        //   selectorGenerator.generateTagNameBasedSelector(target.tagName)
        // }
        // const links = document.getElementsByTagName('a')
        // if (target.tagName.toLowerCase() === 'a') {
        //   if (selectorGenerator.hasOnlyOneWithText(links, (target as HTMLAnchorElement).text)) {
        //     selectorGenerator.generateLinkTextBasedSelector((target as HTMLAnchorElement).text)
        //   }
        // }
        // if (selectorGenerator.hasOnlyOneWithText(document.getElementsByTagName('*'), (target as any).text)) {
        //   selectorGenerator.generateTextBasedSelector((target as any).text)
        // }
        // const css = selectorGenerator.getCssSelector(target)
        // if (css !== null) {
        //   selectorGenerator.generateCssBasedSelector(css as string)
        // }
        // const xpath = selectorGenerator.getRelativeXPathSelector(target)
        // if (xpath !== null) {
        //   selectorGenerator.generateXPathBasedSelector(xpath as string)
        // }
        // const ignoreIDCss = selectorGenerator.getCssSelector(target, true)
        // if (ignoreIDCss) {
        //   selectorGenerator.generateCssBasedSelector(ignoreIDCss)
        // }
        // const ignoreIDXpath = selectorGenerator.getRelativeXPathSelector(target, true)
        // if (ignoreIDXpath) {
        //   selectorGenerator.generateXPathBasedSelector(ignoreIDXpath)
        // }
        selectorGenerator.collectAttributeBasedSelectors(target);
        selectorGenerator.collectUniqueClassSelectors(target);
        // selectorGenerator.generateCssWithIgnoreId(target)
        const ruls = [];
        const notShadowDom = !(0, utils_1.isInShadow)(target);
        if (notShadowDom) { // shadow dom 不支持 xpath 查找
            const xpath = (0, find_rules_1.generateElementFindRules)(target);
            if (xpath === null || xpath === void 0 ? void 0 : xpath.length) {
                xpath.forEach((x) => {
                    selectorGenerator.storeSelector(x.value, 'xpath');
                });
            }
        }
        for (let i = 0; i < selectorGenerator.selectors.length; i++) {
            // console.log(selectorGenerator.selectors[i].value);
            const has = ruls.find((v) => v.value === selectorGenerator.selectors[i].value);
            if (!has) {
                ruls.push(selectorGenerator.selectors[i]);
            }
        }
        // console.log('result', ruls)
        // console.log('---------------------------------------------------------')
        return {
            ruls,
        };
    }
    catch (e) {
        return {
            ruls: [],
        };
    }
};
exports.processElementXpath = processElementXpath;


/***/ }),

/***/ 5546:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "NIL", ({
  enumerable: true,
  get: function get() {
    return _nil.default;
  }
}));
Object.defineProperty(exports, "parse", ({
  enumerable: true,
  get: function get() {
    return _parse.default;
  }
}));
Object.defineProperty(exports, "stringify", ({
  enumerable: true,
  get: function get() {
    return _stringify.default;
  }
}));
Object.defineProperty(exports, "v1", ({
  enumerable: true,
  get: function get() {
    return _v.default;
  }
}));
Object.defineProperty(exports, "v3", ({
  enumerable: true,
  get: function get() {
    return _v2.default;
  }
}));
Object.defineProperty(exports, "v4", ({
  enumerable: true,
  get: function get() {
    return _v3.default;
  }
}));
Object.defineProperty(exports, "v5", ({
  enumerable: true,
  get: function get() {
    return _v4.default;
  }
}));
Object.defineProperty(exports, "validate", ({
  enumerable: true,
  get: function get() {
    return _validate.default;
  }
}));
Object.defineProperty(exports, "version", ({
  enumerable: true,
  get: function get() {
    return _version.default;
  }
}));

var _v = _interopRequireDefault(__webpack_require__(5473));

var _v2 = _interopRequireDefault(__webpack_require__(4405));

var _v3 = _interopRequireDefault(__webpack_require__(5775));

var _v4 = _interopRequireDefault(__webpack_require__(2707));

var _nil = _interopRequireDefault(__webpack_require__(3927));

var _version = _interopRequireDefault(__webpack_require__(7493));

var _validate = _interopRequireDefault(__webpack_require__(4084));

var _stringify = _interopRequireDefault(__webpack_require__(9688));

var _parse = _interopRequireDefault(__webpack_require__(432));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),

/***/ 9756:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */
function md5(bytes) {
  if (typeof bytes === 'string') {
    const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Uint8Array(msg.length);

    for (let i = 0; i < msg.length; ++i) {
      bytes[i] = msg.charCodeAt(i);
    }
  }

  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */


function md5ToHexEncodedArray(input) {
  const output = [];
  const length32 = input.length * 32;
  const hexTab = '0123456789abcdef';

  for (let i = 0; i < length32; i += 8) {
    const x = input[i >> 5] >>> i % 32 & 0xff;
    const hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
    output.push(hex);
  }

  return output;
}
/**
 * Calculate output length with padding and bit length
 */


function getOutputLength(inputLength8) {
  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */


function wordsToMd5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[getOutputLength(len) - 1] = len;
  let a = 1732584193;
  let b = -271733879;
  let c = -1732584194;
  let d = 271733878;

  for (let i = 0; i < x.length; i += 16) {
    const olda = a;
    const oldb = b;
    const oldc = c;
    const oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  return [a, b, c, d];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */


function bytesToWords(input) {
  if (input.length === 0) {
    return [];
  }

  const length8 = input.length * 8;
  const output = new Uint32Array(getOutputLength(length8));

  for (let i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
  }

  return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */


function safeAdd(x, y) {
  const lsw = (x & 0xffff) + (y & 0xffff);
  const msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */


function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */


function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}

function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}

function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}

function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}

function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

var _default = md5;
exports["default"] = _default;

/***/ }),

/***/ 4443:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var _default = {
  randomUUID
};
exports["default"] = _default;

/***/ }),

/***/ 3927:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _default = '00000000-0000-0000-0000-000000000000';
exports["default"] = _default;

/***/ }),

/***/ 432:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function parse(uuid) {
  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Invalid UUID');
  }

  let v;
  const arr = new Uint8Array(16); // Parse ########-....-....-....-............

  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 0xff;
  arr[2] = v >>> 8 & 0xff;
  arr[3] = v & 0xff; // Parse ........-####-....-....-............

  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 0xff; // Parse ........-....-####-....-............

  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 0xff; // Parse ........-....-....-####-............

  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 0xff; // Parse ........-....-....-....-############
  // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)

  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
  arr[11] = v / 0x100000000 & 0xff;
  arr[12] = v >>> 24 & 0xff;
  arr[13] = v >>> 16 & 0xff;
  arr[14] = v >>> 8 & 0xff;
  arr[15] = v & 0xff;
  return arr;
}

var _default = parse;
exports["default"] = _default;

/***/ }),

/***/ 783:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
exports["default"] = _default;

/***/ }),

/***/ 3462:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = rng;
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);

function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ 9462:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;

    case 1:
      return x ^ y ^ z;

    case 2:
      return x & y ^ x & z ^ y & z;

    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  const K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  const H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes === 'string') {
    const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = [];

    for (let i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    // Convert Array-like to Array
    bytes = Array.prototype.slice.call(bytes);
  }

  bytes.push(0x80);
  const l = bytes.length / 4 + 2;
  const N = Math.ceil(l / 16);
  const M = new Array(N);

  for (let i = 0; i < N; ++i) {
    const arr = new Uint32Array(16);

    for (let j = 0; j < 16; ++j) {
      arr[j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
    }

    M[i] = arr;
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (let i = 0; i < N; ++i) {
    const W = new Uint32Array(80);

    for (let t = 0; t < 16; ++t) {
      W[t] = M[i][t];
    }

    for (let t = 16; t < 80; ++t) {
      W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
    }

    let a = H[0];
    let b = H[1];
    let c = H[2];
    let d = H[3];
    let e = H[4];

    for (let t = 0; t < 80; ++t) {
      const s = Math.floor(t / 20);
      const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

var _default = sha1;
exports["default"] = _default;

/***/ }),

/***/ 9688:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
exports.unsafeStringify = unsafeStringify;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

function stringify(arr, offset = 0) {
  const uuid = unsafeStringify(arr, offset); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

var _default = stringify;
exports["default"] = _default;

/***/ }),

/***/ 5473:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _rng = _interopRequireDefault(__webpack_require__(3462));

var _stringify = __webpack_require__(9688);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html
let _nodeId;

let _clockseq; // Previous uuid creation time


let _lastMSecs = 0;
let _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  let i = buf && offset || 0;
  const b = buf || new Array(16);
  options = options || {};
  let node = options.node || _nodeId;
  let clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    const seedBytes = options.random || (options.rng || _rng.default)();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  let msecs = options.msecs !== undefined ? options.msecs : Date.now(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  let nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  const tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  const tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (let n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf || (0, _stringify.unsafeStringify)(b);
}

var _default = v1;
exports["default"] = _default;

/***/ }),

/***/ 4405:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _v = _interopRequireDefault(__webpack_require__(2548));

var _md = _interopRequireDefault(__webpack_require__(9756));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v3 = (0, _v.default)('v3', 0x30, _md.default);
var _default = v3;
exports["default"] = _default;

/***/ }),

/***/ 2548:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.URL = exports.DNS = void 0;
exports["default"] = v35;

var _stringify = __webpack_require__(9688);

var _parse = _interopRequireDefault(__webpack_require__(432));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape

  const bytes = [];

  for (let i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }

  return bytes;
}

const DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
exports.DNS = DNS;
const URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
exports.URL = URL;

function v35(name, version, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    var _namespace;

    if (typeof value === 'string') {
      value = stringToBytes(value);
    }

    if (typeof namespace === 'string') {
      namespace = (0, _parse.default)(namespace);
    }

    if (((_namespace = namespace) === null || _namespace === void 0 ? void 0 : _namespace.length) !== 16) {
      throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
    } // Compute hash of namespace and value, Per 4.3
    // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
    // hashfunc([...namespace, ... value])`


    let bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      offset = offset || 0;

      for (let i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }

      return buf;
    }

    return (0, _stringify.unsafeStringify)(bytes);
  } // Function#name is not settable on some platforms (#270)


  try {
    generateUUID.name = name; // eslint-disable-next-line no-empty
  } catch (err) {} // For CommonJS default export support


  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}

/***/ }),

/***/ 5775:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _native = _interopRequireDefault(__webpack_require__(4443));

var _rng = _interopRequireDefault(__webpack_require__(3462));

var _stringify = __webpack_require__(9688);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function v4(options, buf, offset) {
  if (_native.default.randomUUID && !buf && !options) {
    return _native.default.randomUUID();
  }

  options = options || {};

  const rnds = options.random || (options.rng || _rng.default)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`


  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0, _stringify.unsafeStringify)(rnds);
}

var _default = v4;
exports["default"] = _default;

/***/ }),

/***/ 2707:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _v = _interopRequireDefault(__webpack_require__(2548));

var _sha = _interopRequireDefault(__webpack_require__(9462));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v5 = (0, _v.default)('v5', 0x50, _sha.default);
var _default = v5;
exports["default"] = _default;

/***/ }),

/***/ 4084:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _regex = _interopRequireDefault(__webpack_require__(783));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function validate(uuid) {
  return typeof uuid === 'string' && _regex.default.test(uuid);
}

var _default = validate;
exports["default"] = _default;

/***/ }),

/***/ 7493:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function version(uuid) {
  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Invalid UUID');
  }

  return parseInt(uuid.slice(14, 15), 16);
}

var _default = version;
exports["default"] = _default;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(2136);
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});