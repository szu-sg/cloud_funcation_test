(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["mnt-swan"] = factory();
	else
		root["mnt-swan"] = factory();
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 4957:
/***/ (function() {

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * 接收 background 发来的消息，并向同域下发送，mtn Platform 页面会通过 postMessage 捕获到这里发送的消息
 */
chrome.runtime.onMessage.addListener(function (request, sender, sendMessage) {
    console.log('record_platform', request);
    window.postMessage(Object.assign(Object.assign({}, request), { origin: 'swan-record' }));
});
// 向 background 发送消息
window.addEventListener('message', (e) => __awaiter(this, void 0, void 0, function* () {
    var _a;
    if (typeof e.data === 'object' && ((_a = e.data) === null || _a === void 0 ? void 0 : _a.origin) === 'mnt') {
        console.log('record_platform_local', e);
        const { payload } = e.data;
        if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'mtn-rr-do-snapshot') {
            yield chrome.runtime.sendMessage(payload);
        }
        if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'clickAsHover') {
            yield chrome.runtime.sendMessage(payload);
        }
        if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'pauseRecording') {
            yield chrome.runtime.sendMessage(payload);
        }
        if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'toggleUrl') {
            yield chrome.runtime.sendMessage(payload);
        }
        if ((payload === null || payload === void 0 ? void 0 : payload.type) === 'mtn-rr-do-snapshot-with-record') {
            yield chrome.runtime.sendMessage(payload);
        }
    }
}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__[4957]();
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});