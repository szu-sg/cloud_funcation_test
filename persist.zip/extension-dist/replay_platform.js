(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["mnt-swan"] = factory();
	else
		root["mnt-swan"] = factory();
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 8702:
/***/ (function() {

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
chrome.runtime.onMessage.addListener(function (request, sender, sendMessage) {
    console.log('replay_platform-runtime', request);
    window.postMessage(Object.assign(Object.assign({}, request), { origin: 'swan-replay' }));
});
window.addEventListener('message', (e) => __awaiter(this, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    if (typeof e.data === 'object' && ((_a = e.data) === null || _a === void 0 ? void 0 : _a.origin) === 'mnt') {
        console.log('replay_platform-local', e);
        if (((_b = e.data) === null || _b === void 0 ? void 0 : _b.type) === 'mnt-event-replay') {
            console.log('replay_platform-local', 'mnt-event-replay', e);
            yield chrome.runtime.sendMessage(e.data);
        }
        if (((_c = e.data) === null || _c === void 0 ? void 0 : _c.type) === 'mtn-rr-do-snapshot') {
            yield chrome.runtime.sendMessage(e.data);
        }
        const { payload } = e.data;
        if ((payload === null || payload === void 0 ? void 0 : payload.name) === 'open-target') {
            yield chrome.runtime.sendMessage(payload);
        }
        if (((_d = e.data) === null || _d === void 0 ? void 0 : _d.type) === 'get-step-traffic') {
            console.log('get-step-traffic', e.data);
            yield chrome.runtime.sendMessage(e.data);
        }
    }
}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__[8702]();
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});