(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["mnt-swan"] = factory();
	else
		root["mnt-swan"] = factory();
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 7289:
/***/ ((__unused_webpack_module, exports) => {


/* eslint-disable @typescript-eslint/naming-convention */
/**
 * Copyright 2017 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports._keyDefinitions = void 0;
/**
 * @internal
 */
exports._keyDefinitions = {
    '0': { keyCode: 48, key: '0', code: 'Digit0' },
    '1': { keyCode: 49, key: '1', code: 'Digit1' },
    '2': { keyCode: 50, key: '2', code: 'Digit2' },
    '3': { keyCode: 51, key: '3', code: 'Digit3' },
    '4': { keyCode: 52, key: '4', code: 'Digit4' },
    '5': { keyCode: 53, key: '5', code: 'Digit5' },
    '6': { keyCode: 54, key: '6', code: 'Digit6' },
    '7': { keyCode: 55, key: '7', code: 'Digit7' },
    '8': { keyCode: 56, key: '8', code: 'Digit8' },
    '9': { keyCode: 57, key: '9', code: 'Digit9' },
    Power: { key: 'Power', code: 'Power' },
    Eject: { key: 'Eject', code: 'Eject' },
    Abort: { keyCode: 3, code: 'Abort', key: 'Cancel' },
    Help: { keyCode: 6, code: 'Help', key: 'Help' },
    Backspace: { keyCode: 8, code: 'Backspace', key: 'Backspace' },
    Tab: { keyCode: 9, code: 'Tab', key: 'Tab' },
    Numpad5: {
        keyCode: 12,
        shiftKeyCode: 101,
        key: 'Clear',
        code: 'Numpad5',
        shiftKey: '5',
        location: 3,
    },
    NumpadEnter: {
        keyCode: 13,
        code: 'NumpadEnter',
        key: 'Enter',
        text: '\r',
        location: 3,
    },
    Enter: { keyCode: 13, code: 'Enter', key: 'Enter', text: '\r' },
    '\r': { keyCode: 13, code: 'Enter', key: 'Enter', text: '\r' },
    '\n': { keyCode: 13, code: 'Enter', key: 'Enter', text: '\r' },
    ShiftLeft: { keyCode: 16, code: 'ShiftLeft', key: 'Shift', location: 1 },
    ShiftRight: { keyCode: 16, code: 'ShiftRight', key: 'Shift', location: 2 },
    ControlLeft: {
        keyCode: 17,
        code: 'ControlLeft',
        key: 'Control',
        location: 1,
    },
    ControlRight: {
        keyCode: 17,
        code: 'ControlRight',
        key: 'Control',
        location: 2,
    },
    AltLeft: { keyCode: 18, code: 'AltLeft', key: 'Alt', location: 1 },
    AltRight: { keyCode: 18, code: 'AltRight', key: 'Alt', location: 2 },
    Pause: { keyCode: 19, code: 'Pause', key: 'Pause' },
    CapsLock: { keyCode: 20, code: 'CapsLock', key: 'CapsLock' },
    Escape: { keyCode: 27, code: 'Escape', key: 'Escape' },
    Convert: { keyCode: 28, code: 'Convert', key: 'Convert' },
    NonConvert: { keyCode: 29, code: 'NonConvert', key: 'NonConvert' },
    Space: { keyCode: 32, code: 'Space', key: ' ' },
    Numpad9: {
        keyCode: 33,
        shiftKeyCode: 105,
        key: 'PageUp',
        code: 'Numpad9',
        shiftKey: '9',
        location: 3,
    },
    PageUp: { keyCode: 33, code: 'PageUp', key: 'PageUp' },
    Numpad3: {
        keyCode: 34,
        shiftKeyCode: 99,
        key: 'PageDown',
        code: 'Numpad3',
        shiftKey: '3',
        location: 3,
    },
    PageDown: { keyCode: 34, code: 'PageDown', key: 'PageDown' },
    End: { keyCode: 35, code: 'End', key: 'End' },
    Numpad1: {
        keyCode: 35,
        shiftKeyCode: 97,
        key: 'End',
        code: 'Numpad1',
        shiftKey: '1',
        location: 3,
    },
    Home: { keyCode: 36, code: 'Home', key: 'Home' },
    Numpad7: {
        keyCode: 36,
        shiftKeyCode: 103,
        key: 'Home',
        code: 'Numpad7',
        shiftKey: '7',
        location: 3,
    },
    ArrowLeft: { keyCode: 37, code: 'ArrowLeft', key: 'ArrowLeft' },
    Numpad4: {
        keyCode: 37,
        shiftKeyCode: 100,
        key: 'ArrowLeft',
        code: 'Numpad4',
        shiftKey: '4',
        location: 3,
    },
    Numpad8: {
        keyCode: 38,
        shiftKeyCode: 104,
        key: 'ArrowUp',
        code: 'Numpad8',
        shiftKey: '8',
        location: 3,
    },
    ArrowUp: { keyCode: 38, code: 'ArrowUp', key: 'ArrowUp' },
    ArrowRight: { keyCode: 39, code: 'ArrowRight', key: 'ArrowRight' },
    Numpad6: {
        keyCode: 39,
        shiftKeyCode: 102,
        key: 'ArrowRight',
        code: 'Numpad6',
        shiftKey: '6',
        location: 3,
    },
    Numpad2: {
        keyCode: 40,
        shiftKeyCode: 98,
        key: 'ArrowDown',
        code: 'Numpad2',
        shiftKey: '2',
        location: 3,
    },
    ArrowDown: { keyCode: 40, code: 'ArrowDown', key: 'ArrowDown' },
    Select: { keyCode: 41, code: 'Select', key: 'Select' },
    Open: { keyCode: 43, code: 'Open', key: 'Execute' },
    PrintScreen: { keyCode: 44, code: 'PrintScreen', key: 'PrintScreen' },
    Insert: { keyCode: 45, code: 'Insert', key: 'Insert' },
    Numpad0: {
        keyCode: 45,
        shiftKeyCode: 96,
        key: 'Insert',
        code: 'Numpad0',
        shiftKey: '0',
        location: 3,
    },
    Delete: { keyCode: 46, code: 'Delete', key: 'Delete' },
    NumpadDecimal: {
        keyCode: 46,
        shiftKeyCode: 110,
        code: 'NumpadDecimal',
        key: '\u0000',
        shiftKey: '.',
        location: 3,
    },
    Digit0: { keyCode: 48, code: 'Digit0', shiftKey: ')', key: '0' },
    Digit1: { keyCode: 49, code: 'Digit1', shiftKey: '!', key: '1' },
    Digit2: { keyCode: 50, code: 'Digit2', shiftKey: '@', key: '2' },
    Digit3: { keyCode: 51, code: 'Digit3', shiftKey: '#', key: '3' },
    Digit4: { keyCode: 52, code: 'Digit4', shiftKey: '$', key: '4' },
    Digit5: { keyCode: 53, code: 'Digit5', shiftKey: '%', key: '5' },
    Digit6: { keyCode: 54, code: 'Digit6', shiftKey: '^', key: '6' },
    Digit7: { keyCode: 55, code: 'Digit7', shiftKey: '&', key: '7' },
    Digit8: { keyCode: 56, code: 'Digit8', shiftKey: '*', key: '8' },
    Digit9: { keyCode: 57, code: 'Digit9', shiftKey: '(', key: '9' },
    KeyA: { keyCode: 65, code: 'KeyA', shiftKey: 'A', key: 'a' },
    KeyB: { keyCode: 66, code: 'KeyB', shiftKey: 'B', key: 'b' },
    KeyC: { keyCode: 67, code: 'KeyC', shiftKey: 'C', key: 'c' },
    KeyD: { keyCode: 68, code: 'KeyD', shiftKey: 'D', key: 'd' },
    KeyE: { keyCode: 69, code: 'KeyE', shiftKey: 'E', key: 'e' },
    KeyF: { keyCode: 70, code: 'KeyF', shiftKey: 'F', key: 'f' },
    KeyG: { keyCode: 71, code: 'KeyG', shiftKey: 'G', key: 'g' },
    KeyH: { keyCode: 72, code: 'KeyH', shiftKey: 'H', key: 'h' },
    KeyI: { keyCode: 73, code: 'KeyI', shiftKey: 'I', key: 'i' },
    KeyJ: { keyCode: 74, code: 'KeyJ', shiftKey: 'J', key: 'j' },
    KeyK: { keyCode: 75, code: 'KeyK', shiftKey: 'K', key: 'k' },
    KeyL: { keyCode: 76, code: 'KeyL', shiftKey: 'L', key: 'l' },
    KeyM: { keyCode: 77, code: 'KeyM', shiftKey: 'M', key: 'm' },
    KeyN: { keyCode: 78, code: 'KeyN', shiftKey: 'N', key: 'n' },
    KeyO: { keyCode: 79, code: 'KeyO', shiftKey: 'O', key: 'o' },
    KeyP: { keyCode: 80, code: 'KeyP', shiftKey: 'P', key: 'p' },
    KeyQ: { keyCode: 81, code: 'KeyQ', shiftKey: 'Q', key: 'q' },
    KeyR: { keyCode: 82, code: 'KeyR', shiftKey: 'R', key: 'r' },
    KeyS: { keyCode: 83, code: 'KeyS', shiftKey: 'S', key: 's' },
    KeyT: { keyCode: 84, code: 'KeyT', shiftKey: 'T', key: 't' },
    KeyU: { keyCode: 85, code: 'KeyU', shiftKey: 'U', key: 'u' },
    KeyV: { keyCode: 86, code: 'KeyV', shiftKey: 'V', key: 'v' },
    KeyW: { keyCode: 87, code: 'KeyW', shiftKey: 'W', key: 'w' },
    KeyX: { keyCode: 88, code: 'KeyX', shiftKey: 'X', key: 'x' },
    KeyY: { keyCode: 89, code: 'KeyY', shiftKey: 'Y', key: 'y' },
    KeyZ: { keyCode: 90, code: 'KeyZ', shiftKey: 'Z', key: 'z' },
    MetaLeft: { keyCode: 91, code: 'MetaLeft', key: 'Meta', location: 1 },
    MetaRight: { keyCode: 92, code: 'MetaRight', key: 'Meta', location: 2 },
    ContextMenu: { keyCode: 93, code: 'ContextMenu', key: 'ContextMenu' },
    NumpadMultiply: {
        keyCode: 106,
        code: 'NumpadMultiply',
        key: '*',
        location: 3,
    },
    NumpadAdd: { keyCode: 107, code: 'NumpadAdd', key: '+', location: 3 },
    NumpadSubtract: {
        keyCode: 109,
        code: 'NumpadSubtract',
        key: '-',
        location: 3,
    },
    NumpadDivide: { keyCode: 111, code: 'NumpadDivide', key: '/', location: 3 },
    F1: { keyCode: 112, code: 'F1', key: 'F1' },
    F2: { keyCode: 113, code: 'F2', key: 'F2' },
    F3: { keyCode: 114, code: 'F3', key: 'F3' },
    F4: { keyCode: 115, code: 'F4', key: 'F4' },
    F5: { keyCode: 116, code: 'F5', key: 'F5' },
    F6: { keyCode: 117, code: 'F6', key: 'F6' },
    F7: { keyCode: 118, code: 'F7', key: 'F7' },
    F8: { keyCode: 119, code: 'F8', key: 'F8' },
    F9: { keyCode: 120, code: 'F9', key: 'F9' },
    F10: { keyCode: 121, code: 'F10', key: 'F10' },
    F11: { keyCode: 122, code: 'F11', key: 'F11' },
    F12: { keyCode: 123, code: 'F12', key: 'F12' },
    F13: { keyCode: 124, code: 'F13', key: 'F13' },
    F14: { keyCode: 125, code: 'F14', key: 'F14' },
    F15: { keyCode: 126, code: 'F15', key: 'F15' },
    F16: { keyCode: 127, code: 'F16', key: 'F16' },
    F17: { keyCode: 128, code: 'F17', key: 'F17' },
    F18: { keyCode: 129, code: 'F18', key: 'F18' },
    F19: { keyCode: 130, code: 'F19', key: 'F19' },
    F20: { keyCode: 131, code: 'F20', key: 'F20' },
    F21: { keyCode: 132, code: 'F21', key: 'F21' },
    F22: { keyCode: 133, code: 'F22', key: 'F22' },
    F23: { keyCode: 134, code: 'F23', key: 'F23' },
    F24: { keyCode: 135, code: 'F24', key: 'F24' },
    NumLock: { keyCode: 144, code: 'NumLock', key: 'NumLock' },
    ScrollLock: { keyCode: 145, code: 'ScrollLock', key: 'ScrollLock' },
    AudioVolumeMute: {
        keyCode: 173,
        code: 'AudioVolumeMute',
        key: 'AudioVolumeMute',
    },
    AudioVolumeDown: {
        keyCode: 174,
        code: 'AudioVolumeDown',
        key: 'AudioVolumeDown',
    },
    AudioVolumeUp: { keyCode: 175, code: 'AudioVolumeUp', key: 'AudioVolumeUp' },
    MediaTrackNext: {
        keyCode: 176,
        code: 'MediaTrackNext',
        key: 'MediaTrackNext',
    },
    MediaTrackPrevious: {
        keyCode: 177,
        code: 'MediaTrackPrevious',
        key: 'MediaTrackPrevious',
    },
    MediaStop: { keyCode: 178, code: 'MediaStop', key: 'MediaStop' },
    MediaPlayPause: {
        keyCode: 179,
        code: 'MediaPlayPause',
        key: 'MediaPlayPause',
    },
    Semicolon: { keyCode: 186, code: 'Semicolon', shiftKey: ':', key: ';' },
    Equal: { keyCode: 187, code: 'Equal', shiftKey: '+', key: '=' },
    NumpadEqual: { keyCode: 187, code: 'NumpadEqual', key: '=', location: 3 },
    Comma: { keyCode: 188, code: 'Comma', shiftKey: '<', key: ',' },
    Minus: { keyCode: 189, code: 'Minus', shiftKey: '_', key: '-' },
    Period: { keyCode: 190, code: 'Period', shiftKey: '>', key: '.' },
    Slash: { keyCode: 191, code: 'Slash', shiftKey: '?', key: '/' },
    Backquote: { keyCode: 192, code: 'Backquote', shiftKey: '~', key: '`' },
    BracketLeft: { keyCode: 219, code: 'BracketLeft', shiftKey: '{', key: '[' },
    Backslash: { keyCode: 220, code: 'Backslash', shiftKey: '|', key: '\\' },
    BracketRight: { keyCode: 221, code: 'BracketRight', shiftKey: '}', key: ']' },
    Quote: { keyCode: 222, code: 'Quote', shiftKey: '"', key: "'" },
    AltGraph: { keyCode: 225, code: 'AltGraph', key: 'AltGraph' },
    Props: { keyCode: 247, code: 'Props', key: 'CrSel' },
    Cancel: { keyCode: 3, key: 'Cancel', code: 'Abort' },
    Clear: { keyCode: 12, key: 'Clear', code: 'Numpad5', location: 3 },
    Shift: { keyCode: 16, key: 'Shift', code: 'ShiftLeft', location: 1 },
    Control: { keyCode: 17, key: 'Control', code: 'ControlLeft', location: 1 },
    Alt: { keyCode: 18, key: 'Alt', code: 'AltLeft', location: 1 },
    Accept: { keyCode: 30, key: 'Accept' },
    ModeChange: { keyCode: 31, key: 'ModeChange' },
    ' ': { keyCode: 32, key: ' ', code: 'Space' },
    Print: { keyCode: 42, key: 'Print' },
    Execute: { keyCode: 43, key: 'Execute', code: 'Open' },
    '\u0000': { keyCode: 46, key: '\u0000', code: 'NumpadDecimal', location: 3 },
    a: { keyCode: 65, key: 'a', code: 'KeyA' },
    b: { keyCode: 66, key: 'b', code: 'KeyB' },
    c: { keyCode: 67, key: 'c', code: 'KeyC' },
    d: { keyCode: 68, key: 'd', code: 'KeyD' },
    e: { keyCode: 69, key: 'e', code: 'KeyE' },
    f: { keyCode: 70, key: 'f', code: 'KeyF' },
    g: { keyCode: 71, key: 'g', code: 'KeyG' },
    h: { keyCode: 72, key: 'h', code: 'KeyH' },
    i: { keyCode: 73, key: 'i', code: 'KeyI' },
    j: { keyCode: 74, key: 'j', code: 'KeyJ' },
    k: { keyCode: 75, key: 'k', code: 'KeyK' },
    l: { keyCode: 76, key: 'l', code: 'KeyL' },
    m: { keyCode: 77, key: 'm', code: 'KeyM' },
    n: { keyCode: 78, key: 'n', code: 'KeyN' },
    o: { keyCode: 79, key: 'o', code: 'KeyO' },
    p: { keyCode: 80, key: 'p', code: 'KeyP' },
    q: { keyCode: 81, key: 'q', code: 'KeyQ' },
    r: { keyCode: 82, key: 'r', code: 'KeyR' },
    s: { keyCode: 83, key: 's', code: 'KeyS' },
    t: { keyCode: 84, key: 't', code: 'KeyT' },
    u: { keyCode: 85, key: 'u', code: 'KeyU' },
    v: { keyCode: 86, key: 'v', code: 'KeyV' },
    w: { keyCode: 87, key: 'w', code: 'KeyW' },
    x: { keyCode: 88, key: 'x', code: 'KeyX' },
    y: { keyCode: 89, key: 'y', code: 'KeyY' },
    z: { keyCode: 90, key: 'z', code: 'KeyZ' },
    Meta: { keyCode: 91, key: 'Meta', code: 'MetaLeft', location: 1 },
    '*': { keyCode: 106, key: '*', code: 'NumpadMultiply', location: 3 },
    '+': { keyCode: 107, key: '+', code: 'NumpadAdd', location: 3 },
    '-': { keyCode: 109, key: '-', code: 'NumpadSubtract', location: 3 },
    '/': { keyCode: 111, key: '/', code: 'NumpadDivide', location: 3 },
    ';': { keyCode: 186, key: ';', code: 'Semicolon' },
    '=': { keyCode: 187, key: '=', code: 'Equal' },
    ',': { keyCode: 188, key: ',', code: 'Comma' },
    '.': { keyCode: 190, key: '.', code: 'Period' },
    '`': { keyCode: 192, key: '`', code: 'Backquote' },
    '[': { keyCode: 219, key: '[', code: 'BracketLeft' },
    '\\': { keyCode: 220, key: '\\', code: 'Backslash' },
    ']': { keyCode: 221, key: ']', code: 'BracketRight' },
    "'": { keyCode: 222, key: "'", code: 'Quote' },
    Attn: { keyCode: 246, key: 'Attn' },
    CrSel: { keyCode: 247, key: 'CrSel', code: 'Props' },
    ExSel: { keyCode: 248, key: 'ExSel' },
    EraseEof: { keyCode: 249, key: 'EraseEof' },
    Play: { keyCode: 250, key: 'Play' },
    ZoomOut: { keyCode: 251, key: 'ZoomOut' },
    ')': { keyCode: 48, key: ')', code: 'Digit0' },
    '!': { keyCode: 49, key: '!', code: 'Digit1' },
    '@': { keyCode: 50, key: '@', code: 'Digit2' },
    '#': { keyCode: 51, key: '#', code: 'Digit3' },
    $: { keyCode: 52, key: '$', code: 'Digit4' },
    '%': { keyCode: 53, key: '%', code: 'Digit5' },
    '^': { keyCode: 54, key: '^', code: 'Digit6' },
    '&': { keyCode: 55, key: '&', code: 'Digit7' },
    '(': { keyCode: 57, key: '(', code: 'Digit9' },
    A: { keyCode: 65, key: 'A', code: 'KeyA' },
    B: { keyCode: 66, key: 'B', code: 'KeyB' },
    C: { keyCode: 67, key: 'C', code: 'KeyC' },
    D: { keyCode: 68, key: 'D', code: 'KeyD' },
    E: { keyCode: 69, key: 'E', code: 'KeyE' },
    F: { keyCode: 70, key: 'F', code: 'KeyF' },
    G: { keyCode: 71, key: 'G', code: 'KeyG' },
    H: { keyCode: 72, key: 'H', code: 'KeyH' },
    I: { keyCode: 73, key: 'I', code: 'KeyI' },
    J: { keyCode: 74, key: 'J', code: 'KeyJ' },
    K: { keyCode: 75, key: 'K', code: 'KeyK' },
    L: { keyCode: 76, key: 'L', code: 'KeyL' },
    M: { keyCode: 77, key: 'M', code: 'KeyM' },
    N: { keyCode: 78, key: 'N', code: 'KeyN' },
    O: { keyCode: 79, key: 'O', code: 'KeyO' },
    P: { keyCode: 80, key: 'P', code: 'KeyP' },
    Q: { keyCode: 81, key: 'Q', code: 'KeyQ' },
    R: { keyCode: 82, key: 'R', code: 'KeyR' },
    S: { keyCode: 83, key: 'S', code: 'KeyS' },
    T: { keyCode: 84, key: 'T', code: 'KeyT' },
    U: { keyCode: 85, key: 'U', code: 'KeyU' },
    V: { keyCode: 86, key: 'V', code: 'KeyV' },
    W: { keyCode: 87, key: 'W', code: 'KeyW' },
    X: { keyCode: 88, key: 'X', code: 'KeyX' },
    Y: { keyCode: 89, key: 'Y', code: 'KeyY' },
    Z: { keyCode: 90, key: 'Z', code: 'KeyZ' },
    ':': { keyCode: 186, key: ':', code: 'Semicolon' },
    '<': { keyCode: 188, key: '<', code: 'Comma' },
    _: { keyCode: 189, key: '_', code: 'Minus' },
    '>': { keyCode: 190, key: '>', code: 'Period' },
    '?': { keyCode: 191, key: '?', code: 'Slash' },
    '~': { keyCode: 192, key: '~', code: 'Backquote' },
    '{': { keyCode: 219, key: '{', code: 'BracketLeft' },
    '|': { keyCode: 220, key: '|', code: 'Backslash' },
    '}': { keyCode: 221, key: '}', code: 'BracketRight' },
    '"': { keyCode: 222, key: '"', code: 'Quote' },
    SoftLeft: { key: 'SoftLeft', code: 'SoftLeft', location: 4 },
    SoftRight: { key: 'SoftRight', code: 'SoftRight', location: 4 },
    Camera: { keyCode: 44, key: 'Camera', code: 'Camera', location: 4 },
    Call: { key: 'Call', code: 'Call', location: 4 },
    EndCall: { keyCode: 95, key: 'EndCall', code: 'EndCall', location: 4 },
    VolumeDown: {
        keyCode: 182,
        key: 'VolumeDown',
        code: 'VolumeDown',
        location: 4,
    },
    VolumeUp: { keyCode: 183, key: 'VolumeUp', code: 'VolumeUp', location: 4 },
};


/***/ }),

/***/ 1979:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const getFrameUrl = (tabId, primaryKey) => new Promise((resolve) => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.scripting
        .executeScript({
        target: { tabId, frameIds: [0] },
        func: (args) => {
            try {
                let result;
                const elements = document.querySelectorAll('div[data-keybinding-context]');
                elements.forEach((element) => {
                    var _a, _b;
                    const key = element.getAttribute('data-keybinding-context');
                    if (!result && key === args.primaryKey) {
                        result = (_b = (_a = element.querySelector('iframe')) === null || _a === void 0 ? void 0 : _a.src) !== null && _b !== void 0 ? _b : '';
                    }
                });
                return result;
            }
            catch (_a) {
                return undefined;
            }
        },
        args: [{ primaryKey }],
    })
        .then((injectionResults) => {
        if (injectionResults.length) {
            for (const { frameId, result } of injectionResults) {
                console.log(`Frame ${frameId} result:`, result);
                resolve(result);
            }
        }
        else {
            resolve(undefined);
        }
    })
        .catch(() => {
        resolve(undefined);
    });
}));
exports["default"] = (tabId, key) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    // 首先获取到所有的 Frame
    const frames = yield chrome.webNavigation.getAllFrames({ tabId });
    // 通过 key 找到顶层 iframe 并返回 iframe 的 src
    const frameURL = yield getFrameUrl(tabId, key);
    // 匹配出当前 frameID 对应的 frames 数据
    const frame = frames === null || frames === void 0 ? void 0 : frames.find((v) => v.url === frameURL);
    if (frame) {
        const frameID = (_a = frames === null || frames === void 0 ? void 0 : frames.find((v) => v.parentFrameId === frame.frameId)) === null || _a === void 0 ? void 0 : _a.frameId;
        if (frameID) {
            return frameID;
        }
        else {
            return undefined;
        }
    }
    else {
        return undefined;
    }
});


/***/ }),

/***/ 590:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const getPrimaryKey = (tabId, src) => new Promise((resolve) => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.scripting
        .executeScript({
        target: { tabId, frameIds: [0] },
        func: (args) => {
            try {
                let result;
                const elements = document.querySelectorAll('div[data-keybinding-context]');
                elements.forEach((element) => {
                    const key = element.getAttribute('data-keybinding-context');
                    if (key) {
                        const frames = element.querySelectorAll('iframe');
                        frames.forEach((frame) => {
                            console.log('frames', frame.src, args.src);
                            if (!result && frame.src === args.src) {
                                result = key;
                            }
                        });
                    }
                });
                return result;
            }
            catch (_a) {
                return undefined;
            }
        },
        args: [{ src }],
    })
        .then((injectionResults) => {
        if (injectionResults.length) {
            for (const { frameId, result } of injectionResults) {
                console.log(`Frame ${frameId} result:`, result);
                resolve(result);
            }
        }
        else {
            resolve(undefined);
        }
    })
        .catch(() => {
        resolve(undefined);
    });
}));
const findFrame = (id, frames) => {
    var _a;
    if (!id) {
        return undefined;
    }
    const frame = frames === null || frames === void 0 ? void 0 : frames.find((v) => v.frameId === id);
    if ((frame === null || frame === void 0 ? void 0 : frame.parentFrameId) === 0) {
        return frame;
    }
    else {
        return findFrame((_a = frame === null || frame === void 0 ? void 0 : frame.parentFrameId) !== null && _a !== void 0 ? _a : 0, frames);
    }
};
exports["default"] = (tabId, frameID) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    // 首先获取到所有的 Frame
    const frames = yield chrome.webNavigation.getAllFrames({ tabId });
    // 匹配出当前 frameID 对应的 frames 数据
    const frame = frames === null || frames === void 0 ? void 0 : frames.find((v) => v.frameId === frameID);
    if (frame) {
        const src = (_a = findFrame(frame.frameId, frames !== null && frames !== void 0 ? frames : [])) === null || _a === void 0 ? void 0 : _a.url;
        if (src) {
            const key = yield getPrimaryKey(tabId, src);
            return key;
        }
        else {
            return undefined;
        }
    }
    else {
        return undefined;
    }
});


/***/ }),

/***/ 1764:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable max-depth */
/* eslint-disable max-len */
/* eslint-disable max-lines-per-function */
const interface_1 = __webpack_require__(1615);
const replay_1 = __importDefault(__webpack_require__(3151));
// import captureImageHandle from './screen-capture'
const traffic_manager_1 = __importStar(__webpack_require__(6734));
const utils_1 = __webpack_require__(7741);
const uuid_1 = __webpack_require__(5546);
const get_frame_key_1 = __importDefault(__webpack_require__(590));
const get_frame_by_key_1 = __importDefault(__webpack_require__(1979));
const recordingInfo = {
    targetWindow: undefined,
    platformWindow: undefined,
    recordingStartTab: undefined,
    recordingAssertPlatformTab: undefined,
};
const executionInfo = {
    targetWindow: undefined,
    platformWindow: undefined,
    targetTab: undefined,
    debuggerAttached: false,
    platformTab: undefined,
};
let workAreaWidth, workAreaHeight, _h;
let cookieQueue = [];
let delCookieQueue = [];
const injectMapping = new Map();
function headersArray(headers) {
    const result = [];
    for (const name in headers) {
        const value = headers[name];
        if (!Object.is(value, undefined)) {
            const values = Array.isArray(value) ? value : [value];
            const r = values.map((v) => ({ name, value: `${v}` }));
            result.push(...r);
        }
    }
    return result;
}
function initWorkArea() {
    return __awaiter(this, void 0, void 0, function* () {
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        yield chrome.system.display.getInfo().then((devices) => {
            for (const device of devices) {
                if (device.isPrimary || (device.bounds.left === 0 && device.bounds.top === 0)) {
                    const { workArea } = device;
                    workAreaWidth = workArea.width;
                    workAreaHeight = workArea.height;
                }
            }
        });
    });
}
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
function closeWindow(windowId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (windowId) {
                const target = yield chrome.windows.get(windowId);
                if (target) {
                    yield chrome.windows.remove(windowId);
                    console.log('close window success', windowId);
                }
            }
        }
        catch (e) {
            throw Error(`close window exception: ${e}`);
        }
    });
}
function resetCookie() {
    var _a;
    try {
        (_a = cookieQueue === null || cookieQueue === void 0 ? void 0 : cookieQueue.reverse()) === null || _a === void 0 ? void 0 : _a.forEach(({ url, cookie: c }) => __awaiter(this, void 0, void 0, function* () {
            yield chrome.cookies.remove({
                name: c.name,
                url,
            });
            try {
                yield chrome.cookies.set({
                    domain: c.domain,
                    name: c.name,
                    url,
                    value: c.value,
                    expirationDate: c.expirationDate,
                    path: c.path,
                    httpOnly: Boolean(c === null || c === void 0 ? void 0 : c.hostOnly) || false,
                    secure: Boolean(c === null || c === void 0 ? void 0 : c.secure) || false,
                    sameSite: c.sameSite,
                });
            }
            catch (e) {
                console.error('set-cookie in reset error:', Object.assign(Object.assign({}, c), { httpOnly: Boolean(c === null || c === void 0 ? void 0 : c.hostOnly) || false, secure: Boolean(c === null || c === void 0 ? void 0 : c.secure) || false, url }), e);
            }
        }));
        cookieQueue = [];
        console.log('delCookieQueue', delCookieQueue);
        delCookieQueue === null || delCookieQueue === void 0 ? void 0 : delCookieQueue.forEach((c) => __awaiter(this, void 0, void 0, function* () {
            yield chrome.cookies.remove(c);
        }));
        delCookieQueue = [];
    }
    catch (e) {
        console.error('reset-cookie error：', e);
    }
}
// async function closeTab(tabId?: number) {
//   try {
//     if (tabId) {
//       const oldTab = await chrome.tabs.get(tabId)
//       if (oldTab) {
//         await chrome.tabs.remove(tabId)
//       }
//     } else {
//       throw Error(`invalid windowId: ${tabId}`)
//     }
//   } catch (e) {
//     throw Error(`close Tab exception ${e}`)
//   }
// }
const protocolVersion = '1.3';
const updateModifyHeaderInfo = (headers) => __awaiter(void 0, void 0, void 0, function* () {
    _h = headers;
    // 先删除掉
    yield chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [999],
    });
    const requestHeaders = [];
    if (headers) {
        Object.keys(headers).forEach((key) => {
            const val = headers[key];
            if (val !== undefined) {
                requestHeaders.push({
                    header: key,
                    operation: chrome.declarativeNetRequest.HeaderOperation.SET,
                    value: `${val}`,
                });
            }
        });
        if (requestHeaders.length) {
            console.log('requestHeaders', requestHeaders);
            yield chrome.declarativeNetRequest.updateDynamicRules({
                addRules: [
                    {
                        id: 999,
                        priority: 1,
                        action: {
                            type: chrome.declarativeNetRequest.RuleActionType.MODIFY_HEADERS,
                            requestHeaders,
                        },
                        condition: {
                            urlFilter: '*',
                        },
                    },
                ],
            });
        }
    }
});
const InjectE2ESessionIDInUrl = (sid) => __awaiter(void 0, void 0, void 0, function* () {
    if (!sid) {
        yield chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1],
        });
    }
    else {
        yield chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1, 2],
            addRules: [
                {
                    id: 1,
                    priority: 1,
                    action: {
                        type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                        redirect: {
                            transform: {
                                queryTransform: {
                                    addOrReplaceParams: [{ key: 'e2e-session-id', value: sid }],
                                },
                            },
                        },
                    },
                    condition: {
                        urlFilter: '||ide-boe.byted.org',
                        resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME],
                    },
                },
                {
                    id: 2,
                    priority: 1,
                    action: {
                        type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                        redirect: {
                            transform: {
                                queryTransform: {
                                    addOrReplaceParams: [{ key: 'e2e-session-id', value: sid }],
                                },
                            },
                        },
                    },
                    condition: {
                        urlFilter: '||ide.byted.org',
                        resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME],
                    },
                },
            ],
        });
    }
});
const handleStartRecording = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _g, _j, _k, _l, _m;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'start_record') {
            console.log('start_record', message);
            const payload = message.data;
            // 参数校验
            if (!(payload === null || payload === void 0 ? void 0 : payload.assertRecordUrl)) {
                throw Error('invalid platform Url');
            }
            if (!(payload === null || payload === void 0 ? void 0 : payload.url)) {
                throw Error('invalid target Uri');
            }
            // 强制关闭已经打开的录制目标页面（右侧）
            yield closeWindow((_a = recordingInfo.targetWindow) === null || _a === void 0 ? void 0 : _a.id);
            // 强制关闭已经打开的录制是的平台页面（左侧）
            yield closeWindow((_b = recordingInfo.platformWindow) === null || _b === void 0 ? void 0 : _b.id);
            // 等待 window 关闭回调处理（重置 recordingInfo）
            yield sleep(1000);
            // 获取屏幕宽高
            yield initWorkArea();
            yield updateModifyHeaderInfo(payload.headers);
            // 创建 目标页面 window
            const targetWindow = yield chrome.windows.create({
                url: (payload === null || payload === void 0 ? void 0 : payload.target) || 'https://assert-mnt.bytedance.net/apaas-workbench/target',
                type: 'popup',
                left: 0,
                top: 0,
            });
            if (!(targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.id)) {
                throw Error('create window error, targetWindow.id is invalid');
            }
            if (!((_c = targetWindow.tabs) === null || _c === void 0 ? void 0 : _c[0])) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, targetWindow default tab.id is invalid');
            }
            yield chrome.windows.update(targetWindow.id, {
                state: 'normal',
            });
            const height = Math.floor(Number(workAreaHeight));
            yield chrome.windows.update(targetWindow.id, {
                left: 0,
                top: 0,
                width: Math.floor(workAreaWidth * 0.8),
                height,
                // width: 1092,
                // height: 614,
            });
            const platformWindow = yield chrome.windows.create({
                top: 0,
                width: Math.floor(workAreaWidth * 0.2),
                height,
                left: Math.floor(workAreaWidth * 0.8),
                url: payload.assertRecordUrl,
                type: 'popup',
            });
            if (!(platformWindow === null || platformWindow === void 0 ? void 0 : platformWindow.id)) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, platformWindow.id is invalid');
            }
            if (!((_d = platformWindow.tabs) === null || _d === void 0 ? void 0 : _d[0])) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, platformWindow default tab.id is invalid');
            }
            recordingInfo.targetWindow = targetWindow;
            recordingInfo.platformWindow = platformWindow;
            recordingInfo.recordingStartTab = (_e = targetWindow.tabs) === null || _e === void 0 ? void 0 : _e[0];
            recordingInfo.recordingAssertPlatformTab = (_g = platformWindow.tabs) === null || _g === void 0 ? void 0 : _g[0];
            yield chrome.debugger.attach({ tabId: (_j = recordingInfo.recordingStartTab) === null || _j === void 0 ? void 0 : _j.id }, protocolVersion);
            yield chrome.debugger.sendCommand({ tabId: (_k = recordingInfo.recordingStartTab) === null || _k === void 0 ? void 0 : _k.id }, 'Fetch.enable', {
                patterns: [{ urlPattern: '*', resourceType: 'Document', requestStage: 'Request' }],
            });
            yield chrome.tabs.update((_m = (_l = recordingInfo.recordingStartTab) === null || _l === void 0 ? void 0 : _l.id) !== null && _m !== void 0 ? _m : 0, {
                url: payload.url,
            });
        }
    }
    catch (e) {
        console.error('handleStartRecording exception: ', e);
    }
});
const handleStopRecording = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _o, _p;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'end-record') {
            yield closeWindow((_o = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.targetWindow) === null || _o === void 0 ? void 0 : _o.id);
            yield closeWindow((_p = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _p === void 0 ? void 0 : _p.id);
        }
    }
    catch (e) {
        console.error('handleStopRecording exception: ', e);
    }
});
const checkRecordingWindows = () => __awaiter(void 0, void 0, void 0, function* () {
    var _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2;
    if (!((_q = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.targetWindow) === null || _q === void 0 ? void 0 : _q.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: 'invalid targetWindow.id',
        });
    }
    if (!((_r = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _r === void 0 ? void 0 : _r.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: 'invalid platformWindow.id',
        });
    }
    // 校验 tab id 是否存在
    if (!((_s = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _s === void 0 ? void 0 : _s.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid targetWindow default tab.id, tab.id:${(_t = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _t === void 0 ? void 0 : _t.id}`,
        });
    }
    // 校验 Window ID 是否与 当前 tab 的 WindowId 匹配
    if ((recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab.windowId) !== recordingInfo.targetWindow.id) {
        return Promise.resolve({
            success: false,
            errorMsg: `targetPage window id does not match ! tab.windowId is ${recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab.windowId}, targetWindow.id is ${(_u = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.targetWindow) === null || _u === void 0 ? void 0 : _u.id}`,
        });
    }
    // 校验 tab id 是否存在
    if (!((_v = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _v === void 0 ? void 0 : _v.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid platformWindow default tab.id, tab.id:${(_w = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _w === void 0 ? void 0 : _w.id}`,
        });
    }
    // 校验 Window ID 是否与 当前 tab 的 WindowId 匹配
    if ((recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab.windowId) !== ((_x = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _x === void 0 ? void 0 : _x.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `platformPage window id does not match ! tab.windowId is ${recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab.windowId}, platformWindow.id is ${(_y = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _y === void 0 ? void 0 : _y.id}`,
        });
    }
    const target = yield chrome.windows.get((_z = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.targetWindow) === null || _z === void 0 ? void 0 : _z.id, { populate: true });
    if (!((_0 = target.tabs) === null || _0 === void 0 ? void 0 : _0.length)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid targetWindow value, value is ${target}`,
        });
    }
    if (!target.tabs.find((v) => { var _a; return v.id === ((_a = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _a === void 0 ? void 0 : _a.id); })) {
        return Promise.resolve({
            success: false,
            errorMsg: `target tab does not exist ${target.tabs}`,
        });
    }
    const platform = yield chrome.windows.get((_1 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _1 === void 0 ? void 0 : _1.id, { populate: true });
    if (!((_2 = platform.tabs) === null || _2 === void 0 ? void 0 : _2.length)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid platformWindow value, value is ${target}`,
        });
    }
    if (!platform.tabs.find((v) => { var _a; return v.id === ((_a = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _a === void 0 ? void 0 : _a.id); })) {
        return Promise.resolve({
            success: false,
            errorMsg: `platform tab does not exist ${target.tabs}`,
        });
    }
    return Promise.resolve({ success: true });
});
const checkReplayWindows = () => __awaiter(void 0, void 0, void 0, function* () {
    var _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15;
    if (!((_3 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetWindow) === null || _3 === void 0 ? void 0 : _3.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: 'invalid targetWindow.id',
        });
    }
    if (!((_4 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformWindow) === null || _4 === void 0 ? void 0 : _4.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: 'invalid platformWindow.id',
        });
    }
    // 校验 tab id 是否存在
    if (!((_5 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) === null || _5 === void 0 ? void 0 : _5.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid targetWindow default tab.id, tab.id:${(_6 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) === null || _6 === void 0 ? void 0 : _6.id}`,
        });
    }
    // 校验 Window ID 是否与 当前 tab 的 WindowId 匹配
    if ((executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab.windowId) !== executionInfo.targetWindow.id) {
        return Promise.resolve({
            success: false,
            errorMsg: `targetPage window id does not match ! tab.windowId is ${executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab.windowId}, targetWindow.id is ${(_7 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetWindow) === null || _7 === void 0 ? void 0 : _7.id}`,
        });
    }
    // 校验 tab id 是否存在
    if (!((_8 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _8 === void 0 ? void 0 : _8.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid platformWindow default tab.id, tab.id:${(_9 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _9 === void 0 ? void 0 : _9.id}`,
        });
    }
    // 校验 Window ID 是否与 当前 tab 的 WindowId 匹配
    if ((executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab.windowId) !== ((_10 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformWindow) === null || _10 === void 0 ? void 0 : _10.id)) {
        return Promise.resolve({
            success: false,
            errorMsg: `platformPage window id does not match ! tab.windowId is ${executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab.windowId}, platformWindow.id is ${(_11 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformWindow) === null || _11 === void 0 ? void 0 : _11.id}`,
        });
    }
    const target = yield chrome.windows.get((_12 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetWindow) === null || _12 === void 0 ? void 0 : _12.id, { populate: true });
    if (!((_13 = target.tabs) === null || _13 === void 0 ? void 0 : _13.length)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid targetWindow value, value is ${target}`,
        });
    }
    if (!target.tabs.find((v) => { var _a; return v.id === ((_a = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) === null || _a === void 0 ? void 0 : _a.id); })) {
        return Promise.resolve({
            success: false,
            errorMsg: `target tab does not exist ${target.tabs}`,
        });
    }
    const platform = yield chrome.windows.get((_14 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformWindow) === null || _14 === void 0 ? void 0 : _14.id, { populate: true });
    if (!((_15 = platform.tabs) === null || _15 === void 0 ? void 0 : _15.length)) {
        return Promise.resolve({
            success: false,
            errorMsg: `invalid platformWindow value, value is ${target}`,
        });
    }
    if (!platform.tabs.find((v) => { var _a; return v.id === ((_a = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _a === void 0 ? void 0 : _a.id); })) {
        return Promise.resolve({
            success: false,
            errorMsg: `platform tab does not exist ${target.tabs}`,
        });
    }
    return Promise.resolve({ success: true });
});
const handleRecordingEventClickAsHover = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _16, _17;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'clickAsHover') {
            // 校验录制相关 Window 和 tab 是否存在
            const checkResult = yield checkRecordingWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            yield chrome.storage.session.set({ clickAsHover: message.data });
            yield chrome.tabs.sendMessage((_17 = (_16 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _16 === void 0 ? void 0 : _16.id) !== null && _17 !== void 0 ? _17 : 0, message);
        }
    }
    catch (e) {
        console.error('handleRecordingEventClickAsHover exception: ', e);
    }
});
const handleRecordingEventPauseRecording = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _18, _19;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'pauseRecording') {
            // 校验录制相关 Window 和 tab 是否存在
            const checkResult = yield checkRecordingWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            yield chrome.storage.session.set({ pauseRecording: message.data });
            yield chrome.tabs.sendMessage((_19 = (_18 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _18 === void 0 ? void 0 : _18.id) !== null && _19 !== void 0 ? _19 : 0, message);
        }
    }
    catch (e) {
        console.error('handleRecordingEventPauseRecording exception: ', e);
    }
});
const handleRecordingEventCapture = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _20, _21, _22, _23;
    try {
        // 接收 Record SDK (content-js) 发送的 事件捕获信息
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mnt-rr-event-capture') {
            // 校验录制相关 Window 和 tab 是否存在
            const checkResult = yield checkRecordingWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (message === null || message === void 0 ? void 0 : message.frameID) {
                const key = yield (0, get_frame_key_1.default)((_21 = (_20 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _20 === void 0 ? void 0 : _20.id) !== null && _21 !== void 0 ? _21 : 0, message === null || message === void 0 ? void 0 : message.frameID);
                console.log('getFrameKey', key);
                if (key) {
                    message.data.payload.source.frameKey = key;
                }
            }
            yield chrome.tabs.sendMessage((_23 = (_22 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _22 === void 0 ? void 0 : _22.id) !== null && _23 !== void 0 ? _23 : 0, message.data);
        }
    }
    catch (e) {
        console.error('handleRecordingEventCapture exception: ', e);
    }
});
const handleRecordingToggleUrl = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _24, _25;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'toggleUrl') {
            yield chrome.tabs.update((_25 = (_24 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _24 === void 0 ? void 0 : _24.id) !== null && _25 !== void 0 ? _25 : 0, { url: message.data });
        }
    }
    catch (e) {
        console.error('handleRecordingToggleUrl exception: ', e);
    }
});
const handleRestartRecording = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _26, _27, _28, _29;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'restart_record') {
            const checkResult = yield checkRecordingWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            injectMapping.delete((_27 = (_26 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _26 === void 0 ? void 0 : _26.id) !== null && _27 !== void 0 ? _27 : 0);
            yield chrome.tabs.reload((_29 = (_28 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingStartTab) === null || _28 === void 0 ? void 0 : _28.id) !== null && _29 !== void 0 ? _29 : 0);
        }
    }
    catch (e) {
        console.error('handleRestartRecording exception: ', e);
    }
});
const handleStopReplay = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _30, _31;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'end-execution') {
            yield updateModifyHeaderInfo();
            yield closeWindow((_30 = executionInfo.targetWindow) === null || _30 === void 0 ? void 0 : _30.id);
            yield closeWindow((_31 = executionInfo.platformWindow) === null || _31 === void 0 ? void 0 : _31.id);
        }
    }
    catch (e) {
        console.error('handleStopReplay exception: ', e);
    }
});
const handleOpenTaskDetail = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _32;
    if ((message === null || message === void 0 ? void 0 : message.type) === 'open-task-detail') {
        if ((_32 = message === null || message === void 0 ? void 0 : message.data) === null || _32 === void 0 ? void 0 : _32.url) {
            try {
                yield initWorkArea();
                const window = yield chrome.windows.create({
                    url: message === null || message === void 0 ? void 0 : message.data.url,
                    type: 'popup',
                    left: 0,
                    top: 0,
                });
                if (window.id) {
                    yield chrome.windows.update(window.id, {
                        state: 'normal',
                    });
                    yield chrome.windows.update(window.id, {
                        top: 0,
                        left: 0,
                        width: Math.floor(Number(workAreaWidth)),
                        height: Math.floor(Number(workAreaHeight)),
                    });
                }
                else {
                    throw Error(`invalid window.id ${window}`);
                }
            }
            catch (e) {
                console.error('handleOpenTaskDetail exception: ', e);
            }
        }
        else {
            console.error('handleOpenTaskDetail exception: invalid url', message.data);
        }
    }
});
const handleTriggerEvent = (message) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'replay') {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) {
                yield (0, replay_1.default)(message === null || message === void 0 ? void 0 : message.data, executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab);
            }
            else {
                throw Error('invalid tab, target Tab is undefined');
            }
        }
    }
    catch (e) {
        console.error('handleTriggerEvent exception: ', e);
    }
});
const handleSendEventReplayResultToPlatform = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _33;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mtn-event-trigger-result') {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if ((_33 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _33 === void 0 ? void 0 : _33.id) {
                yield chrome.tabs.sendMessage(executionInfo.platformTab.id, message);
            }
            else {
                throw Error('invalid tab, target Tab is undefined');
            }
        }
    }
    catch (e) {
        console.error('handleSendEventReplayResultToPlatform exception: ', e);
    }
});
const handleSendEventReplayToggleUrl = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _34, _35, _36;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mtn-event-trigger-toggle-url') {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            const sendEventToPlatform = (changes, area) => {
                var _a, _b, _c;
                if (area === 'session' && ((_a = changes === null || changes === void 0 ? void 0 : changes.replayLoaded) === null || _a === void 0 ? void 0 : _a.newValue)) {
                    const platformMessage = {
                        type: 'mtn-event-trigger-result',
                        payload: {
                            type: message.payload.type,
                            success: true,
                            failInfo: undefined,
                            clickExtra: undefined,
                        },
                    };
                    chrome.storage.onChanged.removeListener(sendEventToPlatform);
                    chrome.tabs.sendMessage((_c = (_b = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _b === void 0 ? void 0 : _b.id) !== null && _c !== void 0 ? _c : 0, platformMessage);
                }
            };
            chrome.storage.onChanged.addListener(sendEventToPlatform);
            yield chrome.tabs.update((_35 = (_34 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) === null || _34 === void 0 ? void 0 : _34.id) !== null && _35 !== void 0 ? _35 : 0, { url: (_36 = message === null || message === void 0 ? void 0 : message.payload) === null || _36 === void 0 ? void 0 : _36.data });
        }
    }
    catch (e) {
        console.error('handleSendEventReplayToggleUrl exception: ', e);
    }
});
const handleStarReplay = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51;
    const action = message;
    try {
        if ((action === null || action === void 0 ? void 0 : action.name) === 'init-execution') {
            if (!(action === null || action === void 0 ? void 0 : action.initExecutionPayload)) {
                throw Error('invalid initExecutionPayload');
            }
            const { size, targetUrl, platformUrl, isFusionMode } = action.initExecutionPayload;
            // 参数校验
            if (!targetUrl) {
                throw Error('invalid targetUrl');
            }
            if (!platformUrl) {
                throw Error('invalid platformUrl');
            }
            // 强制关闭已经打开的录制目标页面（右侧）
            yield closeWindow((_37 = executionInfo.targetWindow) === null || _37 === void 0 ? void 0 : _37.id);
            // 强制关闭已经打开的录制是的平台页面（左侧）
            yield closeWindow((_38 = executionInfo.platformWindow) === null || _38 === void 0 ? void 0 : _38.id);
            // 等待 window 关闭回调处理（重置 recordingInfo）
            yield sleep(1000);
            // 获取屏幕宽高
            yield initWorkArea();
            yield updateModifyHeaderInfo(action.initExecutionPayload.headers);
            const targetWindow = yield chrome.windows.create({
                url: targetUrl,
                type: 'popup',
                left: 0,
                top: 0,
            });
            if (!(targetWindow === null || targetWindow === void 0 ? void 0 : targetWindow.id)) {
                throw Error('create window error, targetWindow.id is invalid');
            }
            if (!((_39 = targetWindow.tabs) === null || _39 === void 0 ? void 0 : _39[0])) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, targetWindow default tab.id is invalid');
            }
            if (targetWindow.id) {
                yield chrome.windows.update(targetWindow.id, {
                    state: 'normal',
                });
                yield chrome.windows.update(targetWindow.id, {
                    left: 0,
                    top: 0,
                    width: (_40 = size === null || size === void 0 ? void 0 : size.width) !== null && _40 !== void 0 ? _40 : Math.floor(workAreaWidth * 0.8),
                    height: (_41 = size === null || size === void 0 ? void 0 : size.height) !== null && _41 !== void 0 ? _41 : Math.floor(Number(workAreaHeight)),
                });
            }
            const platformWindow = yield chrome.windows.create({
                top: 0,
                width: Math.floor(workAreaWidth * 0.2),
                height: (_42 = size === null || size === void 0 ? void 0 : size.height) !== null && _42 !== void 0 ? _42 : Math.floor(Number(workAreaHeight)),
                left: Math.floor(workAreaWidth * 0.8),
                url: platformUrl,
                type: 'popup',
            });
            if (!(platformWindow === null || platformWindow === void 0 ? void 0 : platformWindow.id)) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, platformWindow.id is invalid');
            }
            if (!((_43 = platformWindow.tabs) === null || _43 === void 0 ? void 0 : _43[0])) {
                yield closeWindow(targetWindow.id);
                throw Error('create window error, platformWindow default tab.id is invalid');
            }
            executionInfo.targetWindow = targetWindow;
            executionInfo.platformWindow = platformWindow;
            executionInfo.debuggerAttached = false;
            executionInfo.targetTab = (_44 = targetWindow.tabs) === null || _44 === void 0 ? void 0 : _44[0];
            executionInfo.platformTab = (_45 = platformWindow.tabs) === null || _45 === void 0 ? void 0 : _45[0];
            yield chrome.debugger.attach({ tabId: (_46 = executionInfo.targetTab) === null || _46 === void 0 ? void 0 : _46.id }, protocolVersion);
            yield chrome.debugger.sendCommand({ tabId: (_47 = executionInfo.targetTab) === null || _47 === void 0 ? void 0 : _47.id }, 'Fetch.enable', {
                patterns: [{ urlPattern: '*', resourceType: 'Document', requestStage: 'Request' }],
            });
            if (!executionInfo.debuggerAttached && ((_48 = executionInfo.targetTab) === null || _48 === void 0 ? void 0 : _48.id)) {
                // await chrome.debugger.attach({ tabId: executionInfo.targetTab?.id }, protocolVersion)
                const targetTabId = (_49 = executionInfo.targetTab) === null || _49 === void 0 ? void 0 : _49.id;
                yield traffic_manager_1.default.listen(targetTabId);
                executionInfo.debuggerAttached = true;
            }
            // 同时设置 Record 信息，驱动插件注入相关SDK并开启采集
            if (isFusionMode) {
                recordingInfo.targetWindow = targetWindow;
                recordingInfo.platformWindow = platformWindow;
                recordingInfo.recordingStartTab = (_50 = targetWindow.tabs) === null || _50 === void 0 ? void 0 : _50[0];
                recordingInfo.recordingAssertPlatformTab = (_51 = platformWindow.tabs) === null || _51 === void 0 ? void 0 : _51[0];
            }
            yield chrome.storage.session.set({ executionInfo });
        }
    }
    catch (e) {
        console.error('handleStarReplay exception: ', e);
    }
});
/**
 * 向 Replay SDK 发送事件模拟 command
 */
const handleSendEventSimulationCommandToSDK = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _52, _53, _54, _55, _56, _57, _58, _59;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mnt-event-replay') {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (((_52 = message === null || message === void 0 ? void 0 : message.payload) === null || _52 === void 0 ? void 0 : _52.mockType) === traffic_manager_1.MockType.Mock) {
                const mockTraffics = ((_53 = message === null || message === void 0 ? void 0 : message.payload) === null || _53 === void 0 ? void 0 : _53.mockTraffics) || [];
                traffic_manager_1.default.fillOneStepTraffics(mockTraffics);
            }
            if ((_54 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetTab) === null || _54 === void 0 ? void 0 : _54.id) {
                // 找到 frame
                if ((_56 = (_55 = message === null || message === void 0 ? void 0 : message.payload) === null || _55 === void 0 ? void 0 : _55.frame) === null || _56 === void 0 ? void 0 : _56.url) {
                    const frames = yield chrome.webNavigation.getAllFrames({ tabId: executionInfo.targetTab.id });
                    const _frames = frames === null || frames === void 0 ? void 0 : frames.filter((v) => { var _a, _b; return v.url.includes((_b = (_a = message === null || message === void 0 ? void 0 : message.payload) === null || _a === void 0 ? void 0 : _a.frame) === null || _b === void 0 ? void 0 : _b.url); });
                    let frame;
                    if ((_frames === null || _frames === void 0 ? void 0 : _frames.length) === 1) {
                        frame = _frames[0];
                    }
                    if ((_frames === null || _frames === void 0 ? void 0 : _frames.length) && (_frames === null || _frames === void 0 ? void 0 : _frames.length) > 1) {
                        frame = _frames === null || _frames === void 0 ? void 0 : _frames.sort((a, b) => b.frameId - a.frameId)[0];
                    }
                    if (frame) {
                        let _f = frame;
                        const _fids = [];
                        while (_f) {
                            _fids.push(_f.frameId);
                            _f = frames === null || frames === void 0 ? void 0 : frames.find((v) => _f && v.frameId === _f.parentFrameId);
                        }
                        yield chrome.tabs.sendMessage(executionInfo.targetTab.id, Object.assign(Object.assign({}, message), { fid: _fids.filter((v) => v) }), { frameId: frame.frameId });
                    }
                    else {
                        // 只用于兼容 cloud ide 的场景
                        if (message === null || message === void 0 ? void 0 : message.payload.frameKey) {
                            const fid = yield (0, get_frame_by_key_1.default)((_57 = executionInfo.targetTab.id) !== null && _57 !== void 0 ? _57 : 0, message === null || message === void 0 ? void 0 : message.payload.frameKey);
                            if (fid) {
                                let _f = frames === null || frames === void 0 ? void 0 : frames.find((v) => v.frameId === fid);
                                const _fids = [];
                                while (_f) {
                                    _fids.push(_f.frameId);
                                    _f = frames === null || frames === void 0 ? void 0 : frames.find((v) => _f && v.frameId === _f.parentFrameId);
                                }
                                yield chrome.tabs.sendMessage(executionInfo.targetTab.id, Object.assign(Object.assign({}, message), { fid: _fids.filter((v) => v) }), { frameId: fid });
                            }
                        }
                        else {
                            throw Error('invalid frame, frame is undefined');
                        }
                    }
                }
                else {
                    yield chrome.tabs.sendMessage(executionInfo.targetTab.id, message);
                }
            }
            else {
                throw Error('invalid tab, target Tab is undefined');
            }
        }
    }
    catch (e) {
        console.error('handleSendEventSimulationCommandToSDK exception: ', e);
        // 避免异常时无法正确解决运行
        yield chrome.tabs.sendMessage((_59 = (_58 = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformTab) === null || _58 === void 0 ? void 0 : _58.id) !== null && _59 !== void 0 ? _59 : 0, {
            type: 'mtn-event-trigger-result',
            payload: {
                type: message === null || message === void 0 ? void 0 : message.payload.type,
                success: false,
                failInfo: {
                    failType: interface_1.FailType.JSERROR,
                    failMsg: JSON.stringify(e.message),
                },
            },
        });
    }
});
const handleQueryStepTraffic = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _60, _61;
    try {
        if (message.type === 'get-step-traffic') {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (((_60 = executionInfo.platformTab) === null || _60 === void 0 ? void 0 : _60.id) && ((_61 = executionInfo.targetTab) === null || _61 === void 0 ? void 0 : _61.id)) {
                const { beginTime, endTime } = message.payload;
                const traffics = traffic_manager_1.default.findTrafficBetween(beginTime, endTime).map((traffic) => {
                    var _a, _b, _c, _d;
                    return ({
                        url: (_b = (_a = traffic.request) === null || _a === void 0 ? void 0 : _a.request.url) !== null && _b !== void 0 ? _b : '',
                        request: JSON.stringify(Object.assign(Object.assign({}, (_c = traffic.request) === null || _c === void 0 ? void 0 : _c.request), traffic.requestExtra)),
                        response: JSON.stringify(Object.assign(Object.assign({ headers: (_d = traffic.response) === null || _d === void 0 ? void 0 : _d.response.headers }, traffic.requestExtra), traffic.responseBody)),
                        mockId: traffic.mockId,
                        orgResponse: traffic.orgResponse,
                        requestTime: traffic.requestTime,
                    });
                });
                yield chrome.tabs.sendMessage(executionInfo.platformTab.id, {
                    type: 'get-step-traffic-res',
                    payload: Object.assign(Object.assign({}, message === null || message === void 0 ? void 0 : message.payload), { traffics }),
                });
            }
        }
    }
    catch (e) {
        console.error('hanldQueryStepTraffic exception: ', e);
    }
});
const handleOpenTargetPage = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _62, _63, _64, _65, _66, _67, _68;
    if ((message === null || message === void 0 ? void 0 : message.name) === 'open-target') {
        try {
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            const action = message;
            if ((_62 = action.openTargetPayload) === null || _62 === void 0 ? void 0 : _62.targetUrl) {
                if ((_63 = action === null || action === void 0 ? void 0 : action.openTargetPayload) === null || _63 === void 0 ? void 0 : _63.mockTraffics.length) {
                    traffic_manager_1.default.init(action.openTargetPayload.mockTraffics);
                }
                // 为所有url注入一个 e2esessionID, 目前只针对 ide 场景开放
                yield InjectE2ESessionIDInUrl((_64 = action === null || action === void 0 ? void 0 : action.openTargetPayload) === null || _64 === void 0 ? void 0 : _64.e2eSessionID);
                injectMapping.delete((_66 = (_65 = executionInfo.targetTab) === null || _65 === void 0 ? void 0 : _65.id) !== null && _66 !== void 0 ? _66 : 0);
                executionInfo.targetTab = yield chrome.tabs.update((_68 = (_67 = executionInfo.targetTab) === null || _67 === void 0 ? void 0 : _67.id) !== null && _68 !== void 0 ? _68 : 0, {
                    url: action.openTargetPayload.targetUrl,
                });
            }
            else {
                throw Error('invalid url');
            }
        }
        catch (e) {
            console.error('handleOpenTargetPage exception: ', e);
        }
    }
});
const getFrameDom = (dom, tabId, parentID = 0, actionName = 'do-snapshot-in-frame') => new Promise((resolve) => __awaiter(void 0, void 0, void 0, function* () {
    if (dom === null || dom === void 0 ? void 0 : dom.length) {
        const frames = [];
        const allFrames = yield chrome.webNavigation.getAllFrames({ tabId });
        (0, utils_1.findFrame)(dom[0], frames);
        console.log('handleSnapshot - getFrameDom - findFrame', frames, allFrames);
        if (frames.length && (allFrames === null || allFrames === void 0 ? void 0 : allFrames.length)) {
            let i = 0;
            // let f: DomTreeNode | undefined = frames[0]
            while (frames[i]) {
                const f = frames[i];
                const _frame = allFrames.find((v) => {
                    var _a, _b, _c, _d, _e, _g, _j, _k;
                    console.log('find', v.url, ((_a = f === null || f === void 0 ? void 0 : f.Attributes) === null || _a === void 0 ? void 0 : _a.src) === ((_b = f === null || f === void 0 ? void 0 : f.Attributes) === null || _b === void 0 ? void 0 : _b.document_src), v.url === ((_c = f === null || f === void 0 ? void 0 : f.Attributes) === null || _c === void 0 ? void 0 : _c.src), v.url === ((_d = f === null || f === void 0 ? void 0 : f.Attributes) === null || _d === void 0 ? void 0 : _d.document_src), (_e = f === null || f === void 0 ? void 0 : f.Attributes) === null || _e === void 0 ? void 0 : _e.src, (_g = f === null || f === void 0 ? void 0 : f.Attributes) === null || _g === void 0 ? void 0 : _g.document_src);
                    return ((v.url === ((_j = f === null || f === void 0 ? void 0 : f.Attributes) === null || _j === void 0 ? void 0 : _j.src) || v.url === ((_k = f === null || f === void 0 ? void 0 : f.Attributes) === null || _k === void 0 ? void 0 : _k.document_src)) && v.parentFrameId === parentID);
                });
                if (_frame) {
                    console.log('handleSnapshot - do-snapshot-in-frame - start', _frame);
                    const resp = yield chrome.tabs.sendMessage(tabId, {
                        action: actionName,
                    }, { frameId: _frame.frameId });
                    console.log('handleSnapshot - do-snapshot-in-frame - end', resp);
                    if (resp === null || resp === void 0 ? void 0 : resp.length) {
                        yield getFrameDom(resp, tabId, _frame.frameId, actionName);
                        (0, utils_1.updateRect)(resp[0], f.Rect);
                        f.Children.push(resp[0]);
                    }
                }
                i += 1;
            }
        }
        resolve(true);
    }
    else {
        resolve(undefined);
    }
}));
const handleSnapshot = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _69, _70, _71, _72, _73, _74, _75;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mtn-rr-do-snapshot') {
            const _uid = (0, uuid_1.v4)();
            console.log('handleSnapshot - start', _uid, new Date().getTime());
            const checkResult = yield checkReplayWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (((_69 = executionInfo.targetTab) === null || _69 === void 0 ? void 0 : _69.id) && ((_70 = executionInfo.targetTab) === null || _70 === void 0 ? void 0 : _70.windowId)) {
                console.log('handleSnapshot - dom - start', _uid, new Date().getTime());
                const dom = yield chrome.tabs.sendMessage(executionInfo.targetTab.id, {
                    type: 'mtn-rr-do-snapshot',
                });
                console.log('handleSnapshot - dom - end', _uid, new Date().getTime());
                console.log('handleSnapshot - getFrameDom - start', _uid, new Date().getTime());
                yield getFrameDom(dom, executionInfo.targetTab.id);
                console.log('handleSnapshot - getFrameDom - end', _uid, new Date().getTime());
                console.log('handleSnapshot - captureVisibleTab - start', _uid, new Date().getTime());
                const img = yield chrome.tabs.captureVisibleTab(executionInfo.targetTab.windowId, { format: 'png' });
                console.log('handleSnapshot - captureVisibleTab - end', _uid, new Date().getTime());
                console.log('handleSnapshot - sendMessage - start', _uid, new Date().getTime(), dom, img);
                yield chrome.tabs.sendMessage((_72 = (_71 = executionInfo.platformTab) === null || _71 === void 0 ? void 0 : _71.id) !== null && _72 !== void 0 ? _72 : 0, {
                    type: 'mtn-rr-snapshot-record',
                    payload: {
                        dom,
                        img,
                    },
                });
                console.log('handleSnapshot - sendMessage - end', _uid, new Date().getTime(), dom, img);
            }
        }
    }
    catch (e) {
        console.log('handleSnapshot - error', e.message);
        console.error('handleSnapshot - error', e.message);
        yield chrome.tabs.sendMessage((_74 = (_73 = executionInfo.platformTab) === null || _73 === void 0 ? void 0 : _73.id) !== null && _74 !== void 0 ? _74 : 0, {
            type: 'mtn-rr-snapshot-record',
            payload: {
                dom: [],
                img: '',
                error: (_75 = e === null || e === void 0 ? void 0 : e.message) !== null && _75 !== void 0 ? _75 : 'handleSnapshot fail',
            },
        });
    }
});
const handleSnapshotInRecord = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _76, _77, _78, _79, _80, _81, _82;
    try {
        if ((message === null || message === void 0 ? void 0 : message.type) === 'mtn-rr-do-snapshot-with-record') {
            const _uid = (0, uuid_1.v4)();
            console.log('handleSnapshot - start', _uid, new Date().getTime());
            const checkResult = yield checkRecordingWindows();
            if (!checkResult.success) {
                throw Error(checkResult.errorMsg);
            }
            if (((_76 = recordingInfo.recordingStartTab) === null || _76 === void 0 ? void 0 : _76.id) && ((_77 = recordingInfo.recordingStartTab) === null || _77 === void 0 ? void 0 : _77.windowId)) {
                console.log('handleSnapshot - dom - start', _uid, new Date().getTime());
                const dom = yield chrome.tabs.sendMessage(recordingInfo.recordingStartTab.id, {
                    type: 'mtn-rr-do-snapshot-with-record',
                });
                console.log('handleSnapshot - dom - end', _uid, new Date().getTime());
                console.log('handleSnapshot - getFrameDom - start', _uid, new Date().getTime());
                yield getFrameDom(dom, recordingInfo.recordingStartTab.id, 0, 'do-snapshot-in-frame-with-record');
                console.log('handleSnapshot - getFrameDom - end', _uid, new Date().getTime());
                console.log('handleSnapshot - captureVisibleTab - start', _uid, new Date().getTime());
                const img = yield chrome.tabs.captureVisibleTab(recordingInfo.recordingStartTab.windowId, { format: 'jpeg' });
                console.log('handleSnapshot - captureVisibleTab - end', _uid, new Date().getTime());
                console.log('handleSnapshot - sendMessage - start', _uid, new Date().getTime(), dom, img);
                yield chrome.tabs.sendMessage((_79 = (_78 = recordingInfo.recordingAssertPlatformTab) === null || _78 === void 0 ? void 0 : _78.id) !== null && _79 !== void 0 ? _79 : 0, {
                    type: 'mtn-rr-snapshot-record',
                    payload: {
                        dom,
                        img,
                    },
                });
                console.log('handleSnapshot - sendMessage - end', _uid, new Date().getTime(), dom, img);
            }
        }
    }
    catch (e) {
        console.log('handleSnapshot - error', e.message);
        console.error('handleSnapshot - error', e.message);
        yield chrome.tabs.sendMessage((_81 = (_80 = recordingInfo.recordingAssertPlatformTab) === null || _80 === void 0 ? void 0 : _80.id) !== null && _81 !== void 0 ? _81 : 0, {
            type: 'mtn-rr-snapshot-record',
            payload: {
                dom: [],
                img: '',
                error: (_82 = e === null || e === void 0 ? void 0 : e.message) !== null && _82 !== void 0 ? _82 : 'handleSnapshot fail',
            },
        });
    }
});
const handleSetExtraHeaders = (message) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'set-extra-headers') {
            yield updateModifyHeaderInfo(message === null || message === void 0 ? void 0 : message.headers);
        }
    }
    catch (e) {
        throw Error(`handleSetExtraHeaders error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
});
const handleQueryWorkAreaSize = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _83, _84, _85, _86, _87, _88;
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'query-work-area-size') {
            // const tab = await chrome.tabs.get(recordingInfo.recordingStartTab?.id ?? 0)
            const win = yield chrome.windows.get((_84 = (_83 = recordingInfo.targetWindow) === null || _83 === void 0 ? void 0 : _83.id) !== null && _84 !== void 0 ? _84 : 0);
            yield chrome.tabs.sendMessage((_86 = (_85 = recordingInfo.recordingAssertPlatformTab) === null || _85 === void 0 ? void 0 : _85.id) !== null && _86 !== void 0 ? _86 : 0, {
                type: 'mnt-rr-window-size',
                payload: {
                    width: Math.floor((_87 = win.width) !== null && _87 !== void 0 ? _87 : 0),
                    height: Math.floor((_88 = win.height) !== null && _88 !== void 0 ? _88 : 0),
                },
            });
        }
    }
    catch (e) {
        throw Error(`handleQueryWorkAreaSize error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
});
const handleUpdateExecutionWindowSize = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _89, _90, _91, _92;
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'set-window-size') {
            yield chrome.windows.update((_90 = (_89 = executionInfo.targetWindow) === null || _89 === void 0 ? void 0 : _89.id) !== null && _90 !== void 0 ? _90 : 0, {
                width: ((_91 = message === null || message === void 0 ? void 0 : message.payload) === null || _91 === void 0 ? void 0 : _91.width) || Math.floor(message.width),
                height: ((_92 = message === null || message === void 0 ? void 0 : message.payload) === null || _92 === void 0 ? void 0 : _92.height) || Math.floor(message.height),
            });
            // await chrome.debugger.attach({ tabId: executionInfo.targetTab?.id }, protocolVersion)
        }
    }
    catch (e) {
        throw Error(`handleUpdateExecutionWindowSize error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
});
const handleHeartbeat = (message) => {
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'heartbeat') {
            console.log('heartbeat - ', new Date().getTime());
        }
    }
    catch (e) {
        throw Error(`handleHeartbeat error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
};
const handleSetRecordEnv = (message) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'set-record-env') {
            yield chrome.storage.local.set({ 'mnt-record-env': message === null || message === void 0 ? void 0 : message.payload });
        }
    }
    catch (e) {
        throw Error(`handleSetRecordEnv error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
});
// eslint-disable-next-line one-var
let uploadRef;
const handleTransferFileBuffer = (message) => __awaiter(void 0, void 0, void 0, function* () {
    var _93, _94, _95, _96, _97, _98, _99;
    try {
        // 在 Chrome 插件中直接上传，每次传输消息的性能损耗太大了
        if ((message === null || message === void 0 ? void 0 : message.name) === 'transfer-file-buffer') {
            const { type, name, mode, chunkSize, bufferSize, numChunks, chunk, start } = message.payload;
            if (mode === 'start') {
                console.log('transfer-file-buffer start', new Date().getTime());
                uploadRef = {
                    type,
                    name,
                    chunkSize,
                    bufferSize,
                    numChunks,
                    combinedData: new Uint8Array(bufferSize),
                };
                yield chrome.tabs.sendMessage((_94 = (_93 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _93 === void 0 ? void 0 : _93.id) !== null && _94 !== void 0 ? _94 : 0, {
                    name: 'upload-file',
                    payload: {
                        mode: 'start',
                    },
                });
            }
            else if (mode === 'sending') {
                // chunk 此时是 object 类型需要将 object 转化为 buffer
                (_95 = uploadRef === null || uploadRef === void 0 ? void 0 : uploadRef.combinedData) === null || _95 === void 0 ? void 0 : _95.set(new Uint8Array(Object.values(chunk)), start);
            }
            else if (mode === 'end') {
                const _env = yield chrome.storage.local.get(['mnt-record-env']);
                const env = _env['mnt-record-env'];
                console.log('transfer-file-buffer done', uploadRef, new Date().getTime());
                if (uploadRef) {
                    if ((uploadRef === null || uploadRef === void 0 ? void 0 : uploadRef.bufferSize) < 1024 * 1024 * 100) {
                        const { combinedData } = uploadRef;
                        const blob = new Blob([combinedData === null || combinedData === void 0 ? void 0 : combinedData.buffer], { type: uploadRef.type });
                        const newFile = new File([blob], uploadRef.name || '未知文件', {
                            type: blob.type,
                        });
                        const data = new FormData();
                        data.append('projectId', `${env.projectId}`);
                        data.append('caseId', `${env.caseId}`);
                        data.append('file', newFile);
                        const _resp = yield fetch('https://assert-mnt.bytedance.net/web-apaas-api/recorder/upload-small-file', {
                            method: 'POST',
                            headers: {
                                'x-user-token': env.tk,
                            },
                            body: data,
                        });
                        const resp = yield _resp.json();
                        // 发送消息
                        console.log('upload file', resp);
                        yield chrome.tabs.sendMessage((_97 = (_96 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _96 === void 0 ? void 0 : _96.id) !== null && _97 !== void 0 ? _97 : 0, {
                            name: 'upload-file',
                            payload: {
                                mode: 'end',
                                success: resp.code === 200 && resp.data,
                                name: uploadRef.name,
                                uri: resp.data,
                                size: uploadRef === null || uploadRef === void 0 ? void 0 : uploadRef.bufferSize,
                            },
                        });
                    }
                    else {
                        // const startResp = await (await fetch('https://assert-mnt.bytedance.net/mnt-apaas-api/recorder/upload-small-file', {
                        //   method: 'post',
                        //   headers: {
                        //     "Content-Type": "multipart/form-data",
                        //     "x-user-token": env.tk,
                        //   },
                        // })).json()
                    }
                    uploadRef = undefined;
                }
            }
        }
    }
    catch (e) {
        yield chrome.tabs.sendMessage((_99 = (_98 = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.recordingAssertPlatformTab) === null || _98 === void 0 ? void 0 : _98.id) !== null && _99 !== void 0 ? _99 : 0, {
            name: 'upload-file',
            payload: {
                mode: 'end',
                success: false,
            },
        });
        uploadRef = undefined;
        throw Error(`handleTransferFileBuffer error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
});
const handleSetCookie = (message) => {
    var _a;
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'set-cookies' && (message === null || message === void 0 ? void 0 : message.setCookiesPayload)) {
            const expirationDate = new Date();
            expirationDate.setDate(expirationDate.getDate() + 30);
            (_a = message === null || message === void 0 ? void 0 : message.setCookiesPayload) === null || _a === void 0 ? void 0 : _a.cookies.forEach((c) => __awaiter(void 0, void 0, void 0, function* () {
                var _b, _c;
                if (c.name) {
                    delCookieQueue.push({
                        name: c.name,
                        url: `${c.url}${c.path}`,
                    });
                    yield chrome.cookies.remove({
                        name: c.name,
                        url: `${c.url}${c.path}`,
                    });
                }
                console.log('delCookieQueue - add', delCookieQueue);
                try {
                    yield chrome.cookies.set({
                        domain: c.domain,
                        name: c.name,
                        value: c.value,
                        httpOnly: c.httpOnly,
                        secure: c.secure,
                        path: c.path,
                        expirationDate: Number(c.expires) || expirationDate.getTime() / 1000,
                        url: (_b = c.url) !== null && _b !== void 0 ? _b : '',
                    });
                }
                catch (e) {
                    console.error('set-cookie error:', {
                        domain: c.domain,
                        name: c.name,
                        value: c.value,
                        httpOnly: c.httpOnly,
                        secure: c.secure,
                        path: c.path,
                        expirationDate: Number(c.expires) || expirationDate.getTime() / 1000,
                        url: (_c = c.url) !== null && _c !== void 0 ? _c : '',
                    });
                }
            }));
        }
    }
    catch (e) {
        throw Error(`handleSetCookie error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
};
const handleResetCookie = (message) => {
    try {
        if ((message === null || message === void 0 ? void 0 : message.name) === 'reset-cookies') {
            resetCookie();
        }
    }
    catch (e) {
        throw Error(`handleResetCookie error ${JSON.stringify((e === null || e === void 0 ? void 0 : e.message) || '')}`);
    }
};
const handle = (request, sendResponse) => __awaiter(void 0, void 0, void 0, function* () {
    var _100, _101, _102;
    yield handleStartRecording(request);
    yield handleStopRecording(request);
    yield handleRecordingEventCapture(request);
    yield handleRecordingEventClickAsHover(request);
    yield handleRecordingEventPauseRecording(request);
    yield handleRecordingToggleUrl(request);
    yield handleRestartRecording(request);
    yield handleOpenTargetPage(request);
    yield handleTriggerEvent(request);
    yield handleStarReplay(request);
    yield handleStopReplay(request);
    yield handleSnapshot(request);
    yield handleOpenTaskDetail(request);
    yield handleSendEventSimulationCommandToSDK(request);
    yield handleSendEventReplayResultToPlatform(request);
    yield handleQueryStepTraffic(request);
    yield handleSetExtraHeaders(request);
    yield handleQueryWorkAreaSize(request);
    yield handleUpdateExecutionWindowSize(request);
    yield handleSetRecordEnv(request);
    yield handleTransferFileBuffer(request);
    yield handleSendEventReplayToggleUrl(request);
    yield handleSnapshotInRecord(request);
    handleSetCookie(request);
    handleResetCookie(request);
    // handleHeartbeat(request)
    if (request.type === 'mnt-rr-dom-mutation' && ((_100 = recordingInfo.recordingAssertPlatformTab) === null || _100 === void 0 ? void 0 : _100.id)) {
        yield chrome.tabs.sendMessage(recordingInfo.recordingAssertPlatformTab.id, request.data);
    }
    if ((request === null || request === void 0 ? void 0 : request.type) === 'mnt-rr-log' && ((_101 = recordingInfo.recordingAssertPlatformTab) === null || _101 === void 0 ? void 0 : _101.id)) {
        console.log('request.mnt-rr-log', request.data);
        // await chrome.tabs.sendMessage(recordingInfo.recordingAssertPlatformTab.id, request.data)
    }
    if (request.type === 'mnt-rr-dom-mutation' && ((_102 = executionInfo.platformTab) === null || _102 === void 0 ? void 0 : _102.id)) {
        yield chrome.tabs.sendMessage(executionInfo.platformTab.id, request.data);
    }
});
const run = () => {
    console.log('run');
    // eslint-disable-next-line @typescript-eslint/no-misused-promises
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => __awaiter(void 0, void 0, void 0, function* () {
        console.log('bg-msg', request);
        yield handle(request, sendResponse);
        return true;
    }));
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
    // handleHeartbeat()
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, _tab) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        console.log('tabs-onUpdated', tabId, changeInfo, executionInfo, recordingInfo, _tab);
        const tab = yield chrome.tabs.get(tabId);
        if (!tab.url) {
            return;
        }
        if (changeInfo.status === 'loading' && tab.status === 'loading' && injectMapping.get(tabId)) {
            console.log('页面reload 需要重新挂载SDK');
            injectMapping.delete(tabId);
        }
        // 检查页面是否完成加载
        if (changeInfo.status === 'complete') {
            const currentUri = ((_a = tab.url) === null || _a === void 0 ? void 0 : _a.indexOf('?')) ? tab.url.split('?')[0] : tab.url;
            const last = injectMapping.get(tabId);
            if (last && last === currentUri) {
                return;
            }
            else {
                injectMapping.set(tabId, currentUri);
            }
            if (tabId === ((_b = executionInfo.targetTab) === null || _b === void 0 ? void 0 : _b.id)) {
                console.log('inject replay');
                yield chrome.scripting.executeScript({
                    target: { tabId, allFrames: true },
                    files: ['replay.js'],
                });
                yield chrome.scripting.executeScript({
                    world: 'MAIN',
                    target: { tabId, allFrames: false },
                    files: ['window_hook.js'],
                });
            }
            if (tabId === ((_c = executionInfo.platformTab) === null || _c === void 0 ? void 0 : _c.id)) {
                console.log('inject replay_platform');
                yield chrome.scripting.executeScript({
                    target: { tabId, allFrames: true },
                    files: ['replay_platform.js'],
                });
            }
            if (tabId === ((_d = recordingInfo.recordingStartTab) === null || _d === void 0 ? void 0 : _d.id)) {
                console.log('inject record');
                yield chrome.scripting.executeScript({
                    target: { tabId, allFrames: true },
                    files: ['record.js'],
                });
                yield chrome.scripting.executeScript({
                    world: 'MAIN',
                    target: { tabId, allFrames: false },
                    files: ['window_hook.js'],
                });
            }
            if (tabId === ((_e = recordingInfo.recordingAssertPlatformTab) === null || _e === void 0 ? void 0 : _e.id)) {
                console.log('inject record_platform');
                yield chrome.scripting.executeScript({
                    target: { tabId, allFrames: true },
                    files: ['record_platform.js'],
                });
            }
        }
    }));
    // 处理 tab 关闭事件
    chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
        var _a, _b, _c, _d;
        console.log('tabs-onRemoved', tabId, removeInfo, executionInfo, recordingInfo);
        injectMapping.delete(tabId);
        if (tabId === ((_a = executionInfo.targetTab) === null || _a === void 0 ? void 0 : _a.id)) {
            executionInfo.targetTab = undefined;
            executionInfo.debuggerAttached = false;
            resetCookie();
        }
        if (tabId === ((_b = executionInfo.platformTab) === null || _b === void 0 ? void 0 : _b.id)) {
            executionInfo.platformTab = undefined;
        }
        if (tabId === ((_c = recordingInfo.recordingAssertPlatformTab) === null || _c === void 0 ? void 0 : _c.id)) {
            recordingInfo.recordingAssertPlatformTab = undefined;
        }
        if (tabId === ((_d = recordingInfo.recordingStartTab) === null || _d === void 0 ? void 0 : _d.id)) {
            recordingInfo.recordingStartTab = undefined;
        }
    });
    chrome.cookies.onChanged.addListener((changeInfo) => {
        // 当 Cookie 发生变化时的处理代码
        console.log('cookies change', changeInfo);
    });
    chrome.tabs.onCreated.addListener((tab) => {
        console.log('tabs-created:', tab);
    });
    // // 监听窗口移除事件
    chrome.windows.onRemoved.addListener((windowId) => __awaiter(void 0, void 0, void 0, function* () {
        var _g, _j, _k, _l;
        if (((_g = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.targetWindow) === null || _g === void 0 ? void 0 : _g.id) === windowId) {
            recordingInfo.targetWindow = undefined;
            resetCookie();
        }
        if (((_j = recordingInfo === null || recordingInfo === void 0 ? void 0 : recordingInfo.platformWindow) === null || _j === void 0 ? void 0 : _j.id) === windowId) {
            recordingInfo.platformWindow = undefined;
            resetCookie();
        }
        if (((_k = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetWindow) === null || _k === void 0 ? void 0 : _k.id) === windowId) {
            executionInfo.targetWindow = undefined;
            resetCookie();
        }
        if (((_l = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.platformWindow) === null || _l === void 0 ? void 0 : _l.id) === windowId) {
            executionInfo.platformWindow = undefined;
            resetCookie();
        }
        yield updateModifyHeaderInfo();
        console.log('Window removed:', windowId, recordingInfo, executionInfo);
    }));
    chrome.windows.onBoundsChanged.addListener((window) => __awaiter(void 0, void 0, void 0, function* () {
        var _m;
        console.log('Window onBoundsChanged:', window);
        if (window.id === ((_m = executionInfo === null || executionInfo === void 0 ? void 0 : executionInfo.targetWindow) === null || _m === void 0 ? void 0 : _m.id)) {
            if ((window === null || window === void 0 ? void 0 : window.left) !== undefined && (window === null || window === void 0 ? void 0 : window.left) > 0 && (window === null || window === void 0 ? void 0 : window.id)) {
                yield chrome.windows.update(window.id, { left: 0, top: 0 });
            }
            console.log('Window onBoundsChanged: is Target Window', window);
        }
    }));
    chrome.windows.onCreated.addListener((window) => {
        console.log('Window onCreated:', window);
    });
    chrome.debugger.onEvent.addListener((target, message, params) => __awaiter(void 0, void 0, void 0, function* () {
        if (message === 'Fetch.requestPaused') {
            console.log('header', _h);
            const { requestId, request } = params;
            console.log('Fetch.continueRequest', _h, requestId, request, headersArray(request.headers));
            if (_h) {
                yield chrome.debugger.sendCommand(target, 'Fetch.continueRequest', {
                    requestId,
                    headers: [...headersArray(request.headers), ...headersArray(_h)],
                });
            }
            else {
                yield chrome.debugger.sendCommand(target, 'Fetch.continueRequest', {
                    requestId,
                });
            }
        }
    }));
    chrome.webNavigation.onCompleted.addListener((e) => __awaiter(void 0, void 0, void 0, function* () {
        var _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
        if (e.tabId === ((_o = recordingInfo.recordingStartTab) === null || _o === void 0 ? void 0 : _o.id) && e.frameId !== 0) {
            yield chrome.scripting.executeScript({
                target: { tabId: (_p = recordingInfo.recordingStartTab) === null || _p === void 0 ? void 0 : _p.id, frameIds: [e.frameId] },
                files: ['record.js'],
            });
            yield chrome.scripting.executeScript({
                target: { tabId: (_q = recordingInfo.recordingStartTab) === null || _q === void 0 ? void 0 : _q.id, frameIds: [e.frameId] },
                world: 'MAIN',
                files: ['window_hook.js'],
            });
        }
        if (e.tabId === ((_r = recordingInfo.recordingStartTab) === null || _r === void 0 ? void 0 : _r.id) && e.frameId !== 0) {
            const url = new URL(e.url);
            yield chrome.scripting.executeScript({
                target: { tabId: (_s = recordingInfo.recordingStartTab) === null || _s === void 0 ? void 0 : _s.id, frameIds: [e.frameId] },
                func: (args) => {
                    ;
                    window.__mnt = args;
                },
                args: [{ fid: e.frameId, uri: `${url.origin}${url.pathname}` }],
            });
        }
        if (e.tabId === ((_t = executionInfo.targetTab) === null || _t === void 0 ? void 0 : _t.id) && e.frameId !== 0) {
            yield chrome.scripting.executeScript({
                target: { tabId: (_u = executionInfo.targetTab) === null || _u === void 0 ? void 0 : _u.id, frameIds: [e.frameId] },
                files: ['replay.js'],
            });
            yield chrome.scripting.executeScript({
                target: { tabId: (_v = executionInfo.targetTab) === null || _v === void 0 ? void 0 : _v.id, frameIds: [e.frameId] },
                world: 'MAIN',
                files: ['window_hook.js'],
            });
        }
        if (e.tabId === ((_w = executionInfo.targetTab) === null || _w === void 0 ? void 0 : _w.id) && e.frameId !== 0) {
            const url = new URL(e.url);
            yield chrome.scripting.executeScript({
                target: { tabId: (_x = executionInfo.targetTab) === null || _x === void 0 ? void 0 : _x.id, frameIds: [e.frameId] },
                func: (args) => {
                    ;
                    window.__mnt = args;
                },
                args: [{ fid: e.frameId, uri: `${url.origin}${url.pathname}` }],
            });
        }
    }));
    chrome.webNavigation.onCompleted.addListener((e) => __awaiter(void 0, void 0, void 0, function* () {
        var _y;
        console.log('webNavigation', e);
        if (e.tabId === ((_y = executionInfo.targetTab) === null || _y === void 0 ? void 0 : _y.id) && e.frameId !== 0) {
            // 向父级发送请求，计算 frame 的 rect
            yield chrome.tabs.sendMessage(e.tabId, {
                type: 'calculate-frame-rect',
                payload: {
                    frameId: e.frameId,
                    url: e.url,
                },
            }, { frameId: e.parentFrameId });
        }
    }));
    chrome.webNavigation.onBeforeNavigate.addListener((e) => {
        console.log('onBeforeNavigate', e);
    });
};
// chrome.runtime.onStartup.addListener(() => {
//   console.log('onStartup')
//   run()
// })
// chrome.runtime.onInstalled.addListener(() => {
//   console.log('onInstalled')
//   run()
// })
run();


/***/ }),

/***/ 3151:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
/* eslint-disable max-lines-per-function */
/* eslint-disable max-depth */
const interface_1 = __webpack_require__(1615);
const USKeyboardLayout_1 = __webpack_require__(7289);
const assert = (value, message) => {
    if (!value) {
        throw new Error(message);
    }
};
const move = (x, y, tab, button = 'none') => __awaiter(void 0, void 0, void 0, function* () {
    console.log('move');
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchMouseEvent', {
        type: 'mouseMoved',
        button,
        x,
        y,
        modifiers: 0,
    });
});
const down = (x, y, tab, button = 'left', modifiers = interface_1.MouseModifiers.Default, clickCount = 1) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('down');
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        button,
        x,
        y,
        modifiers,
        clickCount,
    });
});
const up = (x, y, tab, button = 'left', modifiers = interface_1.MouseModifiers.Default, clickCount = 1) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('up');
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        button,
        x,
        y,
        modifiers,
        clickCount,
    });
});
let _modifiers = 0;
const pressedKeys = new Set();
const modifierBit = (key) => {
    if (key === 'Alt') {
        return 1;
    }
    if (key === 'Control') {
        return 2;
    }
    if (key === 'Meta') {
        return 4;
    }
    if (key === 'Shift') {
        return 8;
    }
    return 0;
};
const keyDescriptionForString = (keyString) => {
    const shift = _modifiers & 8;
    const description = {
        key: '',
        keyCode: 0,
        code: '',
        text: '',
        location: 0,
    };
    const definition = USKeyboardLayout_1._keyDefinitions[keyString];
    assert(definition, `Unknown key: "${keyString}"`);
    if (definition.key) {
        description.key = definition.key;
    }
    if (shift && definition.shiftKey) {
        description.key = definition.shiftKey;
    }
    if (definition.keyCode) {
        description.keyCode = definition.keyCode;
    }
    if (shift && definition.shiftKeyCode) {
        description.keyCode = definition.shiftKeyCode;
    }
    if (definition.code) {
        description.code = definition.code;
    }
    if (definition.location) {
        description.location = definition.location;
    }
    if (description.key.length === 1) {
        description.text = description.key;
    }
    if (definition.text) {
        description.text = definition.text;
    }
    if (shift && definition.shiftText) {
        description.text = definition.shiftText;
    }
    // if any modifiers besides shift are pressed, no text should be sent
    if (_modifiers & ~8) {
        description.text = '';
    }
    return description;
};
const keyDown = (key, tab) => __awaiter(void 0, void 0, void 0, function* () {
    const description = keyDescriptionForString(key);
    const autoRepeat = pressedKeys.has(description.code);
    pressedKeys.add(description.code);
    _modifiers |= modifierBit(description.key);
    const { text } = description;
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchKeyEvent', {
        type: text ? 'keyDown' : 'rawKeyDown',
        modifiers: _modifiers,
        windowsVirtualKeyCode: description.keyCode,
        code: description.code,
        key: description.key,
        text,
        unmodifiedText: text,
        autoRepeat,
        location: description.location,
        isKeypad: description.location === 3,
        // commands: options.commands,
    });
});
const keyUp = (key, tab) => __awaiter(void 0, void 0, void 0, function* () {
    const description = keyDescriptionForString(key);
    _modifiers &= ~modifierBit(description.key);
    pressedKeys.delete(description.code);
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchKeyEvent', {
        type: 'keyUp',
        modifiers: _modifiers,
        key: description.key,
        windowsVirtualKeyCode: description.keyCode,
        code: description.code,
        location: description.location,
    });
});
const press = (key, tab) => __awaiter(void 0, void 0, void 0, function* () {
    yield keyDown(key, tab);
    yield keyUp(key, tab);
});
const sendCharacter = (char, tab) => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.insertText', { text: char });
});
const charIsKey = (char) => Boolean(USKeyboardLayout_1._keyDefinitions[char]);
const wheel = (x, y, deltaX, deltaY, tab) => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.debugger.sendCommand({
        tabId: tab.id,
    }, 'Input.dispatchMouseEvent', {
        type: 'mouseWheel',
        x,
        y,
        deltaX,
        deltaY,
        modifiers: 0,
        pointerType: 'mouse',
    });
});
const replay = (payload, tab) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j;
    const { stepType } = payload;
    console.log('click', payload);
    if (stepType === 'dblclick') {
        const { dblclickValue } = payload.value;
        if (!dblclickValue) {
            return;
        }
        const { x, y } = dblclickValue;
        yield move(x, y, tab);
        yield new Promise((r) => setTimeout(r, 100));
        yield down(x, y, tab, 'left');
        yield up(x, y, tab, 'left');
        yield down(x, y, tab, 'left', interface_1.MouseModifiers.Default, 2);
        yield up(x, y, tab, 'left', interface_1.MouseModifiers.Default, 2);
        return;
    }
    if (stepType === 'text-selection') {
        const { textSelectionValue } = payload.value;
        if (!textSelectionValue) {
            return;
        }
        const { mouseDownParams, mouseMoveParams, mouseUpParams } = textSelectionValue;
        yield move(mouseDownParams.x, mouseDownParams.y, tab);
        yield new Promise((r) => setTimeout(r, 100));
        yield down(mouseDownParams.x, mouseDownParams.y, tab);
        for (let i = 0, len = mouseMoveParams.length; i < len; i++) {
            const moveParams = mouseMoveParams[i];
            yield move(moveParams.x, moveParams.y, tab, 'left');
        }
        yield up(mouseUpParams.x, mouseUpParams.y, tab);
        return;
    }
    if (stepType === 'keyup') {
        const inputs = (_b = (_a = payload.value) === null || _a === void 0 ? void 0 : _a.inputs) !== null && _b !== void 0 ? _b : [];
        if (inputs.length) {
            for (let i = 0, len = inputs.length; i < len; i++) {
                yield press(inputs[i].key, tab);
            }
        }
        else {
            if (((_c = payload.value) === null || _c === void 0 ? void 0 : _c.keyCode) === 'Enter') {
                yield press('Enter', tab);
            }
            else if (((_d = payload.value) === null || _d === void 0 ? void 0 : _d.keyCode) === 'Tab') {
                yield press('Tab', tab);
            }
            else if (((_e = payload.value) === null || _e === void 0 ? void 0 : _e.keyCode) === 'Escape') {
                yield press('Escape', tab);
            }
            else if (payload.value.keyCode === 'ArrowLeft') {
                yield press('ArrowLeft', tab);
            }
            else if (payload.value.keyCode === 'ArrowRight') {
                yield press('ArrowRight', tab);
            }
            else if (payload.value.keyCode === 'ArrowUp') {
                yield press('ArrowUp', tab);
            }
            else if (payload.value.keyCode === 'ArrowDown') {
                yield press('ArrowDown', tab);
            }
        }
        return;
    }
    if (stepType === 'context-menu') {
        const { pointValue } = payload.value;
        if (!pointValue) {
            return;
        }
        const { x, y } = pointValue;
        yield move(x, y, tab);
        yield new Promise((r) => setTimeout(r, 100));
        yield down(x, y, tab, 'right');
        yield up(x, y, tab, 'right');
        return;
    }
    if (stepType === 'shortcut-key') {
        if ((_f = payload.value.keyPaths) === null || _f === void 0 ? void 0 : _f.length) {
            const clone = JSON.parse(JSON.stringify(payload.value.keyPaths));
            const trigger = clone.shift();
            if (trigger && charIsKey(trigger.key)) {
                // 按下 meta、control、shift
                yield keyDown(trigger.key, tab);
                const run = [];
                clone.forEach((item) => {
                    if (charIsKey(item.key)) {
                        run.push(press(item.key, tab));
                    }
                });
                let i = 0;
                while (run[i] !== undefined) {
                    yield run[i];
                    i += 1;
                }
                // 释放 meta、control、shift
                yield keyUp(trigger.key, tab);
            }
        }
    }
    if (stepType === 'click') {
        const { pointValue, modifiers = 0 } = payload.value;
        if (!pointValue) {
            return;
        }
        const { x, y } = pointValue;
        yield move(x, y, tab);
        yield new Promise((r) => setTimeout(r, 100));
        yield down(x, y, tab, 'left', modifiers);
        yield up(x, y, tab, 'left', modifiers);
        return;
    }
    if (stepType === 'popup' || stepType === 'hover') {
        const { pointValue } = payload.value;
        if (!pointValue) {
            return;
        }
        const { x, y } = pointValue;
        yield move(x, y, tab);
    }
    // 在 Chrome 中 全选动作被浏览器拦截了。command 不会处理所以暂时通过 document.execCommand("selectAll", false); 来实现全选
    if (stepType === 'input' && (payload === null || payload === void 0 ? void 0 : payload.value.text)) {
        const platform = yield chrome.runtime.getPlatformInfo();
        console.log('platform', platform);
        if (platform.os === 'mac') {
            // await keyDown('Meta', tab)
            // await press('KeyA', tab)
            // await keyUp('Meta', tab)
            yield press('Backspace', tab);
        }
        if (platform.os === 'win') {
            // await keyDown('Control', tab)
            // await press('KeyA', tab)
            // await keyUp('Control', tab)
            yield press('Backspace', tab);
        }
        for (const char of payload === null || payload === void 0 ? void 0 : payload.value.text) {
            if (charIsKey(char)) {
                yield press(char, tab);
            }
            else {
                yield sendCharacter(char, tab);
            }
        }
    }
    if (stepType === 'wheel' && ((_h = (_g = payload === null || payload === void 0 ? void 0 : payload.value) === null || _g === void 0 ? void 0 : _g.wheelValue) === null || _h === void 0 ? void 0 : _h.deltas.length)) {
        const { deltas, x, y } = (_j = payload === null || payload === void 0 ? void 0 : payload.value) === null || _j === void 0 ? void 0 : _j.wheelValue;
        yield move(x, y, tab);
        let index = 0;
        while (index < deltas.length) {
            const delta = deltas[index];
            yield wheel(x, y, delta.deltaX, delta.deltaY, tab);
            index += 1;
        }
    }
});
exports["default"] = replay;


/***/ }),

/***/ 6734:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MockType = void 0;
var MockType;
(function (MockType) {
    MockType[MockType["Ignore"] = 0] = "Ignore";
    MockType[MockType["Mock"] = 1] = "Mock";
})(MockType = exports.MockType || (exports.MockType = {}));
class TrafficManager {
    constructor() {
        this._firstTrafficArranged = false;
        this._trafficMap = new Map();
        this._mockTraffics = [];
        this._apiParamsMap = new Map();
    }
    extractUrlParam(rawUrl) {
        const urlSplits = rawUrl.split('?');
        const url = urlSplits[0];
        if (urlSplits.length === 1) {
            return {
                url,
            };
        }
        const params = decodeURIComponent(urlSplits[1])
            .split('&')
            .reduce((pre, next) => {
            const vals = next.split('=');
            if (vals.length === 2) {
                pre[vals[0]] = vals[1];
            }
            return pre;
        }, {});
        return Object.assign({ url }, params);
    }
    listen(targetTabId, log = false) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this._listenTraffic(targetTabId, log);
            // await this._mockTraffic(targetTabId)
        });
    }
    init(initialMockTraffics) {
        // 参数区分的example
        // this._apiParamsMap.set(
        //   'https://kunlunpmuat-dev2857.aedev.feishuapp.bytedance.net/ae/api/v1/biz-api/namespaces/package_2_2__c/appData/authorizedActionsV2',
        //   ['actions', 'actionsWithMultiRecord'],
        // )
        this._trafficMap.clear();
        this._mockTraffics = initialMockTraffics !== null && initialMockTraffics !== void 0 ? initialMockTraffics : [];
        this._firstTrafficArranged = false;
    }
    addParamKey(url, key) {
        var _a;
        const params = (_a = this._apiParamsMap.get(url)) !== null && _a !== void 0 ? _a : [];
        params.push(key);
        this._apiParamsMap.set(url, params);
    }
    match(r1, r2) {
        var _a, _b;
        const r1Url = r1.url;
        const r2Url = r2.url;
        const r1Params = this.extractUrlParam(r1Url);
        const r2Params = this.extractUrlParam(r2Url);
        if (r1Params.url !== r2Params.url) {
            return false;
        }
        const r1Method = r1.method;
        const r2Method = r2.method;
        if (r1Method !== r2Method) {
            return false;
        }
        const r1PostData = JSON.parse((_a = r1.postData) !== null && _a !== void 0 ? _a : '{}');
        const r2PostData = JSON.parse((_b = r2.postData) !== null && _b !== void 0 ? _b : '{}');
        const paramKeys = this._apiParamsMap.get(r1Params.url);
        if (!paramKeys || paramKeys.length === 0) {
            // 没有参数区分
            return true;
        }
        for (const paramKey of paramKeys) {
            if (r1Method === 'GET' && r1Params[paramKey] !== r2Params[paramKey]) {
                return false;
            }
            if (r1Method === 'POST' && JSON.stringify(r1PostData[paramKey]) !== JSON.stringify(r2PostData[paramKey])) {
                return false;
            }
        }
        return true;
    }
    findMockTraffic(currentRequest) {
        const filteredTraffics = this._mockTraffics.filter((t) => {
            const r2 = JSON.parse(t.request);
            return this.match(currentRequest, r2);
        });
        if (!filteredTraffics.length) {
            return null;
        }
        if (filteredTraffics.length > 1) {
            console.log('找到多个流量:', filteredTraffics);
        }
        return filteredTraffics[0];
    }
    findTrafficBetween(beginTime, endTime) {
        const res = [];
        this._trafficMap.forEach((v) => {
            if (!v.requestTime || !v.responseBody) {
                return;
            }
            if (!this._firstTrafficArranged) {
                // 第一步step的流量没有分配
                if (v.requestTime <= endTime) {
                    res.push(v);
                }
            }
            else {
                if (v.requestTime >= beginTime && v.requestTime <= endTime) {
                    res.push(v);
                }
            }
        });
        if (!this._firstTrafficArranged) {
            this._firstTrafficArranged = true;
        }
        return res;
    }
    fillOneStepTraffics(mockTraffics) {
        this._mockTraffics = mockTraffics !== null && mockTraffics !== void 0 ? mockTraffics : [];
    }
    _listenTraffic(targetTabId, log = false) {
        return __awaiter(this, void 0, void 0, function* () {
            chrome.debugger.onEvent.addListener((debuggeeId, message, params) => __awaiter(this, void 0, void 0, function* () {
                if (debuggeeId.tabId === targetTabId && message === 'Network.requestWillBeSent') {
                    // 处理发起的网络请求
                    const requestWillBeSentParams = params;
                    // 暂时忽略 Ajax 和 XHR 中的 js 和 css 请求，降低流量采集密度
                    if (requestWillBeSentParams.request.url.includes('.js') ||
                        requestWillBeSentParams.request.url.includes('.css')) {
                        log && console.log('忽略流量', requestWillBeSentParams.request.url, requestWillBeSentParams);
                        return;
                    }
                    // 暂时屏蔽一下 slardar 相关的日志流量，降低流量采集密度
                    if (requestWillBeSentParams.request.url.includes('mon.zijieapi.com')) {
                        log && console.log('忽略流量', requestWillBeSentParams.request.url, requestWillBeSentParams);
                        return;
                    }
                    if (requestWillBeSentParams.type === 'XHR' || requestWillBeSentParams.type === 'Fetch') {
                        log && console.log('发起的请求', params);
                        this._trafficMap.set(requestWillBeSentParams.requestId, {
                            request: requestWillBeSentParams,
                            requestTime: new Date().getTime(),
                        });
                    }
                }
                /**
                 * 可以获取到完整的 header
                 */
                if (debuggeeId.tabId === targetTabId && message === 'Network.requestWillBeSentExtraInfo') {
                    const requestWillBeSentExtraInfo = params;
                    const record = this._trafficMap.get(requestWillBeSentExtraInfo.requestId);
                    if (record) {
                        log && console.log('发起的请求-额外信息', params);
                        this._trafficMap.set(requestWillBeSentExtraInfo.requestId, Object.assign(Object.assign({}, record), { requestExtra: {
                                headers: requestWillBeSentExtraInfo.headers,
                            } }));
                    }
                }
                if (debuggeeId.tabId === targetTabId && message === 'Network.responseReceivedExtraInfo') {
                    const responseReceivedExtraInfo = params;
                    const record = this._trafficMap.get(responseReceivedExtraInfo.requestId);
                    if (record) {
                        log && console.log('收到的响应-额外信息', params);
                        this._trafficMap.set(responseReceivedExtraInfo.requestId, Object.assign(Object.assign({}, record), { responseExtra: responseReceivedExtraInfo }));
                    }
                }
                if (debuggeeId.tabId === targetTabId && message === 'Network.responseReceived') {
                    // 处理收到的网络响应
                    log && console.log('收到的响应', params);
                    const responseReceivedParams = params;
                    if (responseReceivedParams.requestId &&
                        (responseReceivedParams.type === 'XHR' || responseReceivedParams.type === 'Fetch')) {
                        const record = this._trafficMap.get(responseReceivedParams.requestId);
                        if (record) {
                            this._trafficMap.set(responseReceivedParams.requestId, Object.assign(Object.assign({}, record), { response: responseReceivedParams }));
                        }
                    }
                }
                if (debuggeeId.tabId === targetTabId && message === 'Network.loadingFinished') {
                    const loadingFinishedParams = params;
                    const record = this._trafficMap.get(loadingFinishedParams.requestId);
                    const finishedTime = new Date().getTime();
                    if (record) {
                        const resp = (yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Network.getResponseBody', {
                            requestId: loadingFinishedParams.requestId,
                        }));
                        if (resp) {
                            this._trafficMap.set(loadingFinishedParams.requestId, Object.assign(Object.assign({}, record), { responseBody: resp, responseTime: finishedTime }));
                        }
                    }
                }
            }));
            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Network.enable');
        });
    }
    _mockTraffic(targetTabId) {
        return __awaiter(this, void 0, void 0, function* () {
            chrome.debugger.onEvent.addListener((debuggeeId, message, params) => {
                var _a;
                // *******************************intercept****************************
                if (message === 'Fetch.requestPaused' && debuggeeId.tabId === targetTabId) {
                    const fetchRequestPausedParams = params;
                    const tempTraffic = this._trafficMap.get((_a = fetchRequestPausedParams.networkId) !== null && _a !== void 0 ? _a : '');
                    chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.getResponseBody', { requestId: fetchRequestPausedParams.requestId }, (result) => __awaiter(this, void 0, void 0, function* () {
                        var _b;
                        if (!((_b = tempTraffic === null || tempTraffic === void 0 ? void 0 : tempTraffic.request) === null || _b === void 0 ? void 0 : _b.request)) {
                            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.fulfillRequest', {
                                requestId: fetchRequestPausedParams.requestId,
                                responseCode: fetchRequestPausedParams.responseStatusCode,
                                responseHeaders: fetchRequestPausedParams.responseHeaders,
                                body: result.body,
                            });
                            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.continueRequest', {
                                requestId: fetchRequestPausedParams.requestId,
                            });
                            return;
                        }
                        let { body } = result;
                        const mockTraffic = this.findMockTraffic(tempTraffic.request.request);
                        try {
                            if (mockTraffic) {
                                tempTraffic.mockId = mockTraffic.id;
                                tempTraffic.orgResponse = JSON.stringify(result);
                                const mockResponse = JSON.parse(mockTraffic.response);
                                body = mockResponse.body;
                                body = btoa(unescape(encodeURIComponent(body)));
                            }
                            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.fulfillRequest', {
                                requestId: fetchRequestPausedParams.requestId,
                                responseCode: fetchRequestPausedParams.responseStatusCode,
                                responseHeaders: fetchRequestPausedParams.responseHeaders,
                                body,
                            });
                            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.continueRequest', {
                                requestId: fetchRequestPausedParams.requestId,
                            });
                        }
                        catch (error) {
                            console.error('mock.error', error);
                        }
                    }));
                }
            });
            yield chrome.debugger.sendCommand({ tabId: targetTabId }, 'Fetch.enable', {
                patterns: [{ urlPattern: '*', resourceType: 'XHR', requestStage: 'Response' }],
            });
        });
    }
}
const trafficManager = new TrafficManager();
exports["default"] = trafficManager;


/***/ }),

/***/ 1080:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.generateElementFindRules = exports.findNodeByXpath = void 0;
const default_primaryKeys = [
    'data-e2e-id',
    'data-nclc-runtime-form-item-id',
    'type',
    'name',
    'data-automation-e2e',
    'data-testid',
    // 'data-automation-activity-node-id',
    'data-automation-activity-node-type',
    'data-form-item',
    'data-row-btn',
    'data-autotest-e2e',
    'data-autotest-e2e-type',
];
const ud_uniqu_cls = ['ud__layout', 'ud__table', 'ud__tabs', 'ud__pagination', 'ud__layout__content'];
const primaryKeys = ['data-origin-path', ...default_primaryKeys];
const secondaryKeys = ['data-automation-e2e'];
const primaryClsKeys = ['data-autotest-e2e'];
// const hasOnlyOne = (elementList) => elementList?.length === 1
// const hasOnlyOneWithSelector = (sel) => hasOnlyOne(document.querySelectorAll(sel || '*'))
const findNodeByXpath = (xpath) => {
    const result = document.evaluate(xpath, document, null, XPathResult.ANY_TYPE, null);
    const eles = [];
    let _result = result.iterateNext();
    while (_result) {
        if (_result) {
            eles.push(_result);
        }
        _result = result.iterateNext();
    }
    return eles;
};
exports.findNodeByXpath = findNodeByXpath;
const hasOnlyOneWithXpath = (xpath, ignore = false) => {
    var _a;
    if (ignore) {
        return false;
    }
    return ((_a = (0, exports.findNodeByXpath)(xpath)) === null || _a === void 0 ? void 0 : _a.length) === 1;
};
const getTextContent = (element) => {
    var _a, _b;
    let text = '';
    if ((element === null || element === void 0 ? void 0 : element.children.length) > 0) {
        let textNodeCount = 0;
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let i = 0; i < element.children.length; i++) {
            const child = element.children[i];
            if (child && child.nodeType === Node.TEXT_NODE) {
                textNodeCount += 1;
            }
        }
        // 当前节点内包含文字
        if (textNodeCount > 0 && element.tagName.toLowerCase() !== 'body' && element.tagName.toLowerCase() !== 'html') {
            text = (_a = element.textContent) !== null && _a !== void 0 ? _a : '';
        }
    }
    else {
        text = (_b = element.textContent) !== null && _b !== void 0 ? _b : '';
    }
    return text;
};
const calculate = (element, path = [], pk = [], states = {
    last: 0,
    current: 0,
    finish: false,
}, ignoreText = false) => {
    var _a, _b;
    if (states.finish) {
        return path;
    }
    const tagName = element.tagName.toLowerCase();
    if (element instanceof SVGAElement || ['svg', 'path', 'g', 'text'].includes(tagName)) {
        return;
    }
    states.current += 1;
    if (tagName === 'body') {
        if (path.length) {
            path.unshift(states.current - 1 === states.last ? '/' : '//');
        }
        path.unshift('//body');
        states.finish = true;
        return path;
    }
    let _xpath = tagName;
    // 通过 attribute 寻找唯一性的特征
    const relativePath = element.getAttribute('data-e2e-relative-path');
    if (relativePath) {
        if (path.length) {
            path.unshift(states.current - 1 === states.last ? '/' : '//');
        }
        path.unshift(relativePath);
        states.finish = true;
        return path;
    }
    // 通过元素class属性及索引确定目标元素的唯一性
    for (const c of primaryClsKeys) {
        if ((_a = element.className) === null || _a === void 0 ? void 0 : _a.includes(`${c}`)) {
            const classList = Array.from(element.classList);
            const className = classList === null || classList === void 0 ? void 0 : classList.find((cls) => cls.includes(c));
            const classPath = `[contains(@class,"${className}")]`;
            const nodeCol = (0, exports.findNodeByXpath)(`//${_xpath}${classPath}`);
            if (nodeCol.length) {
                const index = nodeCol.findIndex((ele) => ele === element);
                if (index === -1) {
                    continue;
                }
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`(//${_xpath}${classPath})[${index + 1}]`);
                states.finish = true;
                return path;
            }
        }
    }
    for (const c of ud_uniqu_cls) {
        if ((_b = element.classList) === null || _b === void 0 ? void 0 : _b.contains(`${c}`)) {
            const classPath = `[contains(@class,"${c} ")]`;
            const isOnly = hasOnlyOneWithXpath(`//${_xpath}${classPath}`);
            if (isOnly) {
                _xpath += classPath;
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    for (const key of pk) {
        const attrVal = element.getAttribute(key);
        if (attrVal) {
            const attributePath = `[@${key}="${attrVal}"]`;
            // 找到具有唯一性的特征
            const isOnly = hasOnlyOneWithXpath(`//${_xpath}${attributePath}`);
            // 如果包含 hover 需要过滤一下
            // if (key === 'class' && attrVal.includes('hover')) {
            //   continue
            // }
            if (isOnly) {
                _xpath += attributePath;
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    // 通过元素属性及索引确定目标元素的唯一性
    for (const secondaryKey of secondaryKeys) {
        const attrVal = element.getAttribute(secondaryKey);
        if (attrVal) {
            const attributePath = `[@${secondaryKey}="${attrVal}"]`;
            const nodeCol = (0, exports.findNodeByXpath)(`//${_xpath}${attributePath}`);
            if (nodeCol.length) {
                const index = nodeCol.findIndex((ele) => ele === element);
                if (index === -1) {
                    continue;
                }
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`(//${_xpath}${attributePath})[${index + 1}]`);
                states.finish = true;
                return path;
            }
        }
    }
    // 通过元素的文本信息查看是否具有唯一性
    if (!ignoreText) {
        const text = getTextContent(element);
        if (text.length) {
            const textPath = `[text()='${text}']`;
            const textPathWithTrim = `[text()='${text.trim()}']`;
            const textPathWithTrimStart = `[text()='${text.trimStart()}']`;
            const textPathWithTrimEnd = `[text()='${text.trimEnd()}']`;
            const textList = Array.from(new Set([textPath, textPathWithTrim, textPathWithTrimStart, textPathWithTrimEnd]));
            let isOnly = false;
            textList.forEach((t) => {
                if (hasOnlyOneWithXpath(`//${_xpath}${t}`)) {
                    isOnly = true;
                    _xpath += t;
                    return;
                }
            });
            // 找到具有唯一性的特征
            if (isOnly) {
                if (path.length) {
                    path.unshift(states.current - 1 === states.last ? '/' : '//');
                }
                path.unshift(`//${_xpath}`);
                states.finish = true;
                return path;
            }
        }
    }
    else {
        // 检查 className 的唯一性
        const classNames = element.classList;
        if ((classNames === null || classNames === void 0 ? void 0 : classNames.length) > 0) {
            const _cls = [];
            let _c = '';
            classNames.forEach((cls, i) => {
                if (i + 1 === classNames.length) {
                    _c += `${cls}`;
                }
                else {
                    _c += `${cls} `;
                }
                _cls.push(_c);
            });
            for (const c of _cls) {
                const classPath = `[contains(@class,"${c}")]`;
                const isOnly = hasOnlyOneWithXpath(`//${_xpath}${classPath}`);
                if (isOnly) {
                    _xpath += classPath;
                    if (path.length) {
                        path.unshift(states.current - 1 === states.last ? '/' : '//');
                    }
                    path.unshift(`//${_xpath}`);
                    states.finish = true;
                    return path;
                }
            }
        }
    }
    if (_xpath === tagName) {
        let previousSibling = element;
        let nextSibling = element;
        let nth = 1;
        let nextSiblingCount = 0;
        // eslint-disable-next-line no-cond-assign
        while ((previousSibling = previousSibling.previousElementSibling)) {
            if (previousSibling.nodeName.toLowerCase() === element.nodeName.toLowerCase()) {
                nth++;
            }
        }
        while ((nextSibling = nextSibling.nextElementSibling)) {
            if (nextSibling.nodeName.toLowerCase() === element.nodeName.toLowerCase()) {
                nextSiblingCount++;
            }
        }
        if (nth > 1 || nextSiblingCount > 0) {
            if (nextSiblingCount === 0 && element.nodeName.toLowerCase() === 'td') {
                _xpath += '[last()]';
            }
            else {
                _xpath += `[${nth}]`;
            }
        }
    }
    if (path.length) {
        path.unshift(states.current - 1 === states.last ? '/' : '//');
    }
    path.unshift(_xpath);
    states.last = states.current;
    // if (!isStrictMode && path.length && hasOnlyOneWithXpath(`//${path.join('')}`, isFullPathMode)) {
    //   path.unshift('//')
    //   // console.log('xpath ele', element)
    //   states.finish = true
    //   return path
    // }
};
const generateElementFindRules = (element, pk = primaryKeys) => {
    const result = [];
    const level_1_path = [];
    const level_1_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_2_path = [];
    const level_2_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_3_path = [];
    const level_3_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_4_path = [];
    const level_4_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    const level_5_path = [];
    const level_5_states = {
        last: 0,
        current: 0,
        finish: false,
        path: [],
    };
    // const results: string[][] = [level_1_path, level_2_path, level_3_path, level_4_path, level_5_path]
    // 对 dom 做一次深度遍历。
    // TO DO: 需要在此基础上减少 evaluate 的检查次数，优化在大节点场景中时间复杂度仍旧过高的问题
    while (element.nodeType === Node.ELEMENT_NODE) {
        // console.log('generateElementFindRules', level_1_path, level_1_states, level_2_path, level_2_states)
        if (!level_1_states.finish) {
            calculate(element, level_1_path, default_primaryKeys, level_1_states, true);
        }
        if (!level_2_states.finish) {
            calculate(element, level_2_path, primaryKeys, level_2_states);
        }
        if (!level_3_states.finish) {
            calculate(element, level_3_path, default_primaryKeys, level_3_states);
        }
        // if (!level_4_states.finish) {
        //   calculate(element, level_4_path, primaryKeys, level_4_states)
        // }
        // if (!level_5_states.finish) {
        //   calculate(element, level_5_path, primaryKeys, level_5_states, true, true, true)
        // }
        if (level_1_states.finish &&
            // level_2_states.finish &&
            level_3_states.finish &&
            // level_4_states.finish &&
            // level_5_states.finish
            level_2_states.finish) {
            break;
        }
        element = element.parentNode;
        if (element === null) {
            console.log('ERROR: Cannot determine CSS selector. Please report the error by providing the URL and the element at https://github.com/mszeles/selenideium-element-inspector/issues');
            break;
        }
    }
    if (level_1_states.finish && level_1_path.length) {
        result.push({
            type: 'xpath',
            value: level_1_path.join(''),
        });
    }
    if (level_2_states.finish && level_2_path.length) {
        result.push({
            type: 'xpath',
            value: level_2_path.join(''),
        });
    }
    if (level_3_states.finish && level_3_path.length) {
        result.push({
            type: 'xpath',
            value: level_3_path.join(''),
        });
    }
    if (level_4_states.finish && level_4_path.length) {
        result.push({
            type: 'xpath',
            value: level_4_path.join(''),
        });
    }
    if (level_5_states.finish && level_5_path.length) {
        result.push({
            type: 'xpath',
            value: level_5_path.join(''),
        });
    }
    return result;
};
exports.generateElementFindRules = generateElementFindRules;


/***/ }),

/***/ 1615:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MouseModifiers = exports.FailType = exports.KeyEventCode = exports.MouseInteractionsEventTypes = void 0;
const tuple = (...args) => args;
exports.MouseInteractionsEventTypes = tuple('MouseUp', 'MouseMove', 'MouseDown', 'Click', 'ContextMenu', 'DblClick', 'Focus', 'Blur');
var KeyEventCode;
(function (KeyEventCode) {
    KeyEventCode["Enter"] = "Enter";
    KeyEventCode["Escape"] = "Escape";
    KeyEventCode["Tab"] = "Tab";
    KeyEventCode["ArrowLeft"] = "ArrowLeft";
    KeyEventCode["ArrowRight"] = "ArrowRight";
    KeyEventCode["ArrowUp"] = "ArrowUp";
    KeyEventCode["ArrowDown"] = "ArrowDown";
})(KeyEventCode = exports.KeyEventCode || (exports.KeyEventCode = {}));
var FailType;
(function (FailType) {
    FailType[FailType["NONODE"] = 0] = "NONODE";
    FailType[FailType["JSERROR"] = 1] = "JSERROR";
    FailType[FailType["NORULES"] = 2] = "NORULES";
    FailType[FailType["EDITORKIT"] = 3] = "EDITORKIT";
})(FailType = exports.FailType || (exports.FailType = {}));
var ResponseErrorReason;
(function (ResponseErrorReason) {
    ResponseErrorReason["Failed"] = "Failed";
    ResponseErrorReason["Aborted"] = "Aborted";
    ResponseErrorReason["TimedOut"] = "TimedOut";
    ResponseErrorReason["AccessDenied"] = "AccessDenied";
    ResponseErrorReason["ConnectionClosed"] = "ConnectionClosed";
    ResponseErrorReason["ConnectionReset"] = "ConnectionReset";
    ResponseErrorReason["ConnectionRefused"] = "ConnectionRefused";
    ResponseErrorReason["ConnectionAborted"] = "ConnectionAborted";
    ResponseErrorReason["ConnectionFailed"] = "ConnectionFailed";
    ResponseErrorReason["NameNotResolved"] = "NameNotResolved";
    ResponseErrorReason["InternetDisconnected"] = "InternetDisconnected";
    ResponseErrorReason["AddressUnreachable"] = "AddressUnreachable";
})(ResponseErrorReason || (ResponseErrorReason = {}));
var MouseModifiers;
(function (MouseModifiers) {
    MouseModifiers[MouseModifiers["Default"] = 0] = "Default";
    MouseModifiers[MouseModifiers["Alt"] = 1] = "Alt";
    MouseModifiers[MouseModifiers["Ctrl"] = 2] = "Ctrl";
    MouseModifiers[MouseModifiers["Meta"] = 4] = "Meta";
    MouseModifiers[MouseModifiers["Command"] = 4] = "Command";
    MouseModifiers[MouseModifiers["Shift"] = 8] = "Shift";
})(MouseModifiers = exports.MouseModifiers || (exports.MouseModifiers = {}));


/***/ }),

/***/ 7741:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.matchMouseUpAndMouseDown = exports.getFindRules = exports.findShadowRoots = exports.shadowRootHosts = exports.isInShadow = exports.HookWindowOpen = exports.GenerateTargetDescription = exports.deepTravalSal = exports.updateRect = exports.findFrame = exports.setOnlyE2EID = exports.setSvgWrap = exports.getTagName = exports.isVisible = exports.isValidClassValue = exports.errorListen = exports.postDomMutation = exports.postJsErrorMessage = exports.postTwoMessage = exports.postLogRulesMessage = exports.postLogMessage = exports.processElementId = exports.processElementRuntimeId = exports.detectIsReact = exports.isTouchEvent = exports.getEventTarget = exports.isBlocked = exports.classMatchesRegex = exports.addEventListener = void 0;
/* eslint-disable max-depth */
const uuid_1 = __webpack_require__(5546);
const xpath_1 = __webpack_require__(203);
const addEventListener = (type, fn, target) => {
    const options = { capture: true, passive: type !== 'click' };
    target.addEventListener(type, fn, options);
    return () => target.removeEventListener(type, fn, options);
};
exports.addEventListener = addEventListener;
function classMatchesRegex(node, regex, checkAncestors) {
    var _a;
    if (!node) {
        return false;
    }
    if (node.nodeType !== node.ELEMENT_NODE) {
        if (!checkAncestors) {
            return false;
        }
        return classMatchesRegex(node.parentNode, regex, checkAncestors);
    }
    for (let eIndex = (_a = node.classList) === null || _a === void 0 ? void 0 : _a.length; eIndex--;) {
        const className = node.classList[eIndex];
        if (regex.test(className)) {
            return true;
        }
    }
    if (!checkAncestors) {
        return false;
    }
    return classMatchesRegex(node.parentNode, regex, checkAncestors);
}
exports.classMatchesRegex = classMatchesRegex;
function isBlocked(node, blockClass, blockSelector, checkAncestors) {
    var _a;
    if (!node) {
        return false;
    }
    const el = node.nodeType === node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) {
        return false;
    }
    if (typeof blockClass === 'string') {
        if ((_a = el.classList) === null || _a === void 0 ? void 0 : _a.contains(blockClass)) {
            return true;
        }
        if (checkAncestors && el.closest(`.${blockClass}`) !== null) {
            return true;
        }
    }
    else if (classMatchesRegex(el, blockClass, checkAncestors)) {
        return true;
    }
    if (blockSelector) {
        if (node.matches(blockSelector)) {
            return true;
        }
        if (checkAncestors && el.closest(blockSelector) !== null) {
            return true;
        }
    }
    return false;
}
exports.isBlocked = isBlocked;
function getEventTarget(event) {
    try {
        if ('composedPath' in event) {
            const path = event.composedPath();
            if (path.length) {
                return path[0];
            }
        }
        else if ('path' in event && event.path.length) {
            return event.path[0];
        }
        return event.target;
    }
    catch (_a) {
        return event.target;
    }
}
exports.getEventTarget = getEventTarget;
function isTouchEvent(event) {
    return Boolean(event.changedTouches);
}
exports.isTouchEvent = isTouchEvent;
// export function throttle<T>(
//   func: (arg: T) => void,
//   wait: number,
//   options: ThrottleOptions = {},
// ) {
//   let timeout: ReturnType<typeof setTimeout> | null = null;
//   let previous = 0;
//   return function (...args: T[]) {
//     const now = Date.now();
//     if (!previous && options.leading === false) {
//       previous = now;
//     }
//     const remaining = wait - (now - previous);
//     // eslint-disable-next-line consistent-this, @babel/no-invalid-this, @typescript-eslint/no-this-alias
//     const context = this;
//     if (remaining <= 0 || remaining > wait) {
//       if (timeout) {
//         clearTimeout(timeout);
//         timeout = null;
//       }
//       previous = now;
//       func.apply(context, args);
//     } else if (!timeout && options.trailing !== false) {
//       timeout = setTimeout(() => {
//         previous = options.leading === false ? 0 : Date.now();
//         timeout = null;
//         func.apply(context, args);
//       }, remaining);
//     }
//   };
// }
const detectIsReact = () => Array.from(document.querySelectorAll('[id]')).some((e) => e._reactRootContainer !== undefined);
exports.detectIsReact = detectIsReact;
const processElementRuntimeId = () => {
    const els = document.querySelectorAll('[nclc-runtime-id]');
    const map = {};
    els.forEach((el) => {
        const id = el.getAttribute('nclc-runtime-id');
        if (id) {
            if (map[id]) {
                map[id] = [...map[id], el];
            }
            else {
                map[id] = [el];
            }
        }
    });
    Object.keys(map).forEach((key) => {
        const eles = map[key];
        if (eles.length) {
            eles.forEach((el, i) => {
                el.setAttribute('nclc-runtime-mnt-id', `${key}-${i + 1}`);
            });
        }
    });
};
exports.processElementRuntimeId = processElementRuntimeId;
const processElementId = () => {
    const els = document.querySelectorAll('[id]');
    const map = {};
    els.forEach((el) => {
        const id = el.getAttribute('id');
        if (id) {
            if (map[id]) {
                map[id] = [...map[id], el];
            }
            else {
                map[id] = [el];
            }
        }
    });
    Object.keys(map).forEach((key) => {
        const eles = map[key];
        if (eles.length) {
            eles.forEach((el, i) => {
                el.setAttribute('mnt-id', `${key}-${i + 1}`);
            });
        }
    });
};
exports.processElementId = processElementId;
const postLogMessage = (type, content, noTime = false) => {
    console.log('postLogMessage', type, content, noTime);
    // chrome.runtime.sendMessage(
    //   {
    //     type: 'mnt-rr-log',
    //     data: {
    //       type: 'mnt-rr-log',
    //       payload: {
    //         type,
    //         content,
    //         timestamp: noTime ? null : Date.now(),
    //       },
    //     },
    //   },
    //   function (sendResponse) {
    //     sendResponse()
    //   },
    // )
};
exports.postLogMessage = postLogMessage;
const postLogRulesMessage = (rules) => {
    rules.forEach((rule, index) => {
        (0, exports.postLogMessage)('Info', `${index + 1}. 类型：${rule.type},值：${rule.value}`, true);
    });
};
exports.postLogRulesMessage = postLogRulesMessage;
const postTwoMessage = (typ, rules) => {
    (0, exports.postLogMessage)('Info', `事件：${typ}, 对应的rules: `);
    (0, exports.postLogRulesMessage)(rules);
};
exports.postTwoMessage = postTwoMessage;
const postJsErrorMessage = (content) => {
    window.postMessage({
        type: 'mnt-rr-error',
        data: {
            type: 'javascript',
            content,
        },
    });
};
exports.postJsErrorMessage = postJsErrorMessage;
const postDomMutation = () => __awaiter(void 0, void 0, void 0, function* () {
    yield chrome.runtime.sendMessage({
        type: 'mnt-rr-dom-mutation',
        data: {
            type: 'mnt-rr-dom-mutation',
        },
    });
});
exports.postDomMutation = postDomMutation;
// const originAddEventListener = EventTarget.prototype.addEventListener;
// EventTarget.prototype.addEventListener = function (type, listener, options) {
//   const wrappedListener = function (...args: any[]) {
//     try {
//       return listener.apply(this, args);
//     } catch (err) {
//       throw err;
//     }
//   };
//   return originAddEventListener.call(this, type, wrappedListener, options);
// };
// todo 是不是要写在kakashi里
const errorListen = () => {
    window.onerror = (message, source) => {
        (0, exports.postJsErrorMessage)(JSON.stringify({ message, source }));
    };
    // 捕获资源加载的错误
    window.addEventListener('unhandledrejection', (e) => {
        e.preventDefault();
        (0, exports.postJsErrorMessage)(`unhandledrejection: ${e.reason}`);
        return true;
    });
};
exports.errorListen = errorListen;
const isValidClassValue = (classValue) => {
    if (!classValue || classValue === '') {
        return false;
    }
    if (!classValue.trim()) {
        return false;
    }
    if (classValue.includes('{') || classValue.includes('}')) {
        return false;
    }
    return true;
};
exports.isValidClassValue = isValidClassValue;
function isVisible(elem) {
    var _a;
    const style = window.getComputedStyle(elem);
    if (style.display === 'none') {
        return false;
    }
    if (style.visibility !== 'visible') {
        return false;
    }
    if (elem.tagName.toLowerCase().startsWith('svg')) {
        let svgParentElement = elem.parentElement;
        while (svgParentElement === null || svgParentElement === void 0 ? void 0 : svgParentElement.tagName.toLowerCase().startsWith('svg')) {
            svgParentElement = svgParentElement.parentElement;
        }
        if (!svgParentElement) {
            return false;
        }
        return isVisible(svgParentElement);
    }
    if (elem.offsetWidth + elem.offsetHeight + elem.getBoundingClientRect().height + elem.getBoundingClientRect().width ===
        0) {
        return false;
    }
    const elemCenter = {
        x: elem.getBoundingClientRect().left + elem.offsetWidth / 2,
        y: elem.getBoundingClientRect().top + elem.offsetHeight / 2,
    };
    if (elemCenter.x < 0) {
        return false;
    }
    const clientWidth = document.documentElement.clientWidth || window.innerWidth;
    const clientHeight = document.documentElement.clientHeight || window.innerHeight;
    const boundingWidth = elem.getBoundingClientRect().width;
    if (boundingWidth > clientWidth) {
        return true;
    }
    if (boundingWidth < clientWidth && elemCenter.x > clientWidth) {
        return false;
    }
    if (elemCenter.y < 0) {
        return false;
    }
    if (elem.offsetHeight > clientHeight) {
        return true;
    }
    if (elemCenter.y > clientHeight) {
        return false;
    }
    try {
        let pointContainer = document.elementFromPoint(elemCenter.x, elemCenter.y);
        do {
            if (pointContainer === elem) {
                return true;
            }
        } while ((pointContainer = (_a = pointContainer === null || pointContainer === void 0 ? void 0 : pointContainer.parentElement) !== null && _a !== void 0 ? _a : null));
    }
    catch (e) {
        console.error(e);
        return false;
    }
    return false;
}
exports.isVisible = isVisible;
const getTagName = (element) => { var _a; return ((_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) || ''; };
exports.getTagName = getTagName;
const setSvgWrap = () => {
    // 1. 查找所有的 svg 元素
    const svgElements = document.querySelectorAll('svg');
    // 2. 判断 svg 是否是父级的唯一子元素
    svgElements.forEach(function (svgElement) {
        const { parentElement } = svgElement;
        const isOnlyChild = (parentElement === null || parentElement === void 0 ? void 0 : parentElement.children.length) === 1 && parentElement.children[0] === svgElement;
        // 3. 如果不是唯一子元素就为 svg 添加一个父级使用 div
        if (!isOnlyChild && parentElement) {
            const wrapperElement = document.createElement('div');
            wrapperElement.style.display = 'contents';
            parentElement.replaceChild(wrapperElement, svgElement);
            wrapperElement.appendChild(svgElement);
        }
    });
};
exports.setSvgWrap = setSvgWrap;
const setOnlyE2EID = () => {
    const e2e_els = document.querySelectorAll('[data-e2e-id]');
    const ids = [];
    e2e_els.forEach((el) => {
        const e2e_id = el.getAttribute('data-e2e-id');
        if (e2e_id) {
            ids.push(e2e_id);
        }
    });
    Array.from(new Set(ids)).forEach((id) => {
        const els = document.querySelectorAll(`[data-e2e-id="${id}"]`);
        if (els.length === 1) {
            els[0].setAttribute('data-e2e-id-mnt', id);
            if (id.toLowerCase().includes('table')) {
                const table = els[0].querySelectorAll('table');
                if (table.length === 1) {
                    const trs_head = table[0].querySelectorAll('thead tr');
                    trs_head.forEach((tr, trIndex) => {
                        const ths = tr.querySelectorAll('th');
                        ths.forEach((th, thIndex) => {
                            const _index = thIndex + 1 === ths.length ? 'last()' : thIndex + 1;
                            th.setAttribute('data-e2e-relative-path', `//${(0, exports.getTagName)(els[0])}[@data-e2e-id="${id}"]//table/thead/tr[${trIndex + 1}]//th[${_index}]`);
                        });
                    });
                    const trs_body = table[0].querySelectorAll('tbody tr');
                    trs_body.forEach((tr, trIndex) => {
                        const tds = tr.querySelectorAll('td');
                        tds.forEach((td, tdIndex) => {
                            const _index = tdIndex + 1 === tds.length ? 'last()' : tdIndex + 1;
                            td.setAttribute('data-e2e-relative-path', `//${(0, exports.getTagName)(els[0])}[@data-e2e-id="${id}"]//table/tbody/tr[${trIndex + 1}]//td[${_index}]`);
                        });
                    });
                }
            }
            console.log('Only Element', els[0]);
        }
    });
    if (!e2e_els.length) {
        const ud_table_body = document.querySelectorAll('.ud__table-body');
        if (ud_table_body.length === 1) {
            const trs_body = ud_table_body[0].querySelectorAll('tbody tr');
            trs_body.forEach((tr, trIndex) => {
                const tds = tr.querySelectorAll('td');
                tds.forEach((td, tdIndex) => {
                    const _index = tdIndex + 1 === tds.length ? 'last()' : tdIndex + 1;
                    td.setAttribute('data-e2e-relative-path', `//*[@class='ud__table-body']//tbody/tr[${trIndex + 1}]//td[${_index}]`);
                });
            });
        }
        const ud_table_head = document.querySelectorAll('.ud__table-thead');
        if (ud_table_head.length === 1) {
            const trs_head = ud_table_head[0].querySelectorAll('thead tr');
            trs_head.forEach((tr, trIndex) => {
                const ths = tr.querySelectorAll('th');
                ths.forEach((th, thIndex) => {
                    const _index = thIndex + 1 === ths.length ? 'last()' : thIndex + 1;
                    th.setAttribute('data-e2e-relative-path', `//*[@class='ud__table-thead']//thead/tr[${trIndex + 1}]//th[${_index}]`);
                });
            });
        }
    }
};
exports.setOnlyE2EID = setOnlyE2EID;
function findFrame(node, frames) {
    if (node.Type.toLocaleLowerCase() === 'iframe' && node.Visible) {
        frames.push(node);
    }
    if (node.Children.length) {
        node.Children.forEach((n) => {
            findFrame(n, frames);
        });
    }
}
exports.findFrame = findFrame;
function updateRect(node, rect) {
    if (node.Visible && node.Rect) {
        node.Rect.Top += rect.Top;
        node.Rect.Left += rect.Left;
    }
    if (node.Children.length) {
        node.Children.forEach((n) => {
            updateRect(n, rect);
        });
    }
}
exports.updateRect = updateRect;
/**
 * 深度遍历 dom 对象生成 控件树 Json
 * @param node element节点
 * @param nodes 控件树集合
 * @returns 控件树集合
 */
function deepTravalSal(node, nodes, iframes) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    const stack = [];
    if (node) {
        stack.push(node);
        while (stack.length) {
            const item = stack.shift();
            if (item) {
                // 暂时不记录 style 标签和 script 标签
                if (item.tagName.toLowerCase() === 'style' || item.tagName.toLowerCase() === 'script') {
                    continue;
                }
                const len = item.children.length || 0;
                const rect = item.getBoundingClientRect();
                const attr = {};
                if (item.hasAttributes()) {
                    const attrs = item.attributes;
                    for (let i = attrs.length - 1; i >= 0; i--) {
                        if (attrs[i].name === 'src' && attrs[i].value.includes('./')) {
                            attr.src = `${location.protocol}//${location.host}${location.pathname.replace(/\/[^\/]+$/, '') + attrs[i].value.replace('./', '/')}`;
                        }
                        else {
                            attr[`${attrs[i].name}`] = attrs[i].value;
                        }
                    }
                    try {
                        if (node.tagName.toLowerCase() === 'iframe' &&
                            ((_b = (_a = node.contentWindow) === null || _a === void 0 ? void 0 : _a.document) === null || _b === void 0 ? void 0 : _b.location.href)) {
                            attr.document_src = (_f = (_e = (_d = (_c = node.contentWindow) === null || _c === void 0 ? void 0 : _c.document) === null || _d === void 0 ? void 0 : _d.location) === null || _e === void 0 ? void 0 : _e.href) !== null && _f !== void 0 ? _f : undefined;
                        }
                    }
                    catch (e) {
                        console.error('get iframe document url fail', e);
                    }
                }
                // const fullPath = makeQueryForElement(item, true);
                let ruls = [];
                let elementXpath = '';
                if (isVisible(item)) {
                    const { ruls: _ruls } = (0, xpath_1.processElementXpath)(item);
                    // 不再提供独立的 elementXpath
                    elementXpath = _ruls.length ? _ruls[0].value : '';
                    ruls = _ruls.length ? _ruls : [];
                }
                const fontSize = window.getComputedStyle(item, null).getPropertyValue('font-size').replace('px', '') || undefined;
                let inputValue = '';
                if (item.tagName.toLowerCase() === 'input') {
                    inputValue = (_g = item.value) !== null && _g !== void 0 ? _g : '';
                }
                if (item.contentEditable === 'true') {
                    inputValue = (_h = item.textContent) !== null && _h !== void 0 ? _h : '';
                }
                let text = '';
                if (item.childNodes.length > 0) {
                    let textNodeCount = 0;
                    item.childNodes.forEach((c) => {
                        if (c.nodeType === Node.TEXT_NODE) {
                            textNodeCount += 1;
                        }
                    });
                    // 当前节点内包含文字
                    if (textNodeCount > 0 && item.tagName.toLowerCase() !== 'body') {
                        text = (_j = item.textContent) !== null && _j !== void 0 ? _j : '';
                    }
                }
                else {
                    text = (_k = item.textContent) !== null && _k !== void 0 ? _k : '';
                }
                const current = {
                    _type: 'web',
                    Type: item.tagName,
                    Text: text,
                    Value: inputValue,
                    Visible: isVisible(item),
                    Attributes: attr,
                    Font: fontSize,
                    Rect: {
                        Left: rect.left,
                        Top: rect.top,
                        Width: rect.width,
                        Height: rect.height,
                    },
                    AccurateRect: {
                        Left: rect.left * window.devicePixelRatio,
                        Top: rect.top * window.devicePixelRatio,
                        Width: rect.width * window.devicePixelRatio,
                        Height: rect.height * window.devicePixelRatio,
                    },
                    elementXpath,
                    Children: [],
                    hash: (0, uuid_1.v4)(),
                    findRules: ruls,
                    devicePixelRatio: window.devicePixelRatio,
                };
                if (item.tagName === 'BODY') {
                    current.manifest = {
                        version: chrome.runtime.getManifest().version,
                    };
                }
                nodes.push(current);
                if (current.Type.toLowerCase() === 'iframe' && current.Visible && iframes !== undefined) {
                    iframes.push(current);
                }
                for (let i = 0; i <= len - 1; i++) {
                    if (current.Type.toLowerCase() !== 'svg') {
                        deepTravalSal(item.children[i], current.Children, iframes);
                    }
                }
            }
        }
    }
    return nodes;
}
exports.deepTravalSal = deepTravalSal;
const GenerateTargetDescription = (ele, type) => {
    var _a;
    const nodeName = ele.nodeName.toLowerCase();
    const text = ele.textContent;
    const cls = ((_a = ele.classList) === null || _a === void 0 ? void 0 : _a.toString()) || '';
    if (nodeName === 'button' || cls.includes('btn') || cls.includes('button')) {
        return `点击 按钮 ${text}`;
    }
    else {
        return `点击 ${nodeName} ${text}`;
    }
};
exports.GenerateTargetDescription = GenerateTargetDescription;
const HookWindowOpen = () => {
    const origin = window.open.bind(window);
    Object.assign(window, {
        open: (url, target, features) => {
            origin(url, '_self', features);
        },
    });
};
exports.HookWindowOpen = HookWindowOpen;
function isInShadow(node) {
    return node.getRootNode() instanceof ShadowRoot;
}
exports.isInShadow = isInShadow;
exports.shadowRootHosts = new WeakSet();
function findShadowRoots(element) {
    if (!element) {
        return [];
    }
    // @ts-ignore
    const shadowRoots = [element, ...element.querySelectorAll('*')]
        .filter((elem) => Boolean(elem.shadowRoot))
        .flatMap((elem) => [elem.shadowRoot, ...findShadowRoots(elem.shadowRoot)]);
    shadowRoots.forEach((shadowRoot) => {
        const { host } = shadowRoot.getRootNode();
        exports.shadowRootHosts.add(host);
    });
    return shadowRoots;
}
exports.findShadowRoots = findShadowRoots;
function getFindRules(target) {
    const find = (0, xpath_1.processElementXpath)(target);
    if (isInShadow(target)) {
        const shadowRoot = target.getRootNode();
        const { host } = shadowRoot;
        const hostFind = (0, xpath_1.processElementXpath)(host);
        find === null || find === void 0 ? void 0 : find.ruls.forEach((rule) => {
            rule.hostRules = hostFind.ruls;
        });
    }
    return find;
}
exports.getFindRules = getFindRules;
function matchMouseUpAndMouseDown(mouseUpEvent, mouseDownEvent) {
    if (mouseUpEvent && mouseDownEvent) {
        return (Math.abs(mouseDownEvent.clientX - mouseUpEvent.clientX) < 10 &&
            Math.abs(mouseDownEvent.clientY - mouseUpEvent.clientY) < 10 &&
            (mouseDownEvent.button === 0 || mouseUpEvent.button === 0)); // 0 => left button
        // && mouseDownEvent.target === mouseUpEvent.target // 提示词场景下的 mouseup 时 target 已经是代码窗口而不是提示词选择窗口
    }
    return false;
}
exports.matchMouseUpAndMouseDown = matchMouseUpAndMouseDown;


/***/ }),

/***/ 203:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/* eslint-disable max-lines */
/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/prefer-for-of */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/member-ordering */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.processElementXpath = void 0;
const find_rules_1 = __webpack_require__(1080);
const utils_1 = __webpack_require__(7741);
const PathReg = new RegExp(/^path\[\d+\]$|path/);
function escapeJquery(srcString) {
    // 转义之后的结果
    let escapseResult = srcString;
    // 遇到的特殊字符
    const jsSpecialChars = ['$', '%'];
    for (let i = 0; i < jsSpecialChars.length; i++) {
        escapseResult = escapseResult.replace(new RegExp(`\\${jsSpecialChars[i]}`, 'g'), `\\${jsSpecialChars[i]}`);
    }
    return escapseResult;
}
class SelectorGenerator {
    constructor() {
        this.selectors = [];
    }
    storeSelector(selector, type) {
        if (selector === undefined || selector === 'undefined') {
            console.log('WARNING!: Invalid selector at: ');
            console.trace();
            return;
        }
        this.selectors.push({ value: selector, type });
    }
    generateIdBasedSelector(id) {
        throw new Error('You have to implement the method!');
    }
    generateNameBasedSelector(name) {
        throw new Error('You have to implement the method!');
    }
    generateTagNameBasedSelector(tagName) {
        throw new Error('You have to implement the method!');
    }
    generateLinkTextBasedSelector(linkText) {
        throw new Error('You have to implement the method!');
    }
    generateTextBasedSelector(text) {
        throw new Error('You have to implement the method!');
    }
    generateCssBasedSelector(css) {
        this.storeSelector(css, 'css');
    }
    generateXPathBasedSelector(xPath) {
        throw new Error('You have to implement the method!');
    }
    collectAttributeBasedSelectors(element) {
        var _a, _b;
        const doc = element.getRootNode();
        const { attributes } = element;
        for (let i = 0; i < attributes.length; i++) {
            const nodeName = attributes[i].nodeName.toLowerCase();
            if (nodeName !== 'id' &&
                nodeName !== 'class' &&
                nodeName !== 'name' &&
                nodeName !== 'xmlns:xlink' &&
                !nodeName.includes('&') &&
                attributes[i].nodeValue !== null &&
                attributes[i].nodeValue !== undefined &&
                !((_a = attributes[i].nodeValue) === null || _a === void 0 ? void 0 : _a.includes('}')) &&
                !((_b = attributes[i].nodeValue) === null || _b === void 0 ? void 0 : _b.includes('{'))) {
                const cssSelector = `${element.tagName.toLowerCase()}[${nodeName} = '${escape(attributes[i].nodeValue)}']`;
                const allElements = doc.querySelectorAll(cssSelector);
                if (this.hasOnlyOne(allElements)) {
                    this.generateAttributeBasedSelector(element.tagName.toLowerCase(), nodeName, escape(attributes[i].nodeValue));
                }
            }
        }
    }
    generateAttributeBasedSelector(tagName, attributeName, attributeValue) {
        this.generateCssBasedSelector(`${tagName}[${attributeName} = '${attributeValue}']`);
    }
    collectUniqueClassSelectors(element) {
        const doc = element.getRootNode();
        const cl = element.getAttribute('class');
        if (cl === null || cl === undefined) {
            return;
        }
        const classes = cl.split(' ');
        for (let i = 0; i < classes.length; i++) {
            if ((0, utils_1.isValidClassValue)(classes[i])) {
                const cssSelector = `${element.tagName.toLowerCase()}.${classes[i]}`;
                try {
                    if (this.hasOnlyOne(doc.querySelectorAll(cssSelector))) {
                        this.generateClassBasedSelector(element.tagName.toLowerCase(), classes[i]);
                    }
                }
                catch (e) {
                    console.error('collectUniqueClassSelectors error', e);
                }
            }
        }
    }
    generateClassBasedSelector(tagName, className) {
        this.generateCssBasedSelector(`${tagName}.${className}`);
    }
    hasOnlyOne(elementList) {
        return elementList.length === 1;
    }
    hasOnlyOneWithText(elementList, text) {
        let foundCount = 0;
        for (let i = 0; i < elementList.length; i++) {
            if (elementList[i].text !== undefined && elementList[i].text.localeCompare(text) === 0) {
                foundCount++;
                if (foundCount > 1) {
                    return false;
                }
            }
        }
        return foundCount === 1;
    }
    svgFilter(path) {
        if (path.length > 0 && PathReg.test(path[path.length - 1])) {
            path.pop();
        }
        if (path.length > 0 && path[path.length - 1] === 'svg') {
            path.pop();
        }
    }
    // Source: https://stackoverflow.com/questions/3620116/get-css-path-from-dom-element
    // deprecated
    getCssSelector(element, ignoreID = false) {
        if (!(element instanceof Element)) {
            console.log(`Element is not an Element: ${element}`);
            return;
        }
        const path = [];
        while (element.nodeType === Node.ELEMENT_NODE) {
            let selector = element.nodeName.toLowerCase();
            const UIDL_ID = element.getAttribute('data-e2e-id');
            const FORM_ITEM_ID = element.getAttribute('data-nclc-runtime-form-item-id');
            if (FORM_ITEM_ID) {
                selector += `[data-nclc-runtime-form-item-id="${FORM_ITEM_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (UIDL_ID) {
                selector += `[data-e2e-id="${UIDL_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (element.id && !ignoreID) {
                selector += `#${escapeJquery(element.id)}`;
                path.unshift(selector);
                break;
            }
            else {
                let previousSibling = element;
                let nth = 1;
                // eslint-disable-next-line no-cond-assign
                while ((previousSibling = previousSibling.previousElementSibling)) {
                    if (previousSibling.nodeName.toLowerCase() === selector) {
                        nth++;
                    }
                }
                if (nth !== 1) {
                    selector += `:nth-of-type(${nth})`;
                }
            }
            path.unshift(selector);
            // eslint-disable-next-line no-param-reassign
            element = element.parentNode;
            if (element === null) {
                console.log('ERROR: Cannot determine CSS selector. Please report the error by providing the URL and the element at https://github.com/mszeles/selenideium-element-inspector/issues');
                // eslint-disable-next-line consistent-return
                return null;
            }
        }
        this.svgFilter(path);
        // eslint-disable-next-line consistent-return
        return path.join(' > ');
    }
    // deprecated
    getRelativeXPathSelector(element, ignoreID = false) {
        if (!(element instanceof Element)) {
            console.log(`Element is not an Element: ${element}`);
            return;
        }
        const path = [];
        while (element.nodeType === Node.ELEMENT_NODE) {
            let selector = element.nodeName.toLowerCase();
            const UIDL_ID = element.getAttribute('data-e2e-id');
            const FORM_ITEM_ID = element.getAttribute('data-nclc-runtime-form-item-id');
            if (FORM_ITEM_ID) {
                selector += `[@data-nclc-runtime-form-item-id="${FORM_ITEM_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (UIDL_ID) {
                selector += `[@data-e2e-id="${UIDL_ID}"]`;
                path.unshift(selector);
                break;
            }
            else if (element.id && !ignoreID) {
                const mnt_ID = element.getAttribute('mnt-id');
                if (mnt_ID) {
                    selector += `[@mnt-id="${escapeJquery(mnt_ID)}"]`;
                }
                else {
                    selector += `[@id="${escapeJquery(element.id)}"]`;
                }
                path.unshift(selector);
                break;
            }
            else {
                let previousSibling = element;
                let nth = 1;
                // eslint-disable-next-line no-cond-assign
                while ((previousSibling = previousSibling.previousElementSibling)) {
                    if (previousSibling.nodeName.toLowerCase() === selector) {
                        nth++;
                    }
                }
                if (nth !== 0) {
                    selector += `[${nth}]`;
                }
            }
            path.unshift(selector);
            if (element.parentNode === null) {
                console.log('ERROR: Cannot determine XPath selector.');
                // eslint-disable-next-line consistent-return
                return null;
            }
            // eslint-disable-next-line no-param-reassign
            element = element.parentNode;
        }
        this.svgFilter(path);
        // eslint-disable-next-line consistent-return
        return `//${path.join('/')}`;
    }
}
class JavaScriptSelectorGenerator extends SelectorGenerator {
    getName() {
        return 'JavaScript';
    }
    createXPathSelector(selector) {
        return selector;
    }
    generateIdBasedSelector(id) {
        this.storeSelector(`#${id}`, 'css');
    }
    generateNameBasedSelector(name) {
        // this.storeSelector(this.createSelector(`By.name('${name}')`));
    }
    generateTagNameBasedSelector(tagName) {
        // this.storeSelector(this.createSelector(`By.tagName('${tagName}')`));
    }
    generateLinkTextBasedSelector(linkText) {
        // this.storeSelector(this.createSelector(`By.linkText('${linkText}')`));
    }
    generateTextBasedSelector(text) { }
    generateCssBasedSelector(css) {
        this.storeSelector(css, 'css');
    }
    generateXPathBasedSelector(xPath, ignoreID = false) {
        this.storeSelector(xPath, 'xpath');
    }
    generateCssWithIgnoreId(target) {
        const css = this.getCssSelector(target, true);
        if (css) {
            this.storeSelector(css, 'css');
        }
    }
}
const processElementXpath = (target, _log = false) => {
    var _a;
    try {
        // console.log('------------- Element Inspector -------------')
        // console.log(target)
        // 转化一下
        // processElementRuntimeId()
        // processElementId()
        const doc = target.getRootNode();
        const selectorGenerator = new JavaScriptSelectorGenerator();
        if (target.hasAttribute('id')) {
            const id = escapeJquery((_a = target.getAttribute('id')) !== null && _a !== void 0 ? _a : '');
            try {
                if (id && selectorGenerator.hasOnlyOne(doc.querySelectorAll(`*#${id}`))) {
                    selectorGenerator.generateIdBasedSelector(id);
                }
                else {
                    console.log(`Warning: There are multiple elements with id: ${id}`);
                }
            }
            catch (e) {
                console.log('Error is not a valid selector: ', `*#${id}`, 'reason', e);
            }
        }
        // if (target.hasAttribute('name')) {
        //   const name = target.getAttribute('name')
        //   if (name && selectorGenerator.hasOnlyOne(document.getElementsByName(name))) {
        //     selectorGenerator.generateNameBasedSelector(name)
        //   }
        // }
        // if (selectorGenerator.hasOnlyOne(document.getElementsByTagName(target.tagName))) {
        //   selectorGenerator.generateTagNameBasedSelector(target.tagName)
        // }
        // const links = document.getElementsByTagName('a')
        // if (target.tagName.toLowerCase() === 'a') {
        //   if (selectorGenerator.hasOnlyOneWithText(links, (target as HTMLAnchorElement).text)) {
        //     selectorGenerator.generateLinkTextBasedSelector((target as HTMLAnchorElement).text)
        //   }
        // }
        // if (selectorGenerator.hasOnlyOneWithText(document.getElementsByTagName('*'), (target as any).text)) {
        //   selectorGenerator.generateTextBasedSelector((target as any).text)
        // }
        // const css = selectorGenerator.getCssSelector(target)
        // if (css !== null) {
        //   selectorGenerator.generateCssBasedSelector(css as string)
        // }
        // const xpath = selectorGenerator.getRelativeXPathSelector(target)
        // if (xpath !== null) {
        //   selectorGenerator.generateXPathBasedSelector(xpath as string)
        // }
        // const ignoreIDCss = selectorGenerator.getCssSelector(target, true)
        // if (ignoreIDCss) {
        //   selectorGenerator.generateCssBasedSelector(ignoreIDCss)
        // }
        // const ignoreIDXpath = selectorGenerator.getRelativeXPathSelector(target, true)
        // if (ignoreIDXpath) {
        //   selectorGenerator.generateXPathBasedSelector(ignoreIDXpath)
        // }
        selectorGenerator.collectAttributeBasedSelectors(target);
        selectorGenerator.collectUniqueClassSelectors(target);
        // selectorGenerator.generateCssWithIgnoreId(target)
        const ruls = [];
        const notShadowDom = !(0, utils_1.isInShadow)(target);
        if (notShadowDom) { // shadow dom 不支持 xpath 查找
            const xpath = (0, find_rules_1.generateElementFindRules)(target);
            if (xpath === null || xpath === void 0 ? void 0 : xpath.length) {
                xpath.forEach((x) => {
                    selectorGenerator.storeSelector(x.value, 'xpath');
                });
            }
        }
        for (let i = 0; i < selectorGenerator.selectors.length; i++) {
            // console.log(selectorGenerator.selectors[i].value);
            const has = ruls.find((v) => v.value === selectorGenerator.selectors[i].value);
            if (!has) {
                ruls.push(selectorGenerator.selectors[i]);
            }
        }
        // console.log('result', ruls)
        // console.log('---------------------------------------------------------')
        return {
            ruls,
        };
    }
    catch (e) {
        return {
            ruls: [],
        };
    }
};
exports.processElementXpath = processElementXpath;


/***/ }),

/***/ 5546:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "NIL", ({
  enumerable: true,
  get: function get() {
    return _nil.default;
  }
}));
Object.defineProperty(exports, "parse", ({
  enumerable: true,
  get: function get() {
    return _parse.default;
  }
}));
Object.defineProperty(exports, "stringify", ({
  enumerable: true,
  get: function get() {
    return _stringify.default;
  }
}));
Object.defineProperty(exports, "v1", ({
  enumerable: true,
  get: function get() {
    return _v.default;
  }
}));
Object.defineProperty(exports, "v3", ({
  enumerable: true,
  get: function get() {
    return _v2.default;
  }
}));
Object.defineProperty(exports, "v4", ({
  enumerable: true,
  get: function get() {
    return _v3.default;
  }
}));
Object.defineProperty(exports, "v5", ({
  enumerable: true,
  get: function get() {
    return _v4.default;
  }
}));
Object.defineProperty(exports, "validate", ({
  enumerable: true,
  get: function get() {
    return _validate.default;
  }
}));
Object.defineProperty(exports, "version", ({
  enumerable: true,
  get: function get() {
    return _version.default;
  }
}));

var _v = _interopRequireDefault(__webpack_require__(5473));

var _v2 = _interopRequireDefault(__webpack_require__(4405));

var _v3 = _interopRequireDefault(__webpack_require__(5775));

var _v4 = _interopRequireDefault(__webpack_require__(2707));

var _nil = _interopRequireDefault(__webpack_require__(3927));

var _version = _interopRequireDefault(__webpack_require__(7493));

var _validate = _interopRequireDefault(__webpack_require__(4084));

var _stringify = _interopRequireDefault(__webpack_require__(9688));

var _parse = _interopRequireDefault(__webpack_require__(432));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),

/***/ 9756:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */
function md5(bytes) {
  if (typeof bytes === 'string') {
    const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Uint8Array(msg.length);

    for (let i = 0; i < msg.length; ++i) {
      bytes[i] = msg.charCodeAt(i);
    }
  }

  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */


function md5ToHexEncodedArray(input) {
  const output = [];
  const length32 = input.length * 32;
  const hexTab = '0123456789abcdef';

  for (let i = 0; i < length32; i += 8) {
    const x = input[i >> 5] >>> i % 32 & 0xff;
    const hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
    output.push(hex);
  }

  return output;
}
/**
 * Calculate output length with padding and bit length
 */


function getOutputLength(inputLength8) {
  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */


function wordsToMd5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[getOutputLength(len) - 1] = len;
  let a = 1732584193;
  let b = -271733879;
  let c = -1732584194;
  let d = 271733878;

  for (let i = 0; i < x.length; i += 16) {
    const olda = a;
    const oldb = b;
    const oldc = c;
    const oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  return [a, b, c, d];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */


function bytesToWords(input) {
  if (input.length === 0) {
    return [];
  }

  const length8 = input.length * 8;
  const output = new Uint32Array(getOutputLength(length8));

  for (let i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
  }

  return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */


function safeAdd(x, y) {
  const lsw = (x & 0xffff) + (y & 0xffff);
  const msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */


function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */


function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}

function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}

function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}

function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}

function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

var _default = md5;
exports["default"] = _default;

/***/ }),

/***/ 4443:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var _default = {
  randomUUID
};
exports["default"] = _default;

/***/ }),

/***/ 3927:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _default = '00000000-0000-0000-0000-000000000000';
exports["default"] = _default;

/***/ }),

/***/ 432:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function parse(uuid) {
  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Invalid UUID');
  }

  let v;
  const arr = new Uint8Array(16); // Parse ########-....-....-....-............

  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 0xff;
  arr[2] = v >>> 8 & 0xff;
  arr[3] = v & 0xff; // Parse ........-####-....-....-............

  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 0xff; // Parse ........-....-####-....-............

  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 0xff; // Parse ........-....-....-####-............

  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 0xff; // Parse ........-....-....-....-############
  // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)

  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
  arr[11] = v / 0x100000000 & 0xff;
  arr[12] = v >>> 24 & 0xff;
  arr[13] = v >>> 16 & 0xff;
  arr[14] = v >>> 8 & 0xff;
  arr[15] = v & 0xff;
  return arr;
}

var _default = parse;
exports["default"] = _default;

/***/ }),

/***/ 783:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
exports["default"] = _default;

/***/ }),

/***/ 3462:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = rng;
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);

function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ 9462:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;

    case 1:
      return x ^ y ^ z;

    case 2:
      return x & y ^ x & z ^ y & z;

    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  const K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  const H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes === 'string') {
    const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = [];

    for (let i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    // Convert Array-like to Array
    bytes = Array.prototype.slice.call(bytes);
  }

  bytes.push(0x80);
  const l = bytes.length / 4 + 2;
  const N = Math.ceil(l / 16);
  const M = new Array(N);

  for (let i = 0; i < N; ++i) {
    const arr = new Uint32Array(16);

    for (let j = 0; j < 16; ++j) {
      arr[j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
    }

    M[i] = arr;
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (let i = 0; i < N; ++i) {
    const W = new Uint32Array(80);

    for (let t = 0; t < 16; ++t) {
      W[t] = M[i][t];
    }

    for (let t = 16; t < 80; ++t) {
      W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
    }

    let a = H[0];
    let b = H[1];
    let c = H[2];
    let d = H[3];
    let e = H[4];

    for (let t = 0; t < 80; ++t) {
      const s = Math.floor(t / 20);
      const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

var _default = sha1;
exports["default"] = _default;

/***/ }),

/***/ 9688:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
exports.unsafeStringify = unsafeStringify;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

function stringify(arr, offset = 0) {
  const uuid = unsafeStringify(arr, offset); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

var _default = stringify;
exports["default"] = _default;

/***/ }),

/***/ 5473:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _rng = _interopRequireDefault(__webpack_require__(3462));

var _stringify = __webpack_require__(9688);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html
let _nodeId;

let _clockseq; // Previous uuid creation time


let _lastMSecs = 0;
let _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  let i = buf && offset || 0;
  const b = buf || new Array(16);
  options = options || {};
  let node = options.node || _nodeId;
  let clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    const seedBytes = options.random || (options.rng || _rng.default)();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  let msecs = options.msecs !== undefined ? options.msecs : Date.now(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  let nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  const tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  const tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (let n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf || (0, _stringify.unsafeStringify)(b);
}

var _default = v1;
exports["default"] = _default;

/***/ }),

/***/ 4405:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _v = _interopRequireDefault(__webpack_require__(2548));

var _md = _interopRequireDefault(__webpack_require__(9756));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v3 = (0, _v.default)('v3', 0x30, _md.default);
var _default = v3;
exports["default"] = _default;

/***/ }),

/***/ 2548:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.URL = exports.DNS = void 0;
exports["default"] = v35;

var _stringify = __webpack_require__(9688);

var _parse = _interopRequireDefault(__webpack_require__(432));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape

  const bytes = [];

  for (let i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }

  return bytes;
}

const DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
exports.DNS = DNS;
const URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
exports.URL = URL;

function v35(name, version, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    var _namespace;

    if (typeof value === 'string') {
      value = stringToBytes(value);
    }

    if (typeof namespace === 'string') {
      namespace = (0, _parse.default)(namespace);
    }

    if (((_namespace = namespace) === null || _namespace === void 0 ? void 0 : _namespace.length) !== 16) {
      throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
    } // Compute hash of namespace and value, Per 4.3
    // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
    // hashfunc([...namespace, ... value])`


    let bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      offset = offset || 0;

      for (let i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }

      return buf;
    }

    return (0, _stringify.unsafeStringify)(bytes);
  } // Function#name is not settable on some platforms (#270)


  try {
    generateUUID.name = name; // eslint-disable-next-line no-empty
  } catch (err) {} // For CommonJS default export support


  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}

/***/ }),

/***/ 5775:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _native = _interopRequireDefault(__webpack_require__(4443));

var _rng = _interopRequireDefault(__webpack_require__(3462));

var _stringify = __webpack_require__(9688);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function v4(options, buf, offset) {
  if (_native.default.randomUUID && !buf && !options) {
    return _native.default.randomUUID();
  }

  options = options || {};

  const rnds = options.random || (options.rng || _rng.default)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`


  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0, _stringify.unsafeStringify)(rnds);
}

var _default = v4;
exports["default"] = _default;

/***/ }),

/***/ 2707:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _v = _interopRequireDefault(__webpack_require__(2548));

var _sha = _interopRequireDefault(__webpack_require__(9462));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v5 = (0, _v.default)('v5', 0x50, _sha.default);
var _default = v5;
exports["default"] = _default;

/***/ }),

/***/ 4084:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _regex = _interopRequireDefault(__webpack_require__(783));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function validate(uuid) {
  return typeof uuid === 'string' && _regex.default.test(uuid);
}

var _default = validate;
exports["default"] = _default;

/***/ }),

/***/ 7493:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;

var _validate = _interopRequireDefault(__webpack_require__(4084));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function version(uuid) {
  if (!(0, _validate.default)(uuid)) {
    throw TypeError('Invalid UUID');
  }

  return parseInt(uuid.slice(14, 15), 16);
}

var _default = version;
exports["default"] = _default;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(1764);
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});